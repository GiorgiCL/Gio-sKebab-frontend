# The Continuum ? recovered direction, version 4

The original film used Three.js + Canvas, captured with Playwright and encoded using FFmpeg. This isolated source resumes that exact production approach. The original master is `../refinement/before/idiomorph-master-1080p.mp4`; the similarly named `../output/idiomorph-master-1080p.mp4` is the later illustrated iteration. Original Git source/archive recovered into `recovered/`. See RECOVERY.md and evidence/before/inventory.json for provenance.

## Edit and preview

From `studio-workspace/`, run `node recovery-v4/source/serve.mjs`, then open http://127.0.0.1:4195/. Scrub the timeline or select Play. Enable Sound for synchronized original audio. The exact official logo is `brand/IdiomorphLogo.png`. Typography uses the included OFL fonts. `source/film.mjs` contains geometry, materials, camera, interface studies and deterministic choreography. `source/sound.mjs` synthesizes the original score.

Existing Node dependencies are pinned in the parent package-lock.json. A fresh source installation uses `npm ci` in studio-workspace. No dependency changes were needed for this recovery. Chrome defaults to the installed Windows path; adjust source/render.mjs for another Chromium installation. Set FILM_PORT if 4195 is occupied.

## Render

Run each command from studio-workspace, in this order:

```powershell
node recovery-v4/source/sound.mjs
node recovery-v4/source/render.mjs --animatic
node recovery-v4/source/encode.mjs --animatic
node recovery-v4/source/media.mjs --animatic
# Review the actual encoded animatic and transitions before proceeding.
node recovery-v4/source/render.mjs
node recovery-v4/source/assets.mjs
node recovery-v4/source/encode.mjs
node recovery-v4/source/media.mjs
```

32 seconds / 30 fps / 1920 ? 1080. Spark 0?5; Structure 5?12; Transformation 12?23; Reveal 23?32. Silver/violet surfaces become original concept interfaces, then converge around the official folded emblem. Final artwork is exact supplied imagery, never a claimed photorealistic mesh reconstruction. The three service studies are concepts, not client projects. No human simulation or rejected film audio is reused.

Outputs use distinct `idiomorph-continuum-v4-*` names. The new 1080p master and 48 kHz stereo sound are in output/. Responsive 720p H.264/AAC, VP9/Opus, posters and captions are in frontend/public/studio/recovery/. All previous masters, ZIPs and source remain preserved. Re-rendering this version replaces v4 intermediates; copy a finished v4 master to a new version name before making later creative iterations.

## Validation and evidence

Build the frontend, then run `npm run preview -- --host 127.0.0.1 --port 4186 --strictPort` there. From studio-workspace:

```powershell
node recovery-v4/source/verify.mjs
node recovery-v4/source/visual.mjs
node recovery-v4/source/lighthouse.mjs
```

QA reuses local axe-core/Lighthouse from `.verification/frontend-tools`; these tools are not part of the production app or portable rendering dependencies. Evidence is under evidence/: before/after screenshots, browser assertions, axe reports, encoded film/transition contact sheets, preservation hashes, and Lighthouse HTML/JSON. `evidence/comparison.html` is the local comparison index. Frontend report: frontend/docs/STUDIO_RECOVERY_V4.md.

Audio playback and measured loudness are checked technically. This assistant environment cannot accept audio input, so subjective listening is not claimed. A finished WAV and compact MP3 audition are supplied for human review. The soundtrack is newly synthesized and no stock licensing is required.

## Tools and notices

No required tooling cost, subscriptions, paid API, stock media, installation scripts, or new dependencies. Three.js MIT; Playwright Apache-2.0; ffmpeg-static local GPL-3.0-or-later encoder; DM Sans and Instrument Serif SIL OFL. Full notices are included in the source archive. FFmpeg binaries/node_modules are excluded. Remotion and video-shotcraft were not used by the recovered implementation. Blender is not used here.
