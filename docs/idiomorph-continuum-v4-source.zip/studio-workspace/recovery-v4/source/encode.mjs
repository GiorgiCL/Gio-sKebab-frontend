import ffmpeg from 'ffmpeg-static'
import {spawn} from 'node:child_process'
import {mkdir,writeFile,stat} from 'node:fs/promises'
import {fileURLToPath} from 'node:url'
const out=new URL('../output/',import.meta.url),web=new URL('../../../frontend/public/studio/recovery/',import.meta.url),path=u=>fileURLToPath(u)
await mkdir(web,{recursive:true})
async function run(args){return await new Promise((resolve,reject)=>{const p=spawn(ffmpeg,['-y','-hide_banner',...args],{windowsHide:true,stdio:['ignore','ignore','pipe']});let log='';p.stderr.on('data',b=>{log+=b});p.on('error',reject);p.on('exit',code=>code?reject(Error(log.slice(-4000))):resolve(log))})}
const raw=path(new URL('idiomorph-continuum-v4-sound-raw.wav',out)),sound=path(new URL('idiomorph-continuum-v4-sound.wav',out))
const log=await run(['-i',raw,'-af','loudnorm=I=-18:TP=-1.5:LRA=9:print_format=json','-f','null','-'])
const match=log.match(/\{\s*"input_i"[\s\S]*?\}/),loudness=JSON.parse(match[0])
await writeFile(new URL('sound-analysis-first-pass.json',out),JSON.stringify(loudness,null,2))
await run(['-i',raw,'-af',`loudnorm=I=-18:TP=-1.5:LRA=9:measured_I=${loudness.input_i}:measured_LRA=${loudness.input_lra}:measured_TP=${loudness.input_tp}:measured_thresh=${loudness.input_thresh}:offset=${loudness.target_offset}:linear=true:print_format=json`,'-ar','48000','-c:a','pcm_s16le',sound])
await run(['-i',sound,'-ac','1','-ar','22050','-c:a','libmp3lame','-b:a','48k',path(new URL('sound-listening.mp3',out))])
if(process.argv.includes('--audio-only')){console.log('Finished normalized soundtrack + listening MP3.');process.exit(0)}
const animatic=process.argv.includes('--animatic'),picture=path(new URL(`idiomorph-continuum-v4-${animatic?'animatic':'final'}-picture.mp4`,out))
if(animatic){await run(['-i',picture,'-i',sound,'-c:v','copy','-c:a','aac','-b:a','160k','-movflags','+faststart','-t','32',path(new URL('idiomorph-continuum-v4-animatic.mp4',out))]);console.log('Animatic with new sound complete.');process.exit(0)}
const master=new URL('idiomorph-continuum-v4-master-1080p.mp4',out)
await run(['-i',picture,'-i',sound,'-c:v','copy','-c:a','aac','-b:a','256k','-movflags','+faststart','-t','32',path(master)])
console.log('New 1080p master muxed; old masters preserved.')
for(const[type,args]of[['mp4',['-c:v','libx264','-preset','slow','-crf','22','-c:a','aac','-b:a','128k','-movflags','+faststart']],['webm',['-c:v','libvpx-vp9','-crf','31','-b:v','0','-row-mt','1','-cpu-used','3','-c:a','libopus','-b:a','112k']]]){
 const target=new URL('idiomorph-continuum-v4-720p.'+type,web);await run(['-i',path(master),'-vf','scale=1280:720',...args,path(target)]);console.log(type,(await stat(target)).size)
}
for(const[name,width]of[['continuum-v4-poster.webp',1600],['continuum-v4-poster-small.webp',640]])await run(['-i',path(new URL('poster-clean.png',out)),'-vf',`scale=${width}:-1`,'-c:v','libwebp','-quality','90','-frames:v','1',path(new URL(name,web))])
await writeFile(new URL('continuum-v4-captions.vtt',web),`WEBVTT

00:00.000 --> 00:05.000
[An atmospheric score emerges. A luminous violet form grows and opens into silver surfaces.]

00:05.000 --> 00:12.000
[Surfaces fracture into connected architectural spans. Give the idea a direction.]

00:12.000 --> 00:16.000
[The same surfaces become interfaces. A website wireframe resolves into finished type and layout.]

00:16.000 --> 00:19.000
[Custom web applications. Selecting Engineering filters a project workspace to its two matching tasks.]

00:19.000 --> 00:23.000
[Backend systems and integrations. An enquiry travels from website through API to business tools.]

00:23.000 --> 00:27.000
[The interfaces separate and converge. The exact folded violet and silver Idiomorph emblem appears. The music resolves.]

00:27.000 --> 00:32.000
IDIOMORPH STUDIO.
From ideas to what’s next.
[The closing signature fades into silence.]
`)
console.log('Web exports, responsive posters and captions complete.')
