﻿import {startServer} from './serve.mjs'
import {chromium} from '../../browser-tool.mjs'
import {writeFile} from 'node:fs/promises'
const server=await startServer(4196),browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']})
try{const page=await browser.newPage();await page.goto('http://127.0.0.1:4196/recovery-v4/source/film.html');await page.waitForFunction(()=>window.filmReady);const data=await page.evaluate(()=>window.drawPoster());await writeFile(new URL('../output/poster-clean.png',import.meta.url),Buffer.from(data,'base64'));console.log('Clean official-artwork poster created.')}finally{await browser.close();server.close()}
