﻿from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json
ROOT=Path(__file__).resolve().parents[3]
WORK=ROOT/'studio-workspace'
V4=WORK/'recovery-v4'
TARGET=ROOT/'frontend/docs/idiomorph-continuum-v4-source.zip'
files=set()
def add(p):
 p=p.resolve();p.relative_to(ROOT.resolve())
 if p.is_file():files.add(p)
for name in ['package.json','package-lock.json','serve.mjs','browser-tool.mjs']:add(WORK/name)
for folder in ['fonts','licenses']:
 for p in (WORK/folder).rglob('*'):add(p)
for name in ['IdiomorphLogo.png','provenance.json']:add(WORK/'brand'/name)
for p in (V4/'source').glob('*'):
 if p.suffix in {'.mjs','.html','.py'}:add(p)
for name in ['README.md','RECOVERY.md']:add(V4/name)
add(V4/'output/idiomorph-continuum-v4-sound.wav')
for name in ['before/inventory.json','ANIMATIC_REVIEW.md','browser/results.json','lighthouse/lighthouse-summary.json','media/media-results.json','editor-check.json']:add(V4/'evidence'/name)
for p in (ROOT/'frontend/src/features/studio').glob('*'):add(p)
for p in (ROOT/'frontend/public/studio/recovery').glob('*'):
 if p.suffix in {'.webp','.vtt'}:add(p)
add(ROOT/'frontend/docs/STUDIO_RECOVERY_V4.md')
manifest=[{'file':str(p.relative_to(ROOT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)]
with ZipFile(TARGET,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,p.relative_to(ROOT))
 z.writestr('V4-SOURCE-MANIFEST.json',json.dumps(manifest,indent=2))
with ZipFile(TARGET) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files)+1
result={'file':str(TARGET),'bytes':TARGET.stat().st_size,'entries':len(files)+1,'sha256':hashlib.sha256(TARGET.read_bytes()).hexdigest(),'crcVerified':True,'excludes':['tool binaries','node_modules','render caches','historical masters','finished movie exports']}
(V4/'evidence/source-archive.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
