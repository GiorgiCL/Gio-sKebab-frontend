﻿import {createServer} from 'node:http'
import {createReadStream} from 'node:fs'
import {stat} from 'node:fs/promises'
import {resolve,sep,extname} from 'node:path'
import {fileURLToPath} from 'node:url'
const root=fileURLToPath(new URL('../../',import.meta.url))
export function startServer(port=4195){
 const server=createServer(async(req,res)=>{
  try{
   const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname),file=resolve(root,pathname==='/'?'recovery-v4/source/film.html':pathname.slice(1))
   if(!file.startsWith(resolve(root)+sep)){res.writeHead(403);res.end();return}
   const info=await stat(file);if(!info.isFile()){res.writeHead(404);res.end();return}
   const mime={'.html':'text/html; charset=utf-8','.mjs':'text/javascript','.js':'text/javascript','.woff2':'font/woff2','.png':'image/png','.webp':'image/webp','.mp4':'video/mp4','.webm':'video/webm','.wav':'audio/wav','.mp3':'audio/mpeg','.vtt':'text/vtt'}
   const headers={'Content-Type':mime[extname(file)]||'application/octet-stream','Accept-Ranges':'bytes','Cache-Control':'no-store'}
   let start=0,end=info.size-1,status=200
   if(req.headers.range){const match=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range);if(!match){res.writeHead(416,{'Content-Range':`bytes */${info.size}`});res.end();return}start=match[1]?Number(match[1]):Math.max(0,info.size-Number(match[2]));end=match[1]&&match[2]?Math.min(end,Number(match[2])):end;if(start>end||start>=info.size){res.writeHead(416,{'Content-Range':`bytes */${info.size}`});res.end();return}status=206;headers['Content-Range']=`bytes ${start}-${end}/${info.size}`}
   headers['Content-Length']=String(end-start+1);res.writeHead(status,headers);if(req.method==='HEAD'){res.end();return}const stream=createReadStream(file,{start,end});stream.on('error',()=>res.destroy());stream.pipe(res)
  }catch(error){res.writeHead(error instanceof URIError?400:404);res.end()}
 })
 return new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',()=>resolve(server))})
}
if(process.argv[1]===fileURLToPath(import.meta.url)){await startServer(Number(process.env.FILM_PORT||4195));console.log(`Editable film: http://127.0.0.1:${process.env.FILM_PORT||4195}/`)}
