import { spawn } from 'node:child_process'
import { mkdir,writeFile } from 'node:fs/promises'
import { once } from 'node:events'
import { fileURLToPath } from 'node:url'
import ffmpeg from 'ffmpeg-static'
import { startServer } from './serve.mjs'
import { chromium } from '../../browser-tool.mjs'
const mode=process.argv.includes('--animatic')?'animatic':process.argv.includes('--stills')?'stills':'final'
const out=new URL('../output/',import.meta.url);await mkdir(out,{recursive:true})
const server=await startServer(Number(process.env.FILM_PORT || 4195)),browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-background-networking']})
try{
 const page=await browser.newPage({viewport:{width:1920,height:1080}});page.on('pageerror',e=>{throw e});await page.goto(`http://127.0.0.1:${process.env.FILM_PORT || 4195}/recovery-v4/source/film.html`);await page.waitForFunction(()=>window.filmReady)
 const times=[.8,2.8,4.7,6.5,9.2,11.5,13.5,15.5,17.5,19.5,21.5,23.2,24.2,25.2,26.2,28.5,31]
 for(const t of times){await page.evaluate(t=>window.draw(t),t);const png=await page.evaluate(()=>document.querySelector('#film').toDataURL('image/png').split(',')[1]);await writeFile(new URL(`review-${String(t).replace('.','_')}.png`,out),Buffer.from(png,'base64'))}
 if(mode==='stills'){console.log('17 full-resolution review frames written.');}
 else{
  const fps=mode==='animatic'?8:30,size=mode==='animatic'?['-vf','scale=960:540']:['-vf','scale=1920:1080:in_range=full:out_range=tv:out_color_matrix=bt709','-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709']
  const args=['-y','-hide_banner','-f','image2pipe','-vcodec','mjpeg','-framerate',String(fps),'-i','pipe:0',...size,'-an','-c:v','libx264','-preset',mode==='animatic'?'fast':'medium','-crf',mode==='animatic'?'22':'16','-pix_fmt','yuv420p','-movflags','+faststart',fileURLToPath(new URL(`idiomorph-continuum-v4-${mode}-picture.mp4`,out))]
  const encoder=spawn(ffmpeg,args,{windowsHide:true,stdio:['pipe','ignore','pipe']});let log='';encoder.stderr.on('data',b=>{log=(log+b).slice(-4000)});encoder.stdin.on('error',()=>{});const done=once(encoder,'exit');const start=Date.now()
  for(let frame=0;frame<32*fps;frame++){const jpg=await page.evaluate(t=>window.draw(t),frame/fps);if(!encoder.stdin.write(Buffer.from(jpg,'base64')))await once(encoder.stdin,'drain');if(frame%(fps*2)===0)console.log(`${mode}: ${frame}/${32*fps}, ${Math.round((Date.now()-start)/1000)} s`)}
  encoder.stdin.end();const[code]=await done;if(code)throw Error(log);console.log(mode+' picture complete')
 }
}finally{await browser.close();server.close()}
