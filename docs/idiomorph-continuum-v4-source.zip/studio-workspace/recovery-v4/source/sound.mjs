// Original composition/synthesis. No v3 audio, stock recording, sample or library.
// Broad slow pad voicings, restrained felt notes, filtered air and a closing motif.
import { mkdir,writeFile } from 'node:fs/promises'
const rate=48000,seconds=32,N=rate*seconds,L=new Float64Array(N),R=new Float64Array(N),TAU=Math.PI*2
const clamp=x=>Math.min(1,Math.max(0,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)},span=(t,a,b)=>ease((t-a)/(b-a)),hz=m=>440*2**((m-69)/12)
function addVoice(at,length,midi,amp,pan=0,kind='pad'){
 const f=hz(midi),start=Math.floor(at*rate),end=Math.min(N,Math.ceil((at+length)*rate)),a=Math.cos((pan+1)*Math.PI/4),b=Math.sin((pan+1)*Math.PI/4)
 for(let i=start;i<end;i++){const age=(i-start)/rate,t=i/rate;const env=kind==='pad'?span(age,0,1.5)*(1-span(age,length-2,length)):span(age,0,.025)*Math.exp(-age*(kind==='bell'?1.45:2.8))*(1-span(age,length-.3,length));const mod=1+.00012*Math.sin(age*2.1+f),fund=Math.sin(TAU*f*age*mod),detuned=Math.sin(TAU*f*1.0015*age+.31),upper=Math.sin(TAU*f*2.001*age)*.14+Math.sin(TAU*f*3.002*age)*.026;const value=(fund*.6+detuned*.22+upper)*env*amp;L[i]+=value*a;R[i]+=value*b}
}
// Musical development follows the four film acts; overlapping releases connect harmony.
const chords=[{at:0,len:7,notes:[50,57,60,64],amp:.04},{at:4.7,len:9,notes:[46,53,57,62],amp:.046},{at:11.3,len:9,notes:[41,53,57,60,64,67],amp:.038},{at:17.4,len:7.7,notes:[48,55,58,62,67],amp:.041},{at:22.4,len:6.6,notes:[38,50,57,62,64],amp:.043},{at:25.9,len:6.1,notes:[50,57,61,64,66],amp:.034}]
for(const chord of chords)chord.notes.forEach((m,i)=>addVoice(chord.at,chord.len,m,chord.amp,(i/(chord.notes.length-1)-.5)*1.4))
for(const[at,midi,amp,pan]of[[1.1,74,.047,-.22],[5.2,69,.034,.3],[8.5,65,.028,-.3],[12.7,69,.042,-.25],[14.4,72,.035,.15],[16.1,76,.032,.3],[18.2,74,.034,-.1],[20.2,79,.032,.22],[23.4,69,.044,-.2],[26.25,74,.065,-.2],[26.56,81,.043,.2],[27.1,78,.033,-.05]])addVoice(at,4.5,midi,amp,pan,'bell')
// Low transient energy: a shaped, pitched bloom rather than impact/crackle effects.
for(const at of [4.45,11.1,22.7,26])addVoice(at,2.8,38,.035,0,'felt')
let seed=8191,low=0,slow=0
for(let i=0;i<N;i++){const t=i/rate;seed=(Math.imul(seed,1664525)+1013904223)>>>0;const noise=seed/2147483648-1;low=low*.975+noise*.025;slow=slow*.998+noise*.002
 let air=(low-slow)*.055*span(t,.1,3)*(1-span(t,28.2,31.5))
 for(const at of [4.5,10.9,22.8,25.8]){const env=Math.exp(-(((t-at)/.62)**2));air+=(low-slow)*env*.18}
 L[i]+=air*(.8+.15*Math.sin(t*.6));R[i]+=air*(.8-.15*Math.sin(t*.6))
}
// A small diffuse stereo room; distinct delays prevent a repetitive digital echo.
for(const[delay,gain]of[[.113,.17],[.179,.14],[.257,.11],[.371,.085],[.523,.065],[.719,.04]]){const shift=Math.round(delay*rate);for(let i=N-1;i>=shift;i--){L[i]+=R[i-shift]*gain;R[i]+=L[i-shift]*gain*.93}}
const bytes=Buffer.alloc(44+N*4);bytes.write('RIFF');bytes.writeUInt32LE(bytes.length-8,4);bytes.write('WAVEfmt ',8);bytes.writeUInt32LE(16,16);bytes.writeUInt16LE(1,20);bytes.writeUInt16LE(2,22);bytes.writeUInt32LE(rate,24);bytes.writeUInt32LE(rate*4,28);bytes.writeUInt16LE(4,32);bytes.writeUInt16LE(16,34);bytes.write('data',36);bytes.writeUInt32LE(N*4,40)
let peak=0
for(let i=0;i<N;i++){const t=i/rate,fade=span(t,0,.15)*(1-span(t,30.4,31.95));const l=Math.tanh(L[i])*fade,r=Math.tanh(R[i])*fade;peak=Math.max(peak,Math.abs(l),Math.abs(r));bytes.writeInt16LE(Math.round(l*32767),44+i*4);bytes.writeInt16LE(Math.round(r*32767),46+i*4)}
await mkdir(new URL('../output/',import.meta.url),{recursive:true});await writeFile(new URL('../output/idiomorph-continuum-v4-sound-raw.wav',import.meta.url),bytes);console.log(JSON.stringify({seconds,rate,channels:2,peakDBFS:20*Math.log10(peak)}))
