import { createServer } from 'node:http'
import { readFile, writeFile, mkdtemp, mkdir } from 'node:fs/promises'
import { join, extname, resolve } from 'node:path'
import { tmpdir } from 'node:os'
import { chromium } from '../../browser-tool.mjs'
import assert from 'node:assert/strict'

const dist = resolve('frontend/dist')
const output = resolve('studio-workspace/recovery-v4/evidence/existing-seo')
await mkdir(output, { recursive: true })
let mode = 'no-email'
const profile = { displayName: "Gio's Kebab", description: 'Restaurant preview', address: 'Restaurant fixture address', phone: '+37060000000', email: null, googleMapsUrl: 'https://maps.google.com/', woltUrl: null, boltFoodUrl: null, instagramUrl: null, facebookUrl: null }
const server = createServer(async (req, res) => {
  const pathname = new URL(req.url, 'http://localhost').pathname
  if (pathname.startsWith('/api/')) {
    res.setHeader('Content-Type', 'application/json')
    if (pathname.startsWith('/api/admin/')) { res.writeHead(401); res.end('{}'); return }
    if (pathname.endsWith('/restaurant')) {
      if (mode === 'failure') { res.writeHead(503); res.end('{}'); return }
      res.end(JSON.stringify({ ...profile, email: mode === 'email' ? 'fixture@example.test' : null })); return
    }
    const data = pathname.endsWith('/menu') ? { categories: [{ id: 1, name: 'Fixture category', items: [{ id: 1, name: 'Fixture item', description: null, priceEur: 5, available: true, featured: false, imageUrl: 'http://unsafe-image.example.test/product.png' }] }] } : pathname.endsWith('/lunch-menu') ? { days: [] } : pathname.endsWith('/promotions') ? { promotions: [], timeZone: 'Europe/Vilnius' } : null
    if (!data) res.writeHead(503)
    res.end(JSON.stringify(data)); return
  }
  try {
    const file = pathname.startsWith('/assets/') || pathname.startsWith('/studio/') || ['/gios-kebab-logo.jpg','/robots.txt','/sitemap.xml'].includes(pathname) ? join(dist, pathname) : join(dist, 'index.html')
    const mime = { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html', '.woff2': 'font/woff2', '.woff': 'font/woff', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.png': 'image/png' }
    res.setHeader('Content-Type', mime[extname(file)] || 'application/octet-stream')
    res.end(await readFile(file))
  } catch { res.writeHead(404); res.end() }
})
await new Promise(r => server.listen(14194, '127.0.0.1', r))
const browser = await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
try {
  const page = await browser.newPage()
  const cdp = await page.context().newCDPSession(page)
  const errors = [], requests = []
  cdp.on('Runtime.exceptionThrown', e => errors.push(e.exceptionDetails.text))
  cdp.on('Network.requestWillBeSent', e => requests.push(e.request.url))
  const command = (method, params = {}) => cdp.send(method, params)
  const evaluate = async expression => {
    const value = await command('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
    assert.equal(value.exceptionDetails, undefined, 'Browser evaluation succeeded')
    return value.result.value
  }
  const waitFor = async expression => {
    for (let i = 0; i < 100; i++) { if (await evaluate(`Boolean(${expression})`)) return; await new Promise(r => setTimeout(r, 50)) }
    throw new Error(`Timed out: ${expression}`)
  }
  await command('Page.enable'); await command('Runtime.enable'); await command('Network.enable')
  const locales = ['lt', 'en', 'ru', 'ka']
  const metadata = async () => evaluate(`(() => ({
    title: document.title, lang: document.documentElement.lang,
    canonicals: [...document.querySelectorAll('link[rel=canonical]')].map(e => e.href),
    alternates: [...document.querySelectorAll('link[hreflang]')].map(e => [e.hreflang,e.href]),
    metas: Object.fromEntries([...document.querySelectorAll('meta[name],meta[property]')].map(e => [e.name || e.getAttribute('property'),e.content])),
    schemas: [...document.querySelectorAll('script[type="application/ld+json"]')].map(e => JSON.parse(e.textContent)),
    imageUrls: [...document.querySelectorAll('img')].map(e => e.getAttribute('src'))
  }))()`)
  const reports = []
  for (const locale of locales) for (const suffix of ['', '/privacy', '/legal']) {
    const path = `/${locale}${suffix}`
    await command('Page.navigate', { url: `http://127.0.0.1:14194${path}?source=check#section` })
    await waitFor(`document.querySelector('link[rel=canonical]')?.href === 'https://gioskebab.lt${path}' && document.querySelector('a[href^="tel:"]')`)
    const head = await metadata()
    assert.equal(head.lang, locale)
    assert.deepEqual(head.canonicals, [`https://gioskebab.lt${path}`])
    assert.deepEqual(head.alternates, [...locales.map(l => [l, `https://gioskebab.lt/${l}${suffix}`]), ['x-default', `https://gioskebab.lt/lt${suffix}`]])
    assert.equal(head.metas.robots, 'index, follow')
    assert.equal(head.metas['og:url'], head.canonicals[0])
    assert.equal(head.metas['og:title'], head.title)
    assert.equal(head.metas['twitter:title'], head.title)
    assert.equal(head.metas['og:description'], head.metas.description)
    assert.equal(head.metas['twitter:description'], head.metas.description)
    assert.equal(head.metas['og:image'], 'https://gioskebab.lt/gios-kebab-logo.jpg')
    assert.equal(head.metas['twitter:image'], head.metas['og:image'])
    assert.equal(head.metas['twitter:card'], 'summary')
    if (!suffix) {
      assert.equal(head.schemas.length, 1)
      const schema = head.schemas[0]
      assert.equal(schema['@type'], 'Restaurant'); assert.equal(schema.name, profile.displayName)
      assert.equal(schema.address, profile.address); assert.equal(schema.telephone, profile.phone)
      assert.equal(schema.url, head.canonicals[0]); assert.equal(schema.hasMenu, head.canonicals[0] + '#menu')
      for (const key of ['geo','aggregateRating','openingHours','openingHoursSpecification','priceRange','servesCuisine','sameAs','image','email']) assert.equal(schema[key], undefined)
      assert.ok(!head.imageUrls.some(url => url?.startsWith('http:')), 'Unsafe product images not rendered')
      // Navigate without a reload to ensure runtime metadata is replaced.
      await evaluate("document.querySelector('.footer-legal a').click()")
      await waitFor(`document.querySelector('link[rel=canonical]')?.href === 'https://gioskebab.lt/${locale}/privacy'`)
      assert.equal((await metadata()).schemas.length, 0)
    } else assert.equal(head.schemas.length, 0)
    reports.push({ path, head })
  }
  for (const path of ['/admin/login','/admin','/admin/menu','/lt/missing','/xx']) {
    await command('Page.navigate', { url: `http://127.0.0.1:14194${path}` })
    await waitFor("document.querySelector('meta[name=robots]')?.content === 'noindex, nofollow'")
    const head = await metadata()
    assert.deepEqual(head.canonicals, []); assert.deepEqual(head.alternates, []); assert.deepEqual(head.schemas, [])
    assert.equal(head.metas['og:title'], undefined); assert.equal(head.metas['twitter:card'], undefined)
    reports.push({ path, head })
  }
  // Admin -> public transition must not retain noindex.
  await command('Page.navigate', { url: 'http://127.0.0.1:14194/admin/login' })
  await waitFor("document.querySelector('meta[name=robots]')?.content === 'noindex, nofollow'")
  const navigated = await evaluate(`(() => { const a=[...document.querySelectorAll('a')].find(a => ['/lt','/en','/ru','/ka'].includes(a.pathname)); if (a) {a.click(); return true} return false })()`)
  assert.ok(navigated, 'Admin has public-site link')
  await waitFor("document.querySelector('meta[name=robots]')?.content === 'index, follow'")
  mode = 'failure'
  await command('Page.navigate', { url: 'http://127.0.0.1:14194/en' })
  await waitFor("document.querySelector('meta[name=robots]')?.content === 'index, follow'")
  assert.equal((await metadata()).schemas.length, 0, 'No invented structured data without profile')
  mode = 'email'; await command('Page.reload')
  await waitFor("document.querySelector('script[type=\"application/ld+json\"]')?.textContent.includes('fixture@example.test')")
  assert.equal((await metadata()).schemas[0].email, 'fixture@example.test')
  assert.deepEqual(errors, [])
  assert.deepEqual(requests.filter(url => /posthog|google-analytics|doubleclick|unsafe-image\.example/i.test(url)), [])
  await writeFile(join(output, 'seo-head-checks.json'), JSON.stringify(reports, null, 2))
  console.log(JSON.stringify({ result: 'PASS', metadataRoutes: reports.length, queryHashCanonical: 'pass', spaTransitions: 'pass', missingProfile: 'pass', optionalEmail: 'pass', unsafeImageRequests: 0, browserExceptions: 0 }, null, 2))
  await command('Browser.close')
} finally { await browser.close(); server.close() }
