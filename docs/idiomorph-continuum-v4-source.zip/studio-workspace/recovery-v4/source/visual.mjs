﻿import {chromium} from '../../browser-tool.mjs'
import {mkdir,writeFile} from 'node:fs/promises'
import {fileURLToPath} from 'node:url'
const out=new URL('../evidence/after/',import.meta.url);await mkdir(out,{recursive:true})
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
try{const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message))
 for(const[name,w,h]of[['desktop',1440,1000],['laptop',1280,800],['tablet',768,1024],['mobile',390,844],['small-mobile',320,740]]){
  await page.setViewportSize({width:w,height:h});await page.goto('http://127.0.0.1:4186/studio');await page.evaluate(()=>document.fonts.ready);await page.locator('.im-official-art img').evaluate(i=>i.decode());await page.waitForTimeout(1500)
  await page.screenshot({path:fileURLToPath(new URL(name+'-hero.png',out))})
  for(const id of ['expertise','approach','contact']){await page.locator('#'+id).scrollIntoViewIfNeeded();await page.waitForTimeout(100)}
  await page.evaluate(()=>scrollTo(0,0));await page.screenshot({path:fileURLToPath(new URL(name+'-full.png',out)),fullPage:true})
  for(const id of ['expertise','approach','contact']){await page.evaluate(id=>document.getElementById(id).scrollIntoView({behavior:'instant',block:'start'}),id);await page.waitForTimeout(150);await page.screenshot({path:fileURLToPath(new URL(name+'-'+id+'.png',out))})}
 }
 await writeFile(new URL('visual-errors.json',out),JSON.stringify(errors,null,2));console.log('Five viewports captured.',errors)
}finally{await browser.close()}
