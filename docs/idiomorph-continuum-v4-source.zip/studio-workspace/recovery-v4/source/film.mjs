// The Continuum v4. Recovered Three.js + Canvas production, newly authored choreography.
// No legacy logo geometry, Blender frames, human simulation, stock media or v3 audio.
import * as THREE from 'three'
export const DURATION=32
const canvas=document.querySelector('#film'),c=canvas.getContext('2d',{alpha:false})
const W=1920,H=1080,clamp=x=>Math.min(1,Math.max(0,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)},s=(t,a,b)=>ease((t-a)/(b-a)),mix=(a,b,p)=>a+(b-a)*p
const silver='#f5eef7',muted='#b7a5c7',violet='#c5a2eb'
const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,preserveDrawingBuffer:true})
renderer.setSize(1920,1080);renderer.setPixelRatio(1);renderer.outputColorSpace=THREE.SRGBColorSpace
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05
const world=new THREE.Scene(),camera=new THREE.PerspectiveCamera(37,16/9,.1,100)
const env=document.createElement('canvas');env.width=2048;env.height=1024
const ec=env.getContext('2d');ec.fillStyle='#131019';ec.fillRect(0,0,2048,1024)
for(const[x,y,w,h,col]of[[60,80,210,830,'#f5f0ee'],[570,40,560,200,'#d9cfdf'],[1350,190,65,710,'#b79ae8'],[1760,100,170,900,'#ffffff']]){const g=ec.createLinearGradient(x,0,x+w,0);g.addColorStop(0,'#131019');g.addColorStop(.14,col);g.addColorStop(.86,col);g.addColorStop(1,'#131019');ec.fillStyle=g;ec.fillRect(x,y,w,h)}
const envTexture=new THREE.CanvasTexture(env);envTexture.mapping=THREE.EquirectangularReflectionMapping
const pm=new THREE.PMREMGenerator(renderer),environment=pm.fromEquirectangular(envTexture);world.environment=environment.texture;envTexture.dispose();pm.dispose()
world.add(new THREE.HemisphereLight(0xe6d9f6,0x120a20,1.4))
const key=new THREE.DirectionalLight(0xf2e8ee,3.0);key.position.set(-4,6,7);world.add(key)
const rim=new THREE.DirectionalLight(0xa26be8,3.8);rim.position.set(4,1,-3);world.add(rim)
const light=new THREE.PointLight(0x8c4df4,22,20,2);light.position.set(0,0,2);world.add(light)
// Fine physically lit grain: original deterministic texture, never screen-space noise.
const grain=document.createElement('canvas');grain.width=512;grain.height=512
const gc=grain.getContext('2d'),pixels=gc.createImageData(512,512);let seed=173
for(let i=0;i<pixels.data.length;i+=4){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const n=120+(seed>>>25);pixels.data.set([n,n,n,255],i)}gc.putImageData(pixels,0,0)
gc.strokeStyle='#aaa';gc.lineWidth=.35;for(let i=0;i<120;i++){gc.beginPath();gc.moveTo(i*4.7,0);gc.lineTo(i*4.7+18,512);gc.stroke()}
const grainTexture=new THREE.CanvasTexture(grain);grainTexture.wrapS=grainTexture.wrapT=THREE.RepeatWrapping;grainTexture.repeat.set(3,3)
const metal=new THREE.MeshPhysicalMaterial({color:0xbab5c3,metalness:1,roughness:.27,bumpMap:grainTexture,bumpScale:.014,clearcoat:.2})
const purple=metal.clone();purple.color.set(0x7950b1);purple.roughness=.29
const edgeMaterial=new THREE.MeshPhysicalMaterial({color:0xd3c8df,metalness:1,roughness:.22})
function slabGeometry(w,h,d=.055){const sh=new THREE.Shape(),r=.04;sh.moveTo(-w/2+r,-h/2);sh.lineTo(w/2-r,-h/2);sh.quadraticCurveTo(w/2,-h/2,w/2,-h/2+r);sh.lineTo(w/2,h/2-r);sh.quadraticCurveTo(w/2,h/2,w/2-r,h/2);sh.lineTo(-w/2+r,h/2);sh.quadraticCurveTo(-w/2,h/2,-w/2,h/2-r);sh.lineTo(-w/2,-h/2+r);sh.quadraticCurveTo(-w/2,-h/2,-w/2+r,-h/2);return new THREE.ExtrudeGeometry(sh,{depth:d,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:.018,bevelThickness:.018,curveSegments:4})}
const system=new THREE.Group();world.add(system)
function plateGeometry(){
 const nx=12,ny=20,side=(nx+1)*(ny+1),vertices=[],indices=[]
 for(let z=0;z<2;z++)for(let y=0;y<=ny;y++)for(let x=0;x<=nx;x++)vertices.push((x/nx-.5)*.75,(y/ny-.5)*1.05,z===0?.035:-.035)
 for(let y=0;y<ny;y++)for(let x=0;x<nx;x++){const a=y*(nx+1)+x,b=a+1,d=a+nx+1,cc=d+1;indices.push(a,b,d,b,cc,d,a+side,d+side,b+side,b+side,d+side,cc+side)}
 const perimeter=[];for(let x=0;x<=nx;x++)perimeter.push(x);for(let y=1;y<=ny;y++)perimeter.push(y*(nx+1)+nx);for(let x=nx-1;x>=0;x--)perimeter.push(ny*(nx+1)+x);for(let y=ny-1;y>0;y--)perimeter.push(y*(nx+1))
 for(let k=0;k<perimeter.length;k++){const a=perimeter[k],b=perimeter[(k+1)%perimeter.length];indices.push(a,a+side,b,b,a+side,b+side)}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));g.setIndex(indices);g.computeVertexNormals();return g
}
const panels=Array.from({length:24},(_,i)=>{const geo=plateGeometry(),attribute=geo.attributes.position,base=Float32Array.from(attribute.array);const mesh=new THREE.Mesh(geo,i%4===0?purple:metal);mesh.userData.base=base;system.add(mesh);return mesh})
const spark=new THREE.Mesh(new THREE.OctahedronGeometry(.3,0),new THREE.MeshPhysicalMaterial({color:0x9155e5,metalness:.8,roughness:.19,emissive:0x5a20a0,emissiveIntensity:.5}));world.add(spark)
const wires=new THREE.Group();world.add(wires)
const wireMat=new THREE.LineBasicMaterial({color:0x9c72c4,transparent:true,opacity:.4})
const connections=[]
for(let i=0;i<24;i++){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(new Float32Array(6),3));const l=new THREE.Line(g,wireMat);wires.add(l);connections.push(l)}
const logo=new Image();logo.src='/brand/IdiomorphLogo.png'
const logoReady=logo.decode()
function text(ctx,str,x,y,size=24,font='DM',color=silver,align='left'){ctx.font=`${size}px ${font}`;ctx.fillStyle=color;ctx.textAlign=align;ctx.fillText(str,x,y)}
function spaced(ctx,str,x,y,size=14,tracking=3,color=muted,align='left'){ctx.save();ctx.font=`${size}px DM`;let width=[...str].reduce((a,l)=>a+ctx.measureText(l).width+tracking,0)-tracking;let xx=x-(align==='center'?width/2:align==='right'?width:0);ctx.fillStyle=color;for(const l of str){ctx.fillText(l,xx,y);xx+=ctx.measureText(l).width+tracking}ctx.restore()}
function box(ctx,x,y,w,h,fill,stroke=null,r=0){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1.3;ctx.stroke()}}
function line(ctx,x,y,x2,y2,color='#a893b5',width=1){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x2,y2);ctx.stroke()}
const textures=[]
function screen(w,h){const cv=document.createElement('canvas');cv.width=w;cv.height=h;const texture=new THREE.CanvasTexture(cv);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=renderer.capabilities.getMaxAnisotropy();textures.push(texture);return{cv,ctx:cv.getContext('2d'),texture}}
const site=screen(1100,760),app=screen(1000,660),api=screen(1100,310)
const views=[site,app,api].map((surface,i)=>{const g=new THREE.Group();const size=[[4.9,3.385],[4.35,2.871],[4.35,1.226]][i];g.add(new THREE.Mesh(slabGeometry(...size,.06),edgeMaterial));const face=new THREE.Mesh(new THREE.PlaneGeometry(...size),new THREE.MeshBasicMaterial({map:surface.texture,toneMapped:false}));face.position.z=.083;g.add(face);world.add(g);return g})
const surfaces=[site,app,api],sizes=[[4.9,3.385],[4.35,2.871],[4.35,1.226]],centers=[[-2.45,.1,.22],[2.38,.75,-.1],[2.38,-1.55,.2]]
panels.forEach((p,i)=>{const n=Math.floor(i/8),col=i%4,row=Math.floor((i%8)/4),tex=surfaces[n].texture.clone();tex.repeat.set(.25,.5);tex.offset.set(col*.25,row===0?.5:0);const face=new THREE.Mesh(new THREE.PlaneGeometry(.75,1.05),new THREE.MeshBasicMaterial({map:tex,toneMapped:false,transparent:true,opacity:0}));face.position.z=.1;p.add(face);p.userData.face=face;p.userData.tex=tex})
function drawSite(t){
 const ctx=site.ctx,p=s(t,12.5,15),w=1100,h=760
 ctx.fillStyle='#e9e3dd';ctx.fillRect(0,0,w,h)
 spaced(ctx,'FORM / FIELD',58,64,17,4,'#463749');text(ctx,'Objects for a considered life',1042,64,15,'DM','#645269','right');line(ctx,58,92,1042,92,'#b5a6b8')
 text(ctx,'A different',55,238,101,'Instrument','#342939');text(ctx,'point of view.',55,343,101,'Instrument','#342939')
 text(ctx,'Beautifully useful. Quietly distinctive.',58,397,23,'DM','#68576c')
 box(ctx,59,449,400,222,mixColor('#cfc3cf','#3a2d44',p))
 ctx.save();ctx.beginPath();ctx.rect(59,449,400,222);ctx.clip();ctx.translate(258,560);ctx.rotate(-.32)
 const gr=ctx.createLinearGradient(-180,0,180,0);gr.addColorStop(0,'#4d365f');gr.addColorStop(.28,'#cbbdd3');gr.addColorStop(.42,'#f0e9eb');gr.addColorStop(.47,'#776284');gr.addColorStop(.85,'#ad89c5');gr.addColorStop(1,'#36243d');ctx.fillStyle=gr
 ctx.beginPath();ctx.ellipse(0,0,185,74,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#3a2d44';ctx.beginPath();ctx.ellipse(0,0,128,29,0,0,Math.PI*2);ctx.fill();ctx.restore()
 text(ctx,'Made to be lived with.',515,498,40,'Instrument','#3f3048');text(ctx,'Purpose in every proportion.',518,547,21,'DM','#69576d');text(ctx,'A lasting place in the everyday.',518,579,21,'DM','#69576d')
 box(ctx,517,620,278,47,'#49354f');text(ctx,'Explore the collection',536,651,18,'DM','#f6edf5');text(ctx,'↗',769,652,23,'DM','#f6edf5')
 if(p<1){ctx.globalAlpha=1-p;ctx.fillStyle='#eee9e3';ctx.fillRect(30,115,1040,590);for(const[x,y,ww,hh]of[[58,150,600,75],[58,250,750,75],[58,375,720,28],[58,449,400,222],[518,455,480,38],[518,525,390,25],[518,575,310,25],[518,625,278,47]]){ctx.setLineDash([8,6]);box(ctx,x,y,ww,hh,null,'#9e8da8');ctx.setLineDash([])}ctx.globalAlpha=1}
 // A real layout adjustment resolves typography rhythm rather than a slide change.
 const cursor=s(t,14.5,15.25),cx=mix(920,835,cursor),cy=mix(687,637,cursor);pointer(ctx,cx,cy,.8)
 if(t>15.3){ctx.strokeStyle='#9d7baa';ctx.lineWidth=2;ctx.strokeRect(511,614,290,59)}
 site.texture.needsUpdate=true
}
function mixColor(a,b,p){return '#'+[1,3,5].map(i=>Math.round(mix(parseInt(a.slice(i,i+2),16),parseInt(b.slice(i,i+2),16),p)).toString(16).padStart(2,'0')).join('')}
function pointer(ctx,x,y,k=1){ctx.save();ctx.translate(x,y);ctx.scale(k,k);ctx.fillStyle='#f7edf9';ctx.strokeStyle='#4b365a';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,32);ctx.lineTo(9,23);ctx.lineTo(18,39);ctx.lineTo(25,35);ctx.lineTo(16,20);ctx.lineTo(29,18);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore()}
function drawApp(t){
 const ctx=app.ctx;ctx.fillStyle='#21192b';ctx.fillRect(0,0,1000,660)
 spaced(ctx,'WORKSPACE',48,57,17,3,'#d5c4df');text(ctx,'Project overview',48,135,55,'Instrument');text(ctx,'Less searching. More doing.',48,180,22,'DM',muted)
 const selected=t>=17.6
 for(const[x,label]of[[48,'All tasks'],[235,'Design'],[425,'Engineering']]){const on=selected?label==='Engineering':label==='All tasks';box(ctx,x,220,label==='Engineering'?210:166,52,on?'#6d4b84':'#30253b',on?'#b494cf':'#53415e',5);text(ctx,label,x+18,254,20,'DM',on?'#fff5ff':'#bfadd0')}
 const tasks=selected?[['Enquiry flow','Form & validation','Engineering'],['Data import','API & data mapping','Engineering']]:[['Homepage direction','Layout & typography','Design'],['Enquiry flow','Form & validation','Engineering'],['Data import','API & data mapping','Engineering']]
 const move=s(t,17.5,18.1)
 for(let i=0;i<tasks.length;i++){const y=307+i*87+(selected?(1-move)*20:0);box(ctx,48,y,904,72,'#2c2235','#50405b',5);text(ctx,tasks[i][0],72,y+31,24);text(ctx,tasks[i][1],72,y+56,16,'DM',muted);text(ctx,tasks[i][2],927,y+42,17,'DM','#c4a0df','right')}
 text(ctx,`${tasks.length} tasks · ${selected?'Engineering':'All disciplines'}`,50,620,17,'DM','#ba9fca')
 pointer(ctx,mix(730,543,s(t,16.4,17.5)),mix(530,247,s(t,16.4,17.5)),.9)
 app.texture.needsUpdate=true
}
function drawApi(t){
 const ctx=api.ctx;ctx.fillStyle='#17121f';ctx.fillRect(0,0,1100,310)
 spaced(ctx,'BACKEND SYSTEMS & INTEGRATIONS',40,45,16,2.2,'#c2a4d6')
 for(const[x,label,sub]of[[40,'Website','Enquiry captured'],[410,'Backend API','Validated & routed'],[780,'Your tools','Ready to follow up']]){box(ctx,x,94,280,116,'#2c2137','#77588c',6);text(ctx,label,x+22,140,29,'Instrument');text(ctx,sub,x+22,178,17,'DM','#c7b3d5')}
 for(const x of [320,690]){line(ctx,x,152,x+90,152,'#a478c3',2);text(ctx,'›',x+53,161,28,'DM','#d6b0ed')}
 const p=s(t,19.4,21.5),x=40+p*1018;box(ctx,x,224,45,3,'#d6a6ff');text(ctx,p>.85?'A clear route from interaction to useful data.':'One request. Three purposeful steps.',40,277,20,'DM','#c8b0d7')
 api.texture.needsUpdate=true
}
function backdrop(t){c.fillStyle='#100b17';c.fillRect(0,0,W,H);const g=c.createRadialGradient(1070+Math.sin(t*.13)*60,490,40,1000,510,1130);g.addColorStop(0,'#392345');g.addColorStop(.43,'#21152d');g.addColorStop(1,'#0e0a14');c.fillStyle=g;c.fillRect(0,0,W,H)}
function setCamera(t){const a=s(t,0,5),focus=s(t,12,15),pan=s(t,15.8,18.5),returning=s(t,22,25.5);camera.position.set(mix(-.7,mix(-.45,.45,pan),focus)*(1-returning),mix(.25,.5,a)*(1-returning),mix(8.2,9.1,a));camera.lookAt(mix(0,mix(-.6,.9,pan),focus)*(1-returning),.03,0)}
// Three nested architectural spans: coherent load-bearing curves, depth and varying scale.
function panelTarget(i){const span=Math.floor(i/8),u=(i%8)/7;return new THREE.Vector3(mix(-3.6,3.6,u),Math.sin(u*Math.PI)*1.35-1.15+span*.85,Math.cos(u*Math.PI)*.55-span*.7)}
function tileTarget(i){const n=Math.floor(i/8),col=i%4,row=Math.floor((i%8)/4),[w,h]=sizes[n],[x,y,z]=centers[n];return new THREE.Vector3(x+(col-1.5)*w/4,y+(.5-row)*h/2,z)}
function logoTarget(i){const k=i<12?0:1,u=(i%12)/11;const x=k===0?mix(-.16,-.35,u)-Math.sin(u*Math.PI)*.85:mix(.1,.4,u)+Math.sin(u*Math.PI)*.75;return new THREE.Vector3(x,mix(1.75,-1.75,u)+(k===0?-.35:.35),.025*(i%12))}
export function draw(t){
 t=Math.max(0,Math.min(31.999,t));c.globalAlpha=1;backdrop(t);setCamera(t)
 const emerge=s(t,.25,2.1),fracture=s(t,3,6.2),architecture=s(t,6,9.6),interfaceArrival=s(t,10.5,13),collapse=s(t,22.6,25.6),finish=s(t,25.1,26.2)
 spark.visible=t<5.6;spark.scale.setScalar(mix(.08,2.35,s(t,.3,4.9))*(1-s(t,4,5.6)));spark.rotation.set(.1+t*.21,-.3+t*.16,.35+t*.12);spark.position.set(0,.13,0)
 spark.material.emissiveIntensity=.6+emerge*.4
 light.intensity=10+emerge*16;light.position.set(Math.sin(t*.24)*1.5,1.2,2)
 system.visible=t>2.8&&t<26.2;system.rotation.set(0,0,0)
 panels.forEach((p,i)=>{
  const theta=(i%8)/8*Math.PI*2,ring=Math.floor(i/8),initial=new THREE.Vector3(Math.cos(theta)*(.55+ring*.2),Math.sin(theta)*(.55+ring*.2),Math.sin(i*1.3)*.3)
  const arch=panelTarget(i),spread=initial.clone().multiplyScalar(2.3)
  const tile=tileTarget(i),position=initial.clone().lerp(spread,fracture).lerp(arch,architecture).lerp(tile,interfaceArrival)
  const gather=logoTarget(i);position.lerp(gather,collapse)
  p.position.copy(position)
  const arc=(i%8)/7
  p.rotation.set(mix(theta*.5,.3+Math.sin(arc*Math.PI)*.24,architecture)*(1-interfaceArrival)*(1-collapse),mix(theta+1.2,Math.cos(arc*Math.PI)*.9,architecture)*(1-interfaceArrival)*(1-collapse),mix(theta*.3,Math.cos(arc*Math.PI)*.55,architecture)*(1-interfaceArrival)*(1-collapse))
  const scale=s(t,2.8+i*.026,4.1+i*.026)*(1-finish)
  // Architecture's tiles flatten into the actual interface surfaces at matching positions.
  const n=Math.floor(i/8),[sw,sh]=sizes[n]
  p.scale.set(mix(mix(.55,1.12,architecture),sw/4/.75,interfaceArrival)*scale,mix(mix(.62,1.65,architecture),sh/2/1.05,interfaceArrival)*scale,1)
  p.visible=t<13||collapse>0
  if(collapse>0){p.scale.x*=mix(1,.2,collapse);p.scale.y*=mix(1,.62,collapse);p.rotation.z=mix(0,(i<12?-.55:.55)+Math.sin((i%12)/11*Math.PI)*.55,collapse)}
  const attribute=p.geometry.attributes.position,base=p.userData.base,curve=(1-s(t,10.5,12.1))*(1-collapse)*architecture
  for(let k=0;k<base.length;k+=3){attribute.array[k+2]=base[k+2]+Math.sin((base[k+1]+.525)/1.05*Math.PI)*.22*curve+base[k]*base[k+1]*.35*curve}
  attribute.needsUpdate=true;p.geometry.computeVertexNormals()
  p.userData.face.visible=t>12.1&&t<23.6;p.userData.face.material.opacity=s(t,12.1,12.9)*(1-s(t,22.6,23.6));p.userData.tex.needsUpdate=true
 })
 wires.visible=t>5.7&&t<12.7
 connections.forEach((l,i)=>{const p=panels[i].position,q=panels[(i+1)%24].position,arr=l.geometry.attributes.position.array;arr.set([p.x,p.y,p.z,q.x,q.y,q.z]);l.geometry.attributes.position.needsUpdate=true})
 wireMat.opacity=.34*s(t,5.7,7.5)*(1-s(t,10.5,12.7))
 if(t>10&&t<24){drawSite(t);drawApp(t);drawApi(t)}
 views.forEach((v,i)=>{const pos=centers[i];v.visible=t>=13&&t<22.6;v.position.set(...pos);v.rotation.set(0,0,0);v.scale.setScalar(1)})
 renderer.render(world,camera);c.save();c.globalAlpha=(1-finish)*s(t,0,.7);c.drawImage(renderer.domElement,0,0,W,H);c.restore()
 // The actual approved artwork resolves from two intersecting curved material apertures.
 if(t>24.9){const a=s(t,24.9,26.5),settle=s(t,25.8,28);const height=mix(790,650,settle),width=height,xx=960-width/2,yy=mix(90,55,settle);c.save();c.globalCompositeOperation='screen';c.globalAlpha=a;c.drawImage(logo,xx,yy,width,height);c.restore()}
 // Sparse editorial hierarchy; the object and continuous movement lead each act.
 const labelAlpha=s(t,.65,1.5)*(1-s(t,25.1,26.2));c.save();c.globalAlpha=labelAlpha;spaced(c,'IDIOMORPH / STUDIO',94,83,14,3);spaced(c,'THE CONTINUUM',1826,83,14,3,muted,'right');c.restore()
 if(t<5){c.save();c.globalAlpha=s(t,1.1,2)*(1-s(t,4,5));text(c,'Every possibility starts somewhere.',960,895,48,'Instrument',silver,'center');c.restore()}
 if(t>=5&&t<12){c.save();c.globalAlpha=s(t,5,5.8)*(1-s(t,11,12));spaced(c,'STRUCTURE',94,933,14,4,violet);text(c,'Give the idea a direction.',94,998,55,'Instrument');c.restore()}
 if(t>=12&&t<23){c.save();c.globalAlpha=s(t,12,12.8)*(1-s(t,22,23));const n=t<16?'Business websites':t<19?'Custom web applications':'Backend systems & integrations';text(c,n,94,983,48,'Instrument');spaced(c,'ORIGINAL INTERFACE CONCEPTS',1826,983,12,2,muted,'right');c.restore()}
 if(t>=26){const a=s(t,26,27);c.save();c.globalAlpha=a;spaced(c,'IDIOMORPH',960,802,60,16,silver,'center');spaced(c,'STUDIO',960,850,18,9,muted,'center');text(c,'From ideas to what’s next.',960,939,46,'Instrument',silver,'center');c.restore()}
 // End with a readable signature held through the last frame, never a black tail.
 return canvas.toDataURL('image/jpeg',.97).split(',')[1]
}
export const ready=Promise.all([logoReady,document.fonts.load('32px DM'),document.fonts.load('32px Instrument'),document.fonts.load('italic 32px Instrument')])

// A clean official-artwork poster avoids competing with the website's own captions.
export function drawPoster(){c.globalAlpha=1;backdrop(28.5);c.save();c.globalCompositeOperation='screen';c.drawImage(logo,550,65,820,820);c.restore();return canvas.toDataURL('image/png').split(',')[1]}
