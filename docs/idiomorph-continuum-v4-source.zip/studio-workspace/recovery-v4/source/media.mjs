import ffmpeg from 'ffmpeg-static'
import {spawn} from 'node:child_process'
import {mkdir,writeFile,stat} from 'node:fs/promises'
import {fileURLToPath} from 'node:url'
const dir=new URL('../output/',import.meta.url),evidence=new URL('../evidence/media/',import.meta.url),web=new URL('../../../frontend/public/studio/recovery/',import.meta.url)
await mkdir(evidence,{recursive:true});const path=u=>fileURLToPath(u)
async function run(args){return await new Promise((resolve,reject)=>{const p=spawn(ffmpeg,['-y','-hide_banner',...args],{windowsHide:true,stdio:['ignore','ignore','pipe']});let log='';p.stderr.on('data',b=>{log+=b});p.on('exit',code=>code?reject(Error(log)):resolve(log))})}
const animatic=process.argv.includes('--animatic'),name=animatic?'animatic':'master-1080p',master=new URL(`idiomorph-continuum-v4-${name}.mp4`,dir)
await run(['-v','error','-xerror','-i',path(master),'-f','null','-'])
await run(['-i',path(master),'-vf','fps=1/2,scale=480:270,tile=4x4','-frames:v','1',path(new URL(name+'-contact-sheet.png',evidence))])
for(const[t,label]of[[3,'spark-structure'],[10.8,'structure-interface'],[22.4,'interface-reveal']])await run(['-ss',String(t),'-i',path(master),'-t','4','-vf','fps=3,scale=400:225,tile=6x2','-frames:v','1',path(new URL(name+'-'+label+'.png',evidence))])
if(animatic){console.log('Animatic decoded; actual frame/transition contact sheets ready.');process.exit(0)}
const reports=[]
for(const file of [master,new URL('idiomorph-continuum-v4-720p.mp4',web),new URL('idiomorph-continuum-v4-720p.webm',web),new URL('idiomorph-continuum-v4-sound.wav',dir)]){
 await run(['-v','error','-xerror','-i',path(file),'-f','null','-'])
 const info=await run(['-i',path(file),'-af','loudnorm=I=-18:TP=-1.5:LRA=9:print_format=json','-f','null','-'])
 const sound=JSON.parse(info.match(/\{\s*"input_i"[\s\S]*?\}/)[0]);reports.push({file:path(file),bytes:(await stat(file)).size,duration:info.match(/Duration: ([\d:.]+)/)?.[1],streams:info.split('\n').filter(l=>/Stream #0:/.test(l)),sound})
}
await writeFile(new URL('media-results.json',evidence),JSON.stringify(reports,null,2));console.log(JSON.stringify(reports,null,2))
