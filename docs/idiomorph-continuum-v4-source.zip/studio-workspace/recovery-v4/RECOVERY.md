# Historical recovery — recorded before implementation

Frontend began clean at `355d5d2` on development. The parent is not a Git repository. Applicable instructions: frontend/AGENTS.md; no other AGENTS.md in the video workspace. No backend work needed.

## Surviving versions

1. `b9c2b50`: original 32-second abstract film. Exact surviving master: `../refinement/before/idiomorph-master-1080p.mp4` (5,190,408 bytes). Original scene.mjs, sound.mjs, render/encode scripts, README and web exports survive together. Root scene.mjs and sound.mjs are also historical originals. Hashes: evidence/before/inventory.json.
2. `17df643`: second 32-second Canvas illustration iteration, supplied logo and explorer. The reported `../output/idiomorph-master-1080p.mp4` exists but is THIS later version. Original-named ZIP/report were updated here; Git retains original versions.
3. `355d5d2`: rejected 42-second Blender hand/pencil version. Packed .blend, source, master, previews and animatic survive under ../definitive-v3/. All preserved.

## Exact original pipeline

Three.js 0.180.0, deterministic JavaScript/Canvas 2D, local DM Sans and Instrument Serif, Playwright/installed Chrome frame capture, FFmpeg 6.0 via ffmpeg-static 5.2.0. Original JS stereo synthesis, 48 kHz. Three.js renders metal with PMREM reflections from authored softbox environment and sectional ribbon geometry. Canvas composes typography/interfaces. 960 frames at 30 fps, H.264/AAC master, MP4 and VP9/Opus exports.

Remotion was considered, NOT used: initial report explicitly cites unconfirmed headcount eligibility. video-shotcraft was not found in actual source/manifests. Blender belongs to the later production. Reuse the original unrestricted local workflow.

## Inspected and selected

Encoded contact sheets of both films, original scripts, approved logo and current browser screenshots inspected. Original strengths: dimensional metal, controlled violet, directional reflection, dramatic scale changes, sectional transformation and four-act progression. Improve its overlong tiny opening, flat grid and panel continuity. Its double-return emblem is obsolete: retain the current canonical folded emblem instead.

Rejected film: stiff hand/pencil relationship, hand remaining behind rising surfaces, simple cards, prolonged macros/reveal. Reuse neither its picture nor sound.

New direction: 32 seconds, spark → architectural panels → those panels becoming interfaces → convergence along the canonical silhouette → exact approved artwork. Separate names/directories; animatic reviewed before final render.

## Frontend diagnosis and plan

Preserve hero split, headline, serif/sans pair, logo, plum palette. Baselines: evidence/before/. 3D failure reproduced: Vite refuses dynamic import of public mjs; modal has fallback image, no canvas, disabled controls. Even when renderable the inferred mesh differs from the canonical artwork. Choose option B: official static logo, seamless compositing, brief entrance; no misleading controls.

Tokens: plum #17121e; lifted plum #292031; violet #9b71c2; silver #f6eff8; lilac #d7cbdc; paper #e5deea. Display: Instrument Serif; body: DM Sans. Shared gutters, legible text, tonal transitions, progressive project example, direct email CTA. Owner confirmed idiomorph.studio@gmail.com in this session. Keep publication disabled.

## Guidance actually consulted

- UI/UX Pro Max upstream SKILL.md and README; MIT. Apply focus/keyboard, target sizes, resilient text, media dimensions and motion preferences. No installation or database search claimed.
- Anthropic frontend-design SKILL.md and LICENSE.txt; Apache-2.0. Preserve distinctive brand/type, reduce labels, clarify content, purposeful motion, screenshot critique.
- Vercel Web Interface Guidelines command.md and LICENSE; MIT. Native links/actions, unobscured anchor/focus, honest feedback, captions/description, responsive images, reduced motion and performance checks.

No install scripts executed. Existing Three.js MIT, Playwright Apache-2.0, FFmpeg GPL tools and OFL fonts reused at €0. Full resource URLs and results belong in final report.
