import ffmpeg from 'ffmpeg-static'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { stat } from 'node:fs/promises'
const path=name=>fileURLToPath(new URL(name,import.meta.url))
async function run(args){await new Promise((resolve,reject)=>{const p=spawn(ffmpeg,['-y','-hide_banner',...args],{windowsHide:true,stdio:['ignore','ignore','pipe']});let log='';p.stderr.on('data',b=>{log=(log+b).slice(-3500)});p.on('error',reject);p.on('exit',code=>code===0?resolve():reject(new Error(log)))})}
const picture=path('./output/idiomorph-picture-1080p.mp4'),audio=path('./output/idiomorph-original-sound.wav')
await run(['-i',picture,'-i',audio,'-af','volume=1.6','-c:v','copy','-c:a','aac','-b:a','192k','-movflags','+faststart','-shortest',path('./output/idiomorph-master-1080p.mp4')])
console.log('Master: H.264 + AAC stereo / 1080p')
await run(['-i',picture,'-i',audio,'-af','volume=1.6','-vf','scale=1280:720','-c:v','libx264','-preset','slow','-crf','23','-c:a','aac','-b:a','128k','-movflags','+faststart','-shortest',path('../frontend/public/studio/idiomorph-film-720p.mp4')])
console.log('Website: H.264 + AAC / 720p / progressive faststart')
await run(['-i',picture,'-i',audio,'-af','volume=1.6','-vf','scale=1280:720','-c:v','libvpx-vp9','-b:v','0','-crf','33','-row-mt','1','-cpu-used','3','-c:a','libopus','-b:a','96k','-shortest',path('../frontend/public/studio/idiomorph-film-720p.webm')])
console.log('Website: VP9 + Opus / 720p')
await run(['-i',path('./output/poster.png'),'-vf','scale=1600:900','-c:v','libwebp','-quality','88','-frames:v','1',path('../frontend/public/studio/film-poster.webp')])
await run(['-i',path('./output/emblem.png'),'-vf','crop=980:1080:470:0,scale=784:864','-c:v','libwebp','-quality','90','-frames:v','1',path('../frontend/public/studio/emblem.webp')])
await run(['-i',path('./output/emblem.png'),'-vf','crop=980:1080:470:0,scale=392:432','-c:v','libwebp','-quality','88','-frames:v','1',path('../frontend/public/studio/emblem-small.webp')])
console.log('Poster and transparent chrome emblem: WebP')
for(const name of ['../frontend/public/studio/idiomorph-film-720p.mp4','../frontend/public/studio/idiomorph-film-720p.webm','../frontend/public/studio/film-poster.webp','../frontend/public/studio/emblem.webp'])console.log(name,((await stat(path(name))).size/1024/1024).toFixed(2)+' MiB')
