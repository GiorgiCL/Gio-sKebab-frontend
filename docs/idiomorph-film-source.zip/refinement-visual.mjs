import { chromium } from './browser-tool.mjs'
import { mkdir,writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
const out=new URL('./refinement/after/',import.meta.url);await mkdir(out,{recursive:true})
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
const report=[]
try{for(const[name,width,height]of[['desktop',1440,1000],['tablet',768,1024],['mobile',390,844],['small',320,740]]){
 const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:1}),errors=[],requests=[]
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});page.on('request',r=>requests.push(r.url()))
 await page.goto('http://127.0.0.1:4179/studio');await page.locator('h1').waitFor();await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(200)
 await page.screenshot({path:fileURLToPath(new URL(name+'-hero.png',out))})
 for(const id of ['film','expertise','approach','contact']){await page.locator('#'+id).scrollIntoViewIfNeeded();await page.waitForTimeout(150)}
 await page.locator('#approach img').first().evaluate(img=>img.decode());await page.evaluate(()=>scrollTo({top:0,behavior:'instant'}));await page.waitForTimeout(150)
 await page.screenshot({path:fileURLToPath(new URL(name+'-full.png',out)),fullPage:true})
 await page.addScriptTag({path:fileURLToPath(new URL('../.verification/frontend-tools/node_modules/axe-core/axe.min.js',import.meta.url))})
 const axe=await page.evaluate(()=>window.axe.run(document.querySelector('.im-studio'),{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa']}}))
 const entry={name,width,errors,overflow:await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),videoRequests:requests.filter(x=>/\.(mp4|webm)$/.test(x)),violations:axe.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))}))};report.push(entry)
 await writeFile(new URL(`axe-${name}.json`,out),JSON.stringify(axe,null,2));await page.close()
}}finally{await browser.close()}
await writeFile(new URL('visual-checks.json',out),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2))
