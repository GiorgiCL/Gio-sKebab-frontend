import assert from 'node:assert/strict'
import { writeFile } from 'node:fs/promises'
import { chromium } from './browser-tool.mjs'
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
try {
 const page=await browser.newPage(),warnings=[],errors=[]
 page.on('console',m=>{if(m.type()==='warning')warnings.push(m.text())});page.on('pageerror',e=>errors.push(e.message))
 await page.goto('http://127.0.0.1:4178/studio');await page.locator('h1').waitFor();await page.waitForTimeout(300)
 assert.equal(warnings.some(x=>x.includes('HydrateFallback')),false);assert.deepEqual(errors,[])
 await writeFile(new URL('./validation/loading-check.json',import.meta.url),JSON.stringify({warnings,errors,result:'PASS'},null,2));console.log('PASS: direct studio navigation in development has no hydration fallback warning or browser exception.')
} finally {await browser.close()}
