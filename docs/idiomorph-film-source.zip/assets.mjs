import ffmpeg from 'ffmpeg-static'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
const path=name=>fileURLToPath(new URL(name,import.meta.url))
for(const [from,filter,to,quality] of [
 ['./output/poster.png','scale=1600:900','../frontend/public/studio/film-poster.webp','88'],
 ['./output/emblem.png','crop=980:1080:470:0,scale=784:864','../frontend/public/studio/emblem.webp','90'],
 ['./output/emblem.png','crop=980:1080:470:0,scale=392:432','../frontend/public/studio/emblem-small.webp','88'],
])await new Promise((resolve,reject)=>{const p=spawn(ffmpeg,['-y','-v','error','-i',path(from),'-vf',filter,'-c:v','libwebp','-quality',quality,'-frames:v','1',path(to)],{windowsHide:true,stdio:'inherit'});p.on('exit',code=>code===0?resolve():reject(new Error('Asset encoding failed')))})
console.log('Final responsive still assets encoded.')
