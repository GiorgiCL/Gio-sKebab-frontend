import ffmpeg from 'ffmpeg-static'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
const path=name=>fileURLToPath(new URL(name,import.meta.url))
const targets=[
 ['./output/poster.png','scale=1600:900','film-poster.webp','88'],
 ['./output/poster.png','scale=640:360','film-poster-small.webp','86'],
]
for(const stage of ['discover','design','engineer','refine','deliver']){
 targets.push([`./output/process-${stage}.png`,'scale=960:540',`process-${stage}.webp`,'86'])
 targets.push([`./output/process-${stage}.png`,'scale=480:270',`process-${stage}-small.webp`,'86'])
}
for(const[from,filter,to,quality]of targets)execFileSync(ffmpeg,['-y','-v','error','-i',path(from),'-vf',filter,'-c:v','libwebp','-quality',quality,'-frames:v','1',path('../frontend/public/studio/'+to)],{windowsHide:true})
console.log('Responsive poster and five process illustrations encoded as WebP.')
