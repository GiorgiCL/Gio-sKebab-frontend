import { spawn } from 'node:child_process'
import { mkdir, writeFile } from 'node:fs/promises'
import { once } from 'node:events'
import { fileURLToPath } from 'node:url'
import ffmpeg from 'ffmpeg-static'
import { startServer } from './serve.mjs'
const { chromium } = await import('./browser-tool.mjs')
const output=new URL('./output/',import.meta.url), assets=new URL('../frontend/public/studio/',import.meta.url)
await mkdir(output,{recursive:true});await mkdir(assets,{recursive:true})
const server=await startServer()
const browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-background-networking','--no-first-run']})
const page=await browser.newPage({viewport:{width:1920,height:1080}})
page.on('pageerror',e=>console.error(e));await page.goto('http://127.0.0.1:4192');await page.waitForFunction(()=>window.filmReady)
async function png(time,name){await page.evaluate(t=>window.draw(t),time);const data=await page.evaluate(()=>document.querySelector('#film').toDataURL('image/png').split(',')[1]);await writeFile(new URL(name,output),Buffer.from(data,'base64'))}
try {
 for(const t of [2.8,6.9,11.8,17.9,21.8,25.6,28.5])await png(t,`frame-${t}.png`)
 for(const [name,time]of[['discover',3.9],['design',8.2],['engineer',18.9],['refine',22.5],['deliver',26.1]])await png(time,`process-${name}.png`)
 const emblem=await page.evaluate(()=>window.drawEmblem());await writeFile(new URL('emblem.png',output),Buffer.from(emblem,'base64'))
 await writeFile(new URL('poster.png',output),Buffer.from(await page.evaluate(()=>window.drawPoster()),'base64'))
 if(process.argv.includes('--stills')){console.log('Seven review frames, five process stills, poster and supplied-logo proof rendered.');}
 else {
  const encode=spawn(ffmpeg,['-y','-f','image2pipe','-vcodec','mjpeg','-framerate','30','-i','pipe:0','-an','-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-movflags','+faststart',fileURLToPath(new URL('idiomorph-picture-1080p.mp4',output))],{windowsHide:true,stdio:['pipe','ignore','pipe']})
  let log='';encode.stderr.on('data',b=>{log=(log+b).slice(-4000)});encode.stdin.on('error',()=>{})
  const complete=once(encode,'exit');const start=Date.now()
  for(let frame=0;frame<960;frame++){
   const jpg=await page.evaluate(t=>window.draw(t),frame/30)
   if(!encode.stdin.write(Buffer.from(jpg,'base64')))await once(encode.stdin,'drain')
   if(frame%90===0)console.log(`Rendered ${frame}/960 frames (${Math.round((Date.now()-start)/1000)}s elapsed)`)
  }
  encode.stdin.end();const [code]=await complete;if(code!==0)throw new Error(log)
  console.log('32-second 1920 × 1080 / 30 fps picture master rendered. Run encode.mjs to mux sound and generate web assets.')
 }
} finally {await browser.close();server.close()}
