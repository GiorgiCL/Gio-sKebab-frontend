import lighthouse from '../.verification/frontend-tools/node_modules/lighthouse/core/index.js'
import { chromium } from './browser-tool.mjs'
import { mkdir, writeFile } from 'node:fs/promises'
await mkdir(new URL('./refinement/reports/',import.meta.url),{recursive:true})
const results=[]
for(const formFactor of ['mobile','desktop']){
 const port=formFactor==='mobile'?19359:19360
 const chrome=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:[`--remote-debugging-port=${port}`,'--disable-gpu','--no-first-run']})
 try {
  const result=await lighthouse('http://127.0.0.1:4179/studio',{port,logLevel:'error',output:['html','json'],onlyCategories:['performance','accessibility','best-practices','seo'],formFactor,screenEmulation:{mobile:formFactor==='mobile',width:formFactor==='mobile'?390:1440,height:formFactor==='mobile'?844:1000,deviceScaleFactor:1,disabled:false},throttlingMethod:'simulate',...(formFactor==='desktop'?{throttling:{rttMs:40,throughputKbps:10240,cpuSlowdownMultiplier:1,requestLatencyMs:0,downloadThroughputKbps:0,uploadThroughputKbps:0}}:{})})
  await writeFile(new URL(`./refinement/reports/lighthouse-${formFactor}.html`,import.meta.url),result.report[0]);await writeFile(new URL(`./refinement/reports/lighthouse-${formFactor}.json`,import.meta.url),result.report[1])
  const lhr=result.lhr
  const summary={formFactor,version:lhr.lighthouseVersion,conditions:lhr.configSettings,scores:Object.fromEntries(Object.entries(lhr.categories).map(([k,v])=>[k,Math.round(v.score*100)])),metrics:Object.fromEntries(['first-contentful-paint','largest-contentful-paint','total-blocking-time','cumulative-layout-shift','speed-index','total-byte-weight'].map(id=>[id,{value:lhr.audits[id]?.numericValue,display:lhr.audits[id]?.displayValue}])),opportunities:Object.entries(lhr.audits).filter(([,v])=>v.score!==null&&v.score<1&&v.scoreDisplayMode!=='informative').map(([id,v])=>({id,title:v.title,score:v.score,display:v.displayValue}))}
  results.push(summary);console.log(JSON.stringify(summary,null,2))
 } finally {await chrome.close()}
}
await writeFile(new URL('./refinement/reports/lighthouse-summary.json',import.meta.url),JSON.stringify(results,null,2))
