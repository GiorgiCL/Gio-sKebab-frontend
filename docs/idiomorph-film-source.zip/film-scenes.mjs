// A film about making: original paper, pencil, typography and interface compositions.
// Deterministic Canvas 2D, 1920 × 1080 / 30 fps. No stock media or 3D runtime.
export const DURATION=32
const canvas=document.querySelector('#film'),c=canvas.getContext('2d')
const ink='#302739',paper='#e9e2d7',lilac='#d9cce4',white='#f4eff6',muted='#bfb1cc'
const clamp=v=>Math.max(0,Math.min(1,v)),ease=v=>{v=clamp(v);return v*v*(3-2*v)},span=(t,a,b)=>ease((t-a)/(b-a)),lerp=(a,b,t)=>a+(b-a)*t
const logo=new Image();logo.src='/brand/IdiomorphLogo.png'
const texture=document.createElement('canvas');texture.width=128;texture.height=128
const tc=texture.getContext('2d'),pixels=tc.createImageData(128,128);let seed=173
for(let i=0;i<pixels.data.length;i+=4){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const v=150+seed%80;pixels.data[i]=pixels.data[i+1]=pixels.data[i+2]=v;pixels.data[i+3]=28}tc.putImageData(pixels,0,0)
const pattern=c.createPattern(texture,'repeat')
function text(s,x,y,size=30,font='DM',color=ink,align='left',alpha=1){c.save();c.globalAlpha*=alpha;c.font=`${font==='Hand'?'italic ':''}${size}px ${font==='Hand'?'Instrument':font}`;c.fillStyle=color;c.textAlign=align;c.fillText(s,x,y);c.restore()}
function spaced(s,x,y,size=15,gap=3,color=muted,align='left'){c.save();c.font=`${size}px DM`;const width=[...s].reduce((v,a)=>v+c.measureText(a).width+gap,0)-gap;let px=x-(align==='center'?width/2:align==='right'?width:0);c.fillStyle=color;for(const a of s){c.fillText(a,px,y);px+=c.measureText(a).width+gap}c.restore()}
function line(x1,y1,x2,y2,color='#a499aa',width=1){c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke()}
function box(x,y,w,h,fill=paper,stroke=null,r=0){c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke()}}
function grain(alpha=.2){c.save();c.globalAlpha*=alpha;c.fillStyle=pattern;c.fillRect(0,0,1920,1080);c.restore()}
function desk(color='#261e2e'){box(0,0,1920,1080,color);grain(.16);const g=c.createLinearGradient(0,0,1920,1080);g.addColorStop(0,'#c9a5dd10');g.addColorStop(.6,'#0000');g.addColorStop(1,'#09060f60');c.fillStyle=g;c.fillRect(0,0,1920,1080)}
function sheet(x,y,w,h,angle,fn,fill=paper){c.save();c.translate(x+w/2,y+h/2);c.rotate(angle);c.translate(-w/2,-h/2);c.save();c.shadowColor='#08040d35';c.shadowBlur=58;c.shadowOffsetY=22;box(0,0,w,h,fill);c.restore();line(1,1,w-1,1,'#fff7');c.save();c.beginPath();c.rect(0,0,w,h);c.clip();grain(.28);fn(w,h);c.restore();c.restore()}
function stroke(points,progress=1,color='#66566f',width=2){if(progress<=0)return;c.save();c.strokeStyle=color;c.lineWidth=width;c.lineJoin='round';c.lineCap='round';const lengths=points.slice(1).map((p,i)=>Math.hypot(p[0]-points[i][0],p[1]-points[i][1]));let left=lengths.reduce((a,b)=>a+b,0)*clamp(progress);c.beginPath();c.moveTo(...points[0]);for(let i=0;i<lengths.length&&left>0;i++){const p=points[i],q=points[i+1],f=Math.min(1,left/lengths[i]);c.lineTo(lerp(p[0],q[0],f),lerp(p[1],q[1],f));left-=lengths[i]}c.stroke();c.restore()}
function roughRect(x,y,w,h,p=1,color='#76667b'){const pts=[];for(let k=0;k<=64;k++){const d=k/16;let a,b;if(d<=1){a=x+w*d;b=y}else if(d<=2){a=x+w;b=y+h*(d-1)}else if(d<=3){a=x+w*(3-d);b=y+h}else{a=x;b=y+h*(4-d)}pts.push([a+Math.sin(k*3.1)*1.2,b+Math.cos(k*2.3)*1.2])}stroke(pts,p,color,2)}
function pencil(x,y,angle=-.75){c.save();c.translate(x,y);c.rotate(angle);c.shadowColor='#0004';c.shadowBlur=9;c.shadowOffsetY=8;box(0,-7,257,14,'#ae8e6a');c.shadowBlur=0;box(0,-7,257,4,'#e1cbaa');box(0,3,257,4,'#6f5745');c.beginPath();c.moveTo(257,-7);c.lineTo(283,0);c.lineTo(257,7);c.fillStyle='#d8bf9c';c.fill();c.beginPath();c.moveTo(275,-2);c.lineTo(283,0);c.lineTo(275,2);c.fillStyle='#443b45';c.fill();box(-17,-7,17,14,'#a59ba4');c.restore()}
function brand(x,y,w,h,alpha=1,blend='screen'){c.save();c.globalAlpha*=alpha;c.globalCompositeOperation=blend;c.drawImage(logo,230,120,800,1000,x,y,w,h);c.restore()}
function label(s,color=muted){spaced('IDIOMORPH STUDIO',90,65,13,3,color);spaced(s,1830,65,13,2,color,'right')}
function footer(s,color=muted){spaced(s,90,1020,12,2,color);spaced('AN ORIGINAL STUDY IN MAKING',1830,1020,11,2,color,'right')}

// Hand-plotted lettering. Small variations and a pause before the question mark
// make this a deliberate human gesture, not a machine typing effect.
const handwriting=[[[0,0],[10,68],[28,24],[44,66],[62,0]],[[78,-4],[74,69],[79,34],[94,27],[104,65]],[[150,34],[137,27],[120,36],[116,55],[126,67],[143,57],[149,33],[147,64],[160,67]],[[184,2],[177,60],[184,69],[195,65]],[[165,24],[202,20]],[[231,31],[226,66]],[[232,12],[233,13]],[[260,66],[269,-2],[281,-7],[291,-1]],[[251,28],[284,24]],[[325,4],[338,-2],[353,5],[354,20],[340,34],[336,45]],[[336,62],[337,63]]]
function whatIf(x,y,size,progress){c.save();c.translate(x,y);c.scale(size,size);handwriting.forEach((p,i)=>stroke(p,clamp(progress*handwriting.length-i),'#594466',3));c.restore()}
function checkmark(x,y,p=1){stroke([[x,y],[x+10,y+12],[x+32,y-16]],p,'#665175',3)}

function question(t){
 desk();label('01 / A QUESTION')
 const move=span(t,0,4)*12
 sheet(650-move,140,1000,775,-.035,(w,h)=>{
  spaced('A PLACE TO BEGIN',70,71,13,3,'#796981');line(70,100,w-70,100,'#b5a9bb')
  whatIf(185,240,1.65,span(t,.45,2.85))
  const a=span(t,2.1,3.1);text('Who is it for?',100,495,28,'DM',ink,'left',a);text('What should feel easier?',100,552,28,'DM',ink,'left',span(t,2.5,3.5));text('What could it become?',100,609,28,'DM',ink,'left',span(t,2.9,3.9))
  stroke([[90,654],[340,658],[620,652],[740,655]],span(t,3.2,4.2),'#a78bb8',2)
  text('Start with the person.',650,699,30,'Hand','#7a6285','right',span(t,3.3,4.3))
 })
 text('A good idea',105,405,91,'Instrument',white);text('starts with',105,510,91,'Instrument',white);text('a question.',105,615,91,'Hand','#cfb7df')
 pencil(1515,915,-.9);footer('THINKING / LISTENING / FINDING THE PURPOSE')
}
function sketch(t){
 box(0,0,1920,1080,'#dcd2d0');grain(.35);label('02 / ROOM TO EXPLORE','#69596f')
 sheet(113,140,1060,760,-.035,(w,h)=>{
  spaced('A FIRST THOUGHT, GIVEN SHAPE',55,58,13,2,'#7a6a80')
  roughRect(70,120,660,425,span(t,4.5,6.1));line(70,165,730,165,'#9e8da7');stroke([[89,143],[120,145],[143,142]],span(t,5.3,5.8))
  stroke([[115,242],[450,240],[490,243]],span(t,5.2,6.2),'#49394f',3);stroke([[115,276],[340,274],[390,278]],span(t,5.6,6.6),'#49394f',3)
  roughRect(116,330,235,164,span(t,5.9,6.9),'#8c709c');stroke([[116,494],[188,416],[237,452],[294,364],[351,410]],span(t,6.2,7.3),'#9b82a6')
  for(let i=0;i<4;i++)stroke([[391,352+i*30],[626-i*21,353+i*30]],span(t,6.1+i*.1,7.3+i*.1),'#a597aa',2)
  roughRect(756,318,193,326,span(t,6.1,7.5));line(756,360,949,360,'#9b88a5');stroke([[781,404],[911,402]],span(t,6.8,7.8));roughRect(782,440,141,151,span(t,7,8.1),'#a188ae')
  text('A little less here.',116,607,34,'Hand','#8a6b94','left',span(t,6.9,7.9));stroke([[150,627],[260,642],[385,620],[425,555]],span(t,7.2,8.3),'#a48aae',2)
 })
 text('Explore the',1260,280,78,'Instrument',ink);text('possibilities.',1260,370,78,'Hand','#79518a')
 sheet(1280,492,425,272,.055,()=>{text('Keep the',43,83,45,'Instrument',ink);text('feeling.',43,137,51,'Hand','#80538f');stroke([[40,171],[180,177],[325,167]],span(t,7.2,8.4),'#a285ab',2);text('Make the next step clear.',43,220,19,'DM','#796681')},'#eddfb9')
 pencil(1280,890,-.16);footer('DISCOVERY BECOMES DIRECTION','#74617b')
}
function interfaceScene(t){
 box(0,0,1920,1080,'#d7c9df');grain(.26);label('03 / FINDING ITS OWN LANGUAGE','#65516e')
 const arrival=span(t,8.8,10.2),nudge=lerp(30,0,arrival)
 sheet(130,160+nudge,1220,680,-.018,()=>{
  spaced('AN INTERFACE STUDY',48,47,14,2,'#6a5e72');text('Explore   /   Contact',1167,47,16,'DM','#6a5e72','right');line(48,76,1172,76,'#c1b8c8')
  text('Make room',58,224,112,'Instrument',ink);text('for what matters.',58,340,100,'Hand','#6e4c80')
  text('A distinctive place for your business.',62,408,23,'DM','#716277');line(63,475,278,475,'#82608e');text('Start something  ↗',63,510,22,'DM',ink)
  box(760,104,411,525,'#15101d');brand(783,119,366,458,1,'source-over');text('An idea, with its own identity.',62,612,17,'DM','#807188')
 },'#f1eae8')
 const phone=span(t,10.3,11.9)
 c.save();c.globalAlpha*=phone;sheet(1442,255+(1-phone)*100,292,584,.035,()=>{box(0,0,292,584,'#f1eae8');line(20,47,272,47,'#b4a4be');text('Make room',25,112,47,'Instrument',ink);text('for what matters.',25,166,42,'Hand','#7b588c');box(25,203,242,301,'#15101d');brand(40,216,212,265,1,'source-over');text('A thoughtful next step.  ↗',25,551,15,'DM','#66516e')});c.restore()
 spaced('BUSINESS WEBSITES',130,918,17,4,'#5b4169');text('A presence that feels like you.',130,980,48,'Instrument',ink)
 spaced('ILLUSTRATIVE DESIGN CONCEPT',1810,1009,10,2,'#776181','right')
}
function build(t){
 desk('#2e2335');label('04 / MAKING IT WORK')
 text('Complex behind the scenes.',110,182,62,'Instrument',white);text('Effortless on the other side.',110,260,62,'Hand','#d7bfdf')
 sheet(124,338,1670,523,-.012,()=>{
  spaced('A WORKFLOW, SHAPED AROUND PEOPLE',48,54,13,2,'#7b6684')
  const labels=['A request','A clear next step','Ready to use'];const p=span(t,14.8,17.4)
  line(125,181,1490,181,'#bcabc5',2)
  labels.forEach((s,i)=>{const x=60+i*546;box(x,119,455,119,'#f5efed','#c6b9cd',2);text(s,x+28,166,32,'Instrument',ink);text(['Start with what you need.','Know where things stand.','Keep moving forward.'][i],x+28,204,18,'DM','#75617e');const a=span(t,14.6+i*.65,15.5+i*.65);c.save();c.globalAlpha*=a;checkmark(x+391,174,a);c.restore()})
  const x=110+p*1430;c.beginPath();c.arc(x,181,7,0,Math.PI*2);c.fillStyle='#9062a8';c.fill()
  const systems=span(t,17,18.7);c.save();c.globalAlpha*=systems
  stroke([[280,241],[280,331],[1390,331],[1390,241]],systems,'#b199bf',2)
  const nodes=['INTERFACE','APPLICATION','YOUR TOOLS'];nodes.forEach((s,i)=>{const x=130+i*529;box(x,298,349,67,'#e7dbe9','#a996b5',2);spaced(s,x+174,340,15,2,'#6e507d','center')})
  text('Your tools, working together.',830,439,31,'Hand','#806088','center');c.restore()
 })
 spaced('CUSTOM WEB APPLICATIONS',124,941,16,3,white);spaced('BACKEND SYSTEMS & INTEGRATIONS',1792,941,16,2,white,'right');footer('GOOD ENGINEERING MAKES ROOM FOR PEOPLE')
}
function refine(t){
 box(0,0,1920,1080,'#e9dedc');grain(.35);label('05 / THE PART THAT MAKES THE DIFFERENCE','#7c637d')
 const p=span(t,19.5,22.2);let x=224
 c.save();c.font='188px Instrument';c.fillStyle=ink;for(const char of 'Considered.'){c.fillText(char,x,515);x+=c.measureText(char).width+lerp(-7,2,p)}c.restore()
 line(170,530,1740,530,'#b79ebc');line(170,320,1740,320,'#cdb9ce')
 for(let i=0;i<18;i++)line(190+i*86,535,190+i*86,535+(i%2?13:22),'#a489aa')
 stroke([[1270,601],[1200,655],[995,665],[925,610]],span(t,20.2,21.6),'#9a73a6',2)
 text('Give it a little room.',1265,727,52,'Hand','#8b6298','right',span(t,20.8,21.8))
 text('Space. Rhythm. A feeling.',174,876,68,'Instrument',ink)
 spaced('REFINE UNTIL THE EXPERIENCE FEELS RIGHT.',177,950,16,3,'#79627f')
 pencil(1430,900,-.7);footer('SMALL DECISIONS. A DIFFERENT EXPERIENCE.','#7f6984')
}
function deliver(t){
 desk('#33263a');label('06 / FROM AN IDEA TO SOMETHING REAL')
 text('Ready for',130,330,111,'Instrument',white);text('real life.',130,460,125,'Hand','#dbc2e8')
 const labels=['Clear to use.','Considered in detail.','Made to move forward.'];labels.forEach((s,i)=>{const p=span(t,23.2+i*.35,24.2+i*.35);c.save();c.globalAlpha*=p;checkmark(148,592+i*76,p);text(s,210,604+i*76,29,'DM','#d0bfda');c.restore()})
 const reveal=span(t,23,25.8);c.save();c.beginPath();c.rect(1045,90,660*reveal,828);c.clip();brand(1105,100,600,750);c.restore()
 text('The idea is still yours.',130,889,38,'Instrument',white);text('Now it has somewhere to go.',130,944,38,'Hand','#c5a8d6')
}
function signature(t){
 desk('#18121f');brand(757,62,406,507,span(t,26.5,27.3))
 spaced('IDIOMORPH',960,704,55,13,white,'center');spaced('S T U D I O',960,762,17,7,muted,'center')
 text('Built to become more.',960,881,52,'Instrument','#ddcce8','center')
 line(825,944,1095,944,'#72537d');
}
const scenes=[{at:0,fn:question},{at:4.25,fn:sketch},{at:8.65,fn:interfaceScene},{at:14.1,fn:build},{at:19.25,fn:refine},{at:23,fn:deliver},{at:26.65,fn:signature}]
export function draw(t){
 t=Math.max(0,Math.min(32,t));c.setTransform(1,0,0,1,0,0);c.globalAlpha=1
 const index=scenes.findLastIndex(s=>t>=s.at),current=scenes[Math.max(index,0)]
 if(index>0&&t<current.at+.7)scenes[index-1].fn(t)
 c.save();c.globalAlpha=index>0?span(t,current.at,current.at+.7):1;current.fn(t);c.restore()
 const fade=1-span(t,31.2,32);if(fade<1){c.fillStyle=`rgba(20,14,26,${1-fade})`;c.fillRect(0,0,1920,1080)}
 return canvas.toDataURL('image/jpeg',.97).split(',')[1]
}
window.drawEmblem=()=>{c.clearRect(0,0,1920,1080);brand(580,40,800,1000,1,'source-over');return canvas.toDataURL('image/png').split(',')[1]}
window.drawPoster=()=>{c.globalAlpha=1;desk('#302438');sheet(145,148,995,722,-.055,()=>{spaced('IT STARTS WITH A QUESTION.',66,78,14,3,'#74627b');whatIf(120,220,1.7,1);roughRect(100,386,420,215,1,'#a492ad');line(100,423,520,423,'#b3a2bd');text('Thought, given form.',576,521,46,'Hand','#8b6598');stroke([[574,547],[800,557],[850,546]],1,'#b19abb',2)});brand(1220,76,545,681);pencil(1110,970,-.42);return canvas.toDataURL('image/png').split(',')[1]}
export const ready=Promise.all([document.fonts.load('32px DM'),document.fonts.load('32px Instrument'),document.fonts.load('italic 32px Instrument'),logo.decode()])
