import { chromium } from './browser-tool.mjs'
import { fileURLToPath } from 'node:url'
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
try {
 for(const width of [390,1440]){
  const page=await browser.newPage({viewport:{width,height:900}})
  await page.route('**/api/**',async route=>{const path=new URL(route.request().url()).pathname
   const data=path.endsWith('/restaurant')?{displayName:"Gio's Kebab",description:'Read-only footer review',address:'Fixture address',phone:'+37060000000',email:null,googleMapsUrl:'https://maps.google.com/',woltUrl:null,boltFoodUrl:null,instagramUrl:'https://www.instagram.com/',facebookUrl:null}:path.endsWith('/menu')?{categories:[]}:path.endsWith('/lunch-menu')?{days:[]}:path.endsWith('/promotions')?{promotions:[],timeZone:'Europe/Vilnius'}:null
   await route.fulfill({status:data?200:503,contentType:'application/json',body:JSON.stringify(data||{})})})
  await page.goto('http://127.0.0.1:4179/en');await page.locator('.footer-socials a').filter({hasText:'Instagram'}).waitFor();await page.evaluate(()=>document.fonts.ready)
  await page.locator('.site-footer').screenshot({path:fileURLToPath(new URL(`./validation/restaurant-footer-${width}.png`,import.meta.url))})
  await page.close()
 }
 console.log('Restaurant footer reviewed at desktop and mobile widths with read-only fixtures.')
} finally {await browser.close()}
