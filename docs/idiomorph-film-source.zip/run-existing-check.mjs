import { readFile,writeFile } from 'node:fs/promises'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
const script=(await readFile(new URL('../.verification/audit-browser.mjs',import.meta.url),'utf8')).replaceAll('9333','19365').replaceAll('4175','14193').replace("resolve('.verification')","resolve('studio-workspace/validation/existing-seo')")
const path=fileURLToPath(new URL('./validation/existing-seo-check.mjs',import.meta.url))
await writeFile(path,script)
const child=spawn(process.execPath,[path],{cwd:fileURLToPath(new URL('../',import.meta.url)),windowsHide:true,stdio:['ignore','pipe','pipe']})
let output='';child.stdout.on('data',b=>{output+=b;process.stdout.write(b)});child.stderr.on('data',b=>{output+=b;process.stderr.write(b)})
const timer=setTimeout(()=>{console.log('Legacy CDP harness timed out after 45s. The Playwright regression checks are independent.');child.kill()},45000)
child.on('exit',async code=>{clearTimeout(timer);await writeFile(new URL('./validation/existing-seo-run.txt',import.meta.url),output||'Legacy CDP harness timed out before reporting assertions.');process.exitCode=code??1})
