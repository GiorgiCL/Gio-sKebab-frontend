import { chromium } from '../.verification/frontend-tools/node_modules/playwright-core/index.mjs'
import { writeFile } from 'node:fs/promises'
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
const results=[]
for(const width of [1440,390]){
 const page=await browser.newPage({viewport:{width,height:1000}})
 await page.goto('http://127.0.0.1:4178/studio');await page.locator('.im-chrome').waitFor();await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(1300)
 await page.addScriptTag({path:new URL('../.verification/frontend-tools/node_modules/axe-core/axe.min.js',import.meta.url).pathname.slice(1)})
 const r=await page.evaluate(()=>window.axe.run(document.querySelector('.im-studio'),{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa']}}))
 results.push({width,violations:r.violations,passes:r.passes.length,incomplete:r.incomplete.map(x=>({id:x.id,impact:x.impact}))});await page.close()
}
await writeFile(new URL('./validation/axe-initial.json',import.meta.url),JSON.stringify(results,null,2));console.log(JSON.stringify(results.map(r=>({...r,violations:r.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))}))})),null,2));await browser.close()
