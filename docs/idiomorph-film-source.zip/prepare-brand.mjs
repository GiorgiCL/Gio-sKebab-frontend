import { mkdir,copyFile,readFile,writeFile } from 'node:fs/promises'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { resolve } from 'node:path'
import { createHash } from 'node:crypto'
import ffmpeg from 'ffmpeg-static'
const path=name=>fileURLToPath(new URL(name,import.meta.url))
const original=process.argv[2] ? resolve(process.argv[2]) : path('./brand/IdiomorphLogo.png')
await mkdir(new URL('./brand/',import.meta.url),{recursive:true})
if(resolve(original)!==resolve(path('./brand/IdiomorphLogo.png')))await copyFile(original,path('./brand/IdiomorphLogo.png'))
for(const [name,filter,quality]of[
 ['brand-logo.webp','crop=800:1000:230:120,scale=800:1000','90'],
 ['brand-logo-small.webp','crop=800:1000:230:120,scale=400:500','88'],
 ['brand-icon.webp','crop=800:1000:230:120,scale=96:120','90'],
])execFileSync(ffmpeg,['-y','-v','error','-i',original,'-vf',filter,'-c:v','libwebp','-quality',quality,'-frames:v','1',path('../frontend/public/studio/'+name)],{windowsHide:true})
execFileSync(ffmpeg,['-y','-v','error','-i',original,'-vf','crop=800:1000:230:120,scale=76:96,pad=96:96:10:0:color=black','-frames:v','1',path('../frontend/public/studio/brand-favicon.png')],{windowsHide:true})
const previous=JSON.parse(await readFile(path('./brand/provenance.json'),'utf8').catch(()=>'{}'))
await writeFile(path('./brand/provenance.json'),JSON.stringify({...previous,source:process.argv[2] ? original : previous.source || original,sha256:createHash('sha256').update(await readFile(original)).digest('hex'),sourceDimensions:[1254,1254],treatment:'Unmodified original retained. Web derivatives crop empty outer margins and resize; the artwork is unchanged.',authorization:'User supplied and explicitly requested this identity asset.'},null,2))
console.log('User-supplied logo preserved; responsive WebP and PNG favicon derivatives created.')
