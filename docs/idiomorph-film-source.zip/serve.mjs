import { createServer } from 'node:http'
import { readFile } from 'node:fs/promises'
import { extname, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(fileURLToPath(new URL('.', import.meta.url)))
export function startServer(port = 4192) {
  const server = createServer(async (req, res) => {
    const path = decodeURIComponent(new URL(req.url, 'http://localhost').pathname)
    const base = root
    const relative = path === '/' ? 'film.html' : path.slice(1)
    const file = resolve(base, relative)
    if (!file.startsWith(base + sep)) { res.writeHead(403); res.end(); return }
    try {
      const mime = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.woff2': 'font/woff2', '.png': 'image/png', '.webp': 'image/webp', '.mp4': 'video/mp4', '.wav': 'audio/wav' }
      res.setHeader('Content-Type', mime[extname(file)] || 'application/octet-stream')
      res.end(await readFile(file))
    } catch { res.writeHead(404); res.end() }
  })
  return new Promise(resolve => server.listen(port, '127.0.0.1', () => resolve(server)))
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  await startServer()
  console.log('Film source preview: http://127.0.0.1:4192')
}
