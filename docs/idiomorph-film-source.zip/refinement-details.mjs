import assert from 'node:assert/strict'
import {mkdir,writeFile} from 'node:fs/promises'
import {fileURLToPath} from 'node:url'
import {chromium} from './browser-tool.mjs'
const out=new URL('./refinement/details/',import.meta.url);await mkdir(out,{recursive:true})
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
const checks=[]
try{
 const page=await browser.newPage({viewport:{width:1440,height:1000}})
 await page.goto('http://127.0.0.1:4179/studio');await page.locator('h1').waitFor();await page.evaluate(()=>document.fonts.ready)
 const before=await page.locator('.im-symbol-left').evaluate(el=>getComputedStyle(el).transform)
 await page.locator('.im-symbol-button').hover();await page.waitForTimeout(800)
 const after=await page.locator('.im-symbol-left').evaluate(el=>getComputedStyle(el).transform)
 assert.notEqual(before,after);checks.push('Hero hover responds to the pointer')
 await page.locator('.im-symbol-button').click();await page.waitForTimeout(850);await page.screenshot({path:fileURLToPath(new URL('desktop-symbol-open.png',out))})
 await page.keyboard.press('Tab');await page.locator('.im-progress a').nth(2).focus();await page.waitForTimeout(350)
 const hint=await page.locator('.im-progress a').nth(2).evaluate(el=>getComputedStyle(el,'::after').opacity)
 assert.equal(hint,'1');checks.push('Chapter hint is visible on keyboard focus')
 await page.locator('#film').scrollIntoViewIfNeeded();await page.locator('.im-cinema img').evaluate(el=>el.decode())
 await page.locator('.im-cinema').hover();await page.waitForTimeout(850)
 assert.notEqual(await page.locator('.im-cinema img').evaluate(el=>getComputedStyle(el).transform),'none');checks.push('Poster hover has restrained feedback')
 await page.locator('#film').screenshot({path:fileURLToPath(new URL('desktop-film.png',out))})
 await page.locator('.im-expertise-tabs [role=tab]').nth(1).click();await page.getByRole('button',{name:'Move the idea forward'}).click()
 await page.locator('#expertise').screenshot({path:fileURLToPath(new URL('desktop-workflow.png',out))})
 await page.locator('.im-expertise-tabs [role=tab]').nth(2).click();await page.getByRole('button',{name:'Connect the system',exact:true}).click()
 await page.locator('#expertise').screenshot({path:fileURLToPath(new URL('desktop-connected.png',out))})
 await page.close()
 const mobile=await browser.newPage({viewport:{width:390,height:844}})
 await mobile.goto('http://127.0.0.1:4179/studio');await mobile.locator('h1').waitFor()
 await mobile.locator('#film').scrollIntoViewIfNeeded();await mobile.locator('.im-cinema img').evaluate(el=>el.decode())
 await mobile.locator('#film').screenshot({path:fileURLToPath(new URL('mobile-film.png',out))})
 assert.match(await mobile.locator('.im-cinema img').evaluate(el=>el.currentSrc),/poster-small/);checks.push('Mobile receives the small poster')
 await mobile.locator('#approach').scrollIntoViewIfNeeded();await mobile.locator('#approach img').first().evaluate(el=>el.decode())
 assert.match(await mobile.locator('#approach img').first().evaluate(el=>el.currentSrc),/discover-small/);checks.push('Mobile receives a small process still')
 await mobile.close()
}finally{await browser.close()}
await writeFile(new URL('results.json',out),JSON.stringify(checks,null,2));console.log(checks.join('\n'))
