# Idiomorph Studio — The Continuum

An original 32-second procedural advertisement. The silver double-return ribbon is the shared identity of the film and `/studio` page. No stock images, HDRIs, music, external models, generated raster service, or paid tool is used.

## Open and edit

The source is deliberately outside the production frontend. Node.js and a locally installed Chromium browser are required. Dependencies are pinned in `package-lock.json`. The commercially usable font files and their full OFL notices are included in `fonts/`.

```powershell
cd C:\Users\giorg\Desktop\kebab-shop\studio-workspace
npm ci
npm run preview
```

Open `http://127.0.0.1:4192`. The timeline slider scrubs the composition; Play previews motion. This editable preview does not play the separate sound track. `scene.mjs` contains the geometry, environment lighting, typesetting, compositions, and deterministic time-based choreography. `sound.mjs` synthesizes all sound locally. `film.html` is the editor shell.

`CHROME_PATH` can select another installed Chromium executable. The current default is `C:/Program Files/Google/Chrome/Application/chrome.exe`. Fonts load locally from this project's `fonts/` directory; the editable film source does not depend on the frontend being installed.

## Render

```powershell
npm run sound
npm run render
npm run encode
```

`render.mjs --stills` creates the review frames and identity stills without re-rendering the film. `assets.mjs` regenerates only the responsive WebP stills. A full render writes 960 deterministic frames directly to FFmpeg; intermediate frame sequences do not clutter the workspace. The final full render took about three minutes on this machine.

Outputs:

| Artifact | Location |
| --- | --- |
| 1920 × 1080, 30 fps, 32.000 s, H.264 + AAC stereo master | `output/idiomorph-master-1080p.mp4` |
| Picture-only editable intermediate | `output/idiomorph-picture-1080p.mp4` |
| Original 48 kHz stereo PCM synthesis | `output/idiomorph-original-sound.wav` |
| Browser MP4, H.264 + AAC, progressive faststart | `../frontend/public/studio/idiomorph-film-720p.mp4` |
| Browser WebM, VP9 + Opus | `../frontend/public/studio/idiomorph-film-720p.webm` |
| 1600 × 900 poster | `../frontend/public/studio/film-poster.webp` |
| Transparent 784 × 864 / 392 × 432 emblem | `../frontend/public/studio/emblem.webp`, `emblem-small.webp` |
| Simplified vector identity and favicon | `../frontend/public/studio/emblem.svg` |

## Sequence

| Time | Direction |
| --- | --- |
| 00–04 | A small violet seed; quiet anticipation |
| 04–08 | Controlled separation into silver ribbon segments |
| 08–13 | Architectural relationships resolve into a connected system |
| 13–20 | Original illustrative website, application workflow, and integration compositions enter in sequence |
| 20–27 | Compositions contract; the silver segments converge into one continuous emblem |
| 27–32 | Idiomorph Studio / Built to become more; sonic signature and silence |

The interface examples are explicitly labelled illustrative concepts. They represent services, not customers or completed projects. All on-screen messaging is understandable without sound. A caption file and written description accompany the website film.

## Validation

Run `npm run verify` while the frontend's production preview serves port 4179. `STUDIO_TEST_ORIGIN` changes that origin. This QA script reuses the pre-existing axe-core installation in `../.verification/frontend-tools`; it never writes to a backend. `lighthouse.mjs` similarly reuses the existing Lighthouse installation. Neither is needed to render the film.

`review-video.mjs` strictly decodes all three final video files and extracts actual encoded master frames at 1.5, 5.7, 10, 18, 25.4, and 28.5 seconds. `validation/film-contact-sheet.png` contains those frames in that order. Browser reports, screenshots, and raw Lighthouse HTML/JSON live under `validation/`. Generated outputs and installed tools are excluded by this workspace's `.gitignore`.

The legacy standalone CDP SEO harness did not complete in this environment, including a retry with isolated ports. Its timeout is recorded in `validation/existing-seo-run.txt`. The independent Playwright suite covers public/legal locale navigation, metadata restoration, menu/lunch landmarks, footer integration, and admin authentication gates without production data or writes.

## Licenses and cost

Required tooling cost: **€0**. No account, billing details, subscription, API, or trial is required.

- Three.js 0.180.0: MIT. Commercial use permitted; no organization-size restriction. Used only for offline rendering. No Three.js bundle is sent to website visitors. [Upstream license](https://github.com/mrdoob/three.js/blob/dev/LICENSE).
- FFmpeg 6.0 via ffmpeg-static 5.2.0: the installed binary is GPL v3 enabled. It is a local, unmodified rendering tool; the binary is not shipped with the website. No organization-size restriction. Encoded original artwork is not made GPL by using the encoder. [FFmpeg licensing](https://ffmpeg.org/legal.html), [ffmpeg-static license](https://github.com/eugeneware/ffmpeg-static/blob/master/LICENSE).
- Playwright 1.64.1 / Lighthouse 13.5.0: Apache 2.0, local development and QA. axe-core: MPL 2.0, local QA. No organization-size restrictions. [Playwright](https://github.com/microsoft/playwright/blob/main/LICENSE), [Lighthouse](https://github.com/GoogleChrome/lighthouse/blob/main/LICENSE), [axe-core](https://github.com/dequelabs/axe-core/blob/develop/LICENSE).
- Existing DM Sans and Instrument Serif fonts: SIL OFL 1.1, commercial embedding permitted. Self-hosted; unchanged. Full font notices are included in the frontend's `public/studio/licenses/`.
- All ribbon geometry, light environment, SVG illustrations, motion compositions, and sound were authored for this implementation. No externally licensed media is present.
- Remotion was evaluated but not adopted. Its free commercial eligibility requires an individual or qualifying organization of at most three people; the studio's headcount is unconfirmed. The chosen toolchain avoids that condition. [Official eligibility](https://www.remotion.dev/docs/license/faq).

The sibling frontend's existing React/React Router/Vite stack and font dependencies are unchanged. No new production package was added.
