# Idiomorph Studio — A film about making

Refined locally on 19 October 2026. An original **32-second** advertisement built with deterministic Canvas 2D, the supplied Idiomorph logo, self-hosted fonts, and original synthesized sound. No stock footage, music library, paid service, API, account, or new installation was used in this pass.

## Editable source

This workspace is isolated from the production frontend. The active visual source is **`film-scenes.mjs`**; `sound-design.mjs` generates the sound. `film.html` provides an editable timeline with scrubbing and playback. It previews picture only; the final encoded files contain the separate soundtrack.

The existing Node.js dependencies and installed Chrome browser are reused:

```powershell
cd C:\Users\giorg\Desktop\kebab-shop\studio-workspace
npm run preview
```

Open **http://127.0.0.1:4192**. `CHROME_PATH` selects another compatible Chromium executable for offline rendering; the default is `C:/Program Files/Google/Chrome/Application/chrome.exe`.

The source archive is `../frontend/docs/idiomorph-film-source.zip`. Extract into `studio-workspace/` beside `frontend/` to preserve export paths. It contains source, the exact supplied logo, fonts and notices, and the dependency lockfile. It excludes tool binaries, installed packages, rendered movies, and large QA/baseline media. On a fresh machine dependencies must be restored with `npm ci`; no installation is required in the current workspace.

## Identity

Used **`C:/Users/giorg/Desktop/IdiomorphLogo.png`**, the only matching Desktop asset. Original: 1254 × 1254, 1,495,263 bytes. Exact copy retained in `brand/IdiomorphLogo.png`.

SHA-256: `144191ebe85a63e422fe9eed12cd099cb52b5d638609ac28c42fc107cf434769`.

The artwork is preserved. Web derivatives crop empty margins and resize; the film uses the original. `brand/provenance.json` records its source. Run `node prepare-brand.mjs` to regenerate derivatives from the retained original; an optional path argument explicitly imports a replacement. The crop coordinates are specific to this supplied artwork.

## Render and exports

```powershell
npm run sound
npm run render
npm run encode
```

Rendering streams 960 frames to FFmpeg without a loose image sequence. The completed render took about 85 seconds on this machine. `node render.mjs --stills` refreshes seven review frames, five process illustrations, the logo proof, and poster without rendering the movie. `node assets.mjs` refreshes responsive poster/process WebPs. `encode.mjs` also calls that still encoder.

| Artifact | Location |
| --- | --- |
| 1920 × 1080, 30 fps, 32.000 s, H.264 + AAC stereo master | `output/idiomorph-master-1080p.mp4` — 8,572,594 bytes |
| Picture intermediate | `output/idiomorph-picture-1080p.mp4` |
| Original 48 kHz stereo PCM soundtrack | `output/idiomorph-original-sound.wav` |
| 1280 × 720 H.264 + AAC, faststart | `../frontend/public/studio/idiomorph-film-720p.mp4` — 1,772,151 bytes |
| 1280 × 720 VP9 + Opus | `../frontend/public/studio/idiomorph-film-720p.webm` — 1,468,707 bytes |
| 1600 × 900 / 640 × 360 WebP poster | `../frontend/public/studio/film-poster{,-small}.webp` |
| Five 960 × 540 / 480 × 270 WebP process stills | `../frontend/public/studio/process-{stage}{,-small}.webp` |
| 800 × 1000 / 400 × 500 / 96 × 120 supplied-logo derivatives | `../frontend/public/studio/brand-*.webp` |
| Square PNG favicon | `../frontend/public/studio/brand-favicon.png` |

## Sequence

| Time | Direction |
| --- | --- |
| 00–04.25 | A question on paper: hand-plotted “What if?”, people and purpose |
| 04.25–08.65 | Pencil wireframes, exploratory notes, desktop and phone sketches |
| 08.65–14.10 | A distinctive editorial interface takes shape across screens |
| 14.10–19.25 | A useful workflow and connected backend systems |
| 19.25–23.00 | Spacing, typography, annotation, and refinement |
| 23.00–26.65 | Thoughtful handover; ready for real life |
| 26.65–32.00 | Supplied silver/violet logo, IDIOMORPH STUDIO, “Built to become more.” |

Paper texture, pencil strokes, small camera movements, and deliberate pauses replace the former mechanical geometry. These are original constructed illustrations, not filmed hands or client projects. Interface scenes are labelled illustrative concepts. The website supplies descriptive captions and a full written description. No speech.

The audio combines original pencil-like friction, wooden taps, a quiet harmonic bed, and a restrained signature, ending in digital silence. The final master decodes completely; measured peak −15.9 dBFS, mean −32.6 dBFS, without clipping.

## Local verification

Run the frontend production preview on port 4179, then:

```powershell
npm run verify
node refinement-visual.mjs
node refinement-details.mjs
node review-video.mjs
node lighthouse.mjs
```

The main suite passes **36 checks**, including service studies, email draft context, clipboard, process stages, film seeking/playback/sound/fullscreen/fallback, reduced motion, keyboard behavior, responsive layouts, and read-only restaurant regression fixtures. Seven state-specific axe WCAG A/AA audits pass. Four screenshot viewport audits also pass. Hover/focus and responsive image delivery pass five additional checks.

QA helpers reuse the existing `../.verification/frontend-tools/` installation (axe-core and Lighthouse), sibling frontend, and this machine's saved baseline; they are separate from the portable rendering toolchain. `STUDIO_TEST_ORIGIN` changes the main browser suite's origin.

Evidence:
- `refinement/before/`: preserved original film/source/assets, original screenshots, branch/HEAD/status snapshot.
- `refinement/after/`: final desktop 1440, tablet 768, mobile 390, and small 320 screenshots and axe reports.
- `refinement/details/`: hover/focus, interactive-state screenshots, responsive media checks.
- `refinement/reports/`: 36-check browser report, seven axe reports, process still screenshots, encoded-film contact sheet and strict decode results, Lighthouse HTML/JSON.
- `review-video.mjs`: extracts actual master frames at 2.8, 6.9, 11.8, 17.9, 21.8, 25.6, 28.5, and 31.2 seconds; strictly decodes the master and both website movies.

Lighthouse 13.5.0: performance **91 mobile / 100 desktop**, accessibility **100 / 100**, best practices **100 / 100**. Cold local production preview, simulated 150 ms RTT / 1.6 Mbps / 4× CPU mobile and 40 ms / 10 Mbps / 1× desktop. Film playback is excluded from initial loading. SEO remains **69** because the existing publication flag deliberately sets noindex. See the frontend implementation report for limits and full conditions.

The original `scene.mjs`, `sound.mjs`, and older QA helpers are retained as historical source in this local workspace; active scripts and the updated source archive use the new film. Older `validation/` reports describe the initial implementation.

## Tools, licenses, and cost

Required tooling cost: **€0**. No new dependencies, installs, billing details, paid tools, trials, or remote services.

| Component | Assessment |
| --- | --- |
| Canvas 2D / CSS / SVG / original JavaScript | Native rendering and interface APIs; original authored compositions |
| FFmpeg 6.0 through ffmpeg-static 5.2.0 | Local unmodified GPL-3.0-or-later tool; commercial use, no organization-size restriction. No binaries shipped with website/source archive. [FFmpeg licensing](https://ffmpeg.org/legal.html), [wrapper license](https://github.com/eugeneware/ffmpeg-static/blob/master/LICENSE) |
| Playwright 1.64.1 | Apache 2.0; commercial use, no organization-size restriction. [License](https://github.com/microsoft/playwright/blob/main/LICENSE) |
| axe-core 4.14.0 | MPL 2.0; local QA, no organization-size restriction. [License](https://github.com/dequelabs/axe-core/blob/develop/LICENSE) |
| Lighthouse 13.5.0 | Apache 2.0; local QA, no organization-size restriction. [License](https://github.com/GoogleChrome/lighthouse/blob/main/LICENSE) |
| Existing DM Sans / Instrument Serif | SIL OFL 1.1; commercial self-hosted embedding. Full notices in `fonts/` and frontend `public/studio/licenses/` |
| Supplied logo | User-provided asset, explicitly requested for this studio; exact original retained |
| Other images and sound | Original procedural illustration and synthesis; no stock assets or external music |

No Remotion, image-generation API, animation library, or new production runtime was adopted. The legacy locked Three.js dependency is MIT and unused by the new film; it is not delivered to website visitors. Existing frontend React/Router/Vite dependencies are unchanged.
