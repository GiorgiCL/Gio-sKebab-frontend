// Original synthesis: graphite-like friction, soft wooden taps and a warm harmonic bed.
// No recordings, samples, stock music, external services or voiceover.
import { writeFile,mkdir } from 'node:fs/promises'
const rate=48000,seconds=32,count=rate*seconds,out=Buffer.alloc(44+count*4)
out.write('RIFF',0);out.writeUInt32LE(out.length-8,4);out.write('WAVEfmt ',8);out.writeUInt32LE(16,16);out.writeUInt16LE(1,20);out.writeUInt16LE(2,22);out.writeUInt32LE(rate,24);out.writeUInt32LE(rate*4,28);out.writeUInt16LE(4,32);out.writeUInt16LE(16,34);out.write('data',36);out.writeUInt32LE(count*4,40)
const ease=x=>{x=Math.min(1,Math.max(0,x));return x*x*(3-2*x)},span=(t,a,b)=>ease((t-a)/(b-a))
let seed=104729,low=0,slow=0
for(let i=0;i<count;i++){
 const t=i/rate;seed=(Math.imul(seed,1664525)+1013904223)>>>0;const noise=seed/2147483648-1;low=low*.86+noise*.14;slow=slow*.995+noise*.005
 const breathe=.72+.16*Math.sin(t*.55)+.07*Math.sin(t*1.1+.4)
 let v=(Math.sin(2*Math.PI*146.8324*t)*.021+Math.sin(2*Math.PI*220.04*t)*.013+Math.sin(2*Math.PI*293.61*t)*.008)*breathe*span(t,.3,3.2)*(1-span(t,26.5,30))
 for(const [a,b]of[[.65,2.95],[4.7,6.3],[6.5,8.2],[20.15,21.3]]){const friction=span(t,a,a+.18)*(1-span(t,b-.2,b));v+=(low-slow)*friction*.12*(.6+.2*Math.sin(t*19+Math.sin(t*5)))}
 for(const at of [4.25,8.65,14.1,19.25,23]){const age=t-at;if(age>=0&&age<.6)v+=(Math.sin(age*2*Math.PI*173)*.075+low*.065)*Math.exp(-age*22)*(1-Math.exp(-age*150))}
 for(const [at,hz,amp]of[[26.7,293.665,.09],[26.91,440,.045],[27.1,587.33,.025]]){const age=t-at;if(age>=0){const envelope=(1-Math.exp(-age*22))*Math.exp(-age*1.6);v+=(Math.sin(2*Math.PI*hz*age)+.13*Math.sin(2*Math.PI*hz*3.003*age))*envelope*amp}}
 const fade=span(t,0,.2)*(1-span(t,29.7,30.6));v*=fade
 const left=Math.tanh(v),right=Math.tanh(v+slow*.018*Math.sin(t*.8)*fade)
 out.writeInt16LE(Math.round(left*32767),44+i*4);out.writeInt16LE(Math.round(right*32767),46+i*4)
}
await mkdir(new URL('./output/',import.meta.url),{recursive:true});await writeFile(new URL('./output/idiomorph-original-sound.wav',import.meta.url),out);console.log('Original tactile stereo sound design rendered; ending in digital silence.')
