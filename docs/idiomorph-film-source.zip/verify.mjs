import assert from 'node:assert/strict'
import { readFile, writeFile, mkdir } from 'node:fs/promises'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { chromium } from './browser-tool.mjs'

const origin=process.env.STUDIO_TEST_ORIGIN||'http://127.0.0.1:4179'
const directory=new URL('./validation/',import.meta.url);await mkdir(directory,{recursive:true})
const file=name=>fileURLToPath(new URL(name,directory))
const browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
const checks=[],errors=[],media=[],requests=[]
const context=await browser.newContext({viewport:{width:1440,height:1000},permissions:['clipboard-read','clipboard-write']})
const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{requests.push(r.url());if(/\.(mp4|webm)(\?|$)/.test(r.url()))media.push(r.url())})
const check=(name,detail=true)=>{checks.push({name,detail});console.log('PASS',name)}
async function axe(page,name){
 await page.addScriptTag({path:fileURLToPath(new URL('../.verification/frontend-tools/node_modules/axe-core/axe.min.js',import.meta.url))})
 const result=await page.evaluate(()=>window.axe.run(document.querySelector('.im-studio'),{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa']}}))
 await writeFile(file(`axe-${name}.json`),JSON.stringify(result,null,2));assert.deepEqual(result.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>n.target)})),[]);check(`axe WCAG 2.1 A/AA: ${name}`,{passes:result.passes.length,incomplete:result.incomplete.map(v=>v.id)})
}
try {
 const response=await page.goto(origin+'/studio');assert.equal(response.status(),200);await page.locator('h1').waitFor();await page.evaluate(()=>document.fonts.ready)
 assert.match(await page.title(),/Idiomorph Studio/);assert.equal(await page.locator('html').getAttribute('lang'),'en');assert.equal(await page.locator('meta[name=robots]').getAttribute('content'),'noindex, nofollow')
 assert.equal(await page.locator('.site-footer,.public-nav,.admin-root').count(),0);check('Direct /studio navigation, isolated layout and metadata')
 assert.equal(await page.locator('video').count(),0);assert.equal(media.length,0);assert.equal(requests.some(u=>u.includes('/api/')),false);assert.equal(requests.some(u=>new URL(u).origin!==origin),false);check('No film, API, tracker or remote font requests before interaction')
 await page.waitForTimeout(1700)
 for(const [width,height] of [[320,740],[360,800],[390,844],[768,1024],[1024,900],[1440,1000],[1920,1080]]){
  await page.setViewportSize({width,height});await page.waitForTimeout(70)
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,`No overflow at ${width}`)
  await page.screenshot({path:file(`responsive-${width}.png`),fullPage:true})
 }
 check('Responsive layouts at 320, 360, 390, 768, 1024, 1440 and 1920 px')
 await page.setViewportSize({width:1440,height:1000});await axe(page,'desktop')
 await page.getByRole('button',{name:'Pause motion'}).click();assert.equal(await page.locator('.im-motion-paused').count(),1)
 assert.ok(await page.evaluate(()=>document.getAnimations().filter(a=>a.effect?.target?.closest?.('.im-studio')).every(a=>a.playState==='paused')));check('Explicit motion pause control')
 await page.getByRole('button',{name:'Resume motion'}).click()
 for(const label of ['Discover','Design','Engineer','Refine','Deliver']){await page.getByRole('tab',{name:new RegExp(label)}).click();assert.equal(await page.getByRole('tab',{name:new RegExp(label)}).getAttribute('aria-selected'),'true');assert.equal(await page.getByRole('tabpanel').count(),1)}
 await page.getByRole('tab',{name:/Discover/}).focus();await page.keyboard.press('ArrowRight');assert.equal(await page.getByRole('tab',{name:/Design/}).getAttribute('aria-selected'),'true');await page.keyboard.press('End');assert.equal(await page.getByRole('tab',{name:/Deliver/}).getAttribute('aria-selected'),'true');await page.keyboard.press('Home');assert.equal(await page.getByRole('tab',{name:/Discover/}).getAttribute('aria-selected'),'true');check('All five process stages, keyboard arrows, Home and End')
 await page.getByText('Read the film description').click();assert.equal(await page.locator('.im-transcript').getAttribute('open'),'');await page.getByText('Read the film description').click();check('Accessible complete film description')
 await page.getByRole('button',{name:'Copy email',exact:true}).click();assert.equal(await page.evaluate(()=>navigator.clipboard.readText()),'idiomorph.studio@gmail.com');assert.equal(await page.locator('.im-copy-status').textContent(),'Email copied');assert.match(await page.locator('#im-contact-status').textContent(),/not yet confirmed/);assert.match(await page.getByRole('link',{name:/Draft an email/}).getAttribute('href'),/^mailto:idiomorph\.studio@gmail\.com/);check('Contact copy, draft link and unconfirmed-address disclosure')
 await page.evaluate(()=>scrollTo(0,0));await page.keyboard.press('Control+Home');await page.locator('.im-brand').focus();await page.keyboard.press('Shift+Tab');assert.equal(await page.evaluate(()=>document.activeElement.className),'im-skip');await page.keyboard.press('Enter');assert.equal(new URL(page.url()).hash,'#im-main');check('Keyboard skip navigation and visible focus styles')
 await page.getByRole('button',{name:/Watch the film/}).first().click();await page.waitForFunction(()=>{const v=document.querySelector('video');return v&&v.readyState>=2&&v.currentTime>.1})
 const video=await page.locator('video').evaluate(v=>({duration:v.duration,width:v.videoWidth,height:v.videoHeight,muted:v.muted,paused:v.paused,controls:v.controls,source:v.currentSrc}));assert.equal(video.duration,32);assert.equal(video.width,1280);assert.equal(video.height,720);assert.equal(video.muted,true);assert.equal(video.paused,false);assert.equal(video.controls,true);check('Actual 32-second 720p video plays after explicit interaction',video)
 await page.getByRole('button',{name:'Enable sound'}).click();assert.equal(await page.locator('video').evaluate(v=>v.muted),false);await page.getByRole('button',{name:'Mute sound'}).click();assert.equal(await page.locator('video').evaluate(v=>v.muted),true);check('Explicit sound enable/mute controls')
 await page.getByRole('button',{name:/Expand/}).click();assert.equal(await page.evaluate(()=>!!document.fullscreenElement),true);await page.evaluate(()=>document.exitFullscreen());check('Fullscreen playback')
 await page.locator('video').evaluate(async v=>{v.pause();v.currentTime=16;await new Promise(r=>v.addEventListener('seeked',r,{once:true}))});await page.locator('video').screenshot({path:file('film-playback-16s.png')});await axe(page,'film-controls')
 const range=await context.request.get(origin+'/studio/idiomorph-film-720p.mp4',{headers:{Range:'bytes=0-1023'}});assert.equal(range.status(),206);assert.equal((await range.body()).length,1024);check('MP4 HTTP byte-range delivery and seeking')
 // A separate page checks H.264 fallback independently of preferred WebM playback.
 const mp4=await context.newPage();await mp4.goto(origin+'/studio');await mp4.locator('h1').waitFor();await mp4.evaluate(()=>{const v=document.createElement('video');v.src='/studio/idiomorph-film-720p.mp4';v.muted=true;v.controls=true;document.querySelector('main').append(v);return v.play()});await mp4.waitForFunction(()=>document.querySelector('video')?.currentTime>.1);check('H.264 / AAC fallback playback in Chrome');await mp4.close()
 await page.setViewportSize({width:390,height:844});await axe(page,'mobile');await page.emulateMedia({reducedMotion:'reduce'});await page.reload();await page.locator('h1').waitFor();assert.equal(await page.locator('.im-chrome').evaluate(e=>getComputedStyle(e).animationName),'none');assert.equal(await page.locator('video').count(),0);assert.equal(await page.getByRole('button',{name:'Pause motion'}).isVisible(),false);await page.getByRole('tab',{name:/Deliver/}).click();assert.equal(await page.getByRole('tabpanel').count(),1);await page.screenshot({path:file('reduced-motion-mobile.png'),fullPage:true});check('Reduced motion: static identity, complete content and manual film playback')
 await page.emulateMedia({reducedMotion:'no-preference'})
 // Simulate unavailable media: useful fallback remains within the actual presentation.
 const bad=await context.newPage();await bad.route('**/studio/*.{mp4,webm}',route=>route.abort());await bad.goto(origin+'/studio');await bad.getByRole('button',{name:/Watch the film/}).first().click();await bad.getByText('The film couldn’t play in this browser.').waitFor();assert.equal(await bad.getByRole('link',{name:/Download the film/}).count(),1);await bad.getByText('Read the film description').click();check('Media failure fallback, download and readable description');await bad.close()

 // Read-only API fixtures exercise restaurant integration without a backend or writes.
 const weekdays=['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY']
 const profile={displayName:"Gio's Kebab",description:'Read-only regression fixture',address:'Fixture address',phone:'+37060000000',email:null,googleMapsUrl:'https://maps.google.com/',woltUrl:null,boltFoodUrl:null,instagramUrl:null,facebookUrl:null}
 const item={id:1,name:'Fixture kebab',description:'Fixture description',priceEur:7,available:true,featured:true,imageUrl:null}
 await page.route('**/api/**',async route=>{assert.equal(route.request().method(),'GET','No mutations in regression checks');const p=new URL(route.request().url()).pathname;const bodies={
  '/api/public/restaurant':profile,'/api/public/menu':{categories:[{id:1,name:'Fixture menu',items:[item]}]},'/api/public/lunch-menu':{days:weekdays.map(dayOfWeek=>({dayOfWeek,items:[{...item,id:2}]}))},'/api/public/promotions':{promotions:[],timeZone:'Europe/Vilnius'},'/api/public/opening-status':{openNow:true,closedToday:false,localDate:'2026-10-19',localTime:'12:00',timeZone:'Europe/Vilnius',source:'WEEKLY',openingTime:'11:00',closingTime:'21:00'},'/api/public/opening-hours':{timeZone:'Europe/Vilnius',weekly:weekdays.map(dayOfWeek=>({dayOfWeek,open:true,openingTime:'11:00',closingTime:'21:00'})),specialDates:[]},'/api/admin/auth/me':{},'/api/admin/auth/session-options':{rememberMeSeconds:7200},'/api/admin/auth/csrf':{token:'fixture',headerName:'X-CSRF-TOKEN',parameterName:'_csrf'}};await route.fulfill({status:p.endsWith('/auth/me')?401:p in bodies?200:404,contentType:'application/json',body:JSON.stringify(bodies[p]||{})})})
 for(const locale of ['lt','en','ru','ka']){
  await page.goto(origin+'/'+locale);await page.locator('.footer-studio-credit a').waitFor();assert.equal(await page.locator('.footer-studio-credit a').getAttribute('href'),'/studio');assert.equal(await page.locator('.footer-legal a').count(),2);assert.equal(await page.locator('#menu').count(),1);assert.equal(await page.locator('#lunch').count(),1)
  for(const suffix of ['privacy','legal']){await page.goto(origin+`/${locale}/${suffix}`);await page.locator('.footer-legal').waitFor();assert.equal(await page.locator('html').getAttribute('lang'),locale);assert.equal(await page.locator('.im-studio').count(),0)}
 }
 check('Restaurant menu/lunch landmarks, legal pages and footer links in all four locales (read-only fixtures)')
 await page.goto(origin+'/lt');await page.locator('.footer-studio-credit a').click();await page.locator('.im-brand').waitFor();assert.equal(new URL(page.url()).pathname,'/studio');assert.equal(await page.locator('html').getAttribute('lang'),'en');await page.getByRole('link',{name:/Back to Gio/}).click();await page.locator('.public-site').waitFor();assert.equal(await page.locator('html').getAttribute('lang'),'lt');assert.equal(await page.locator('html').evaluate(e=>e.classList.contains('im-document')),false);assert.match(await page.locator('link[rel=icon]').getAttribute('href'),/gios-kebab-logo/);check('Footer SPA navigation and studio-to-restaurant identity restoration')
 for(const route of ['/admin','/admin/menu','/admin/lunch-menu']){await page.goto(origin+route);await page.locator('input[type=password]').waitFor();assert.equal(new URL(page.url()).pathname,'/admin/login');assert.equal(await page.locator('.im-studio').count(),0)}check('Admin, menu and lunch admin retain signed-out authentication gate (fixtures; no writes)')
 const root=fileURLToPath(new URL('../frontend/',import.meta.url));const getHead=p=>execFileSync('git',['show',`HEAD:${p}`],{cwd:root,encoding:'utf8'}).replaceAll('\r\n','\n')
 const current=async p=>(await readFile(new URL('../frontend/'+p,import.meta.url),'utf8')).replaceAll('\r\n','\n')
 assert.equal((await current('src/app/router.tsx')).split('\n').filter(line=>!line.includes("{ path: '/studio',")).join('\n'),getHead('src/app/router.tsx'))
 assert.equal((await current('src/features/public/PublicNavigation.tsx')).replace('<div className="layout-wrap footer-studio-credit"><Link to="/studio">Website by Idiomorph Studio <span aria-hidden="true">↗</span></Link></div>',''),getHead('src/features/public/PublicNavigation.tsx'))
 assert.equal((await current('src/features/public/public.css')).split('\n').filter(l=>!l.startsWith('.public-site .footer-studio-credit')).join('\n'),getHead('src/features/public/public.css'))
 check('Existing tracked frontend source equals HEAD after removing exactly the authorized route and footer additions')
 assert.deepEqual(errors,[]);check('No browser JavaScript exceptions')
 await writeFile(file('browser-results.json'),JSON.stringify({origin,browser:await browser.version(),checks,errors,media},null,2));console.log(`Completed ${checks.length} browser checks.`)
} finally { await browser.close() }
