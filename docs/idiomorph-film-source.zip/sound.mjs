// Original stereo synthesis. No recordings, samples, music libraries or voiceover.
import { writeFile, mkdir } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
const rate=48000, duration=32, count=rate*duration
const data=Buffer.alloc(44+count*4)
data.write('RIFF',0);data.writeUInt32LE(data.length-8,4);data.write('WAVEfmt ',8);data.writeUInt32LE(16,16);data.writeUInt16LE(1,20);data.writeUInt16LE(2,22);data.writeUInt32LE(rate,24);data.writeUInt32LE(rate*4,28);data.writeUInt16LE(4,32);data.writeUInt16LE(16,34);data.write('data',36);data.writeUInt32LE(count*4,40)
let seed=2417,low=0
const smooth=(t,a,b)=>{const x=Math.min(1,Math.max(0,(t-a)/(b-a)));return x*x*(3-2*x)}
for(let i=0;i<count;i++){
 const t=i/rate;seed=(Math.imul(seed,1664525)+1013904223)>>>0;const noise=seed/2147483648-1;low=low*.96+noise*.04
 const bed=(Math.sin(2*Math.PI*55*t)*.035+Math.sin(2*Math.PI*82.4069*t)*.016+low*.1)*smooth(t,.4,3)*(1-smooth(t,26.5,29.7))
 let v=bed
 for(const [time,freq,amp] of [[.9,440,.09],[4.25,220,.1],[8.2,329.627,.1],[13.1,440,.08],[20.6,164.81,.13],[26.9,440,.12],[27.15,659.255,.075]]){
  const age=t-time;if(age>=0&&age<4){const env=(1-Math.exp(-age*35))*Math.exp(-age*2.3);v+=env*(Math.sin(2*Math.PI*freq*age)+.25*Math.sin(2*Math.PI*freq*2.002*age))*amp}
 }
 for(const time of [4,7.8,12.7,20.6,25.8]){const age=t-time;if(age>-.55&&age<1.8){const env=Math.exp(-Math.pow((age-.04)/.45,2));v+=(noise-low)*env*.025+Math.sin(2*Math.PI*(62*age-8*age*age))*env*.05}}
 v*=smooth(t,0,.4)*(1-smooth(t,29.4,30.6))
 const left=Math.tanh(v)*.8,right=Math.tanh(v+low*.013*Math.sin(t*.7))*.8
 data.writeInt16LE(Math.round(Math.max(-1,Math.min(1,left))*32767),44+i*4);data.writeInt16LE(Math.round(Math.max(-1,Math.min(1,right))*32767),46+i*4)
}
await mkdir(new URL('./output/',import.meta.url),{recursive:true})
await writeFile(new URL('./output/idiomorph-original-sound.wav',import.meta.url),data)
console.log('Original 32-second / 48 kHz stereo sound design written.')
