// Prefer the self-contained project install; reuse the workspace QA tool if present.
export const { chromium } = await import('playwright-core').catch(() => import('../.verification/frontend-tools/node_modules/playwright-core/index.mjs'))
