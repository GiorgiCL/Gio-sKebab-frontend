import { chromium } from './browser-tool.mjs'
import { mkdir, writeFile } from 'node:fs/promises'
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
await mkdir(new URL('./validation/',import.meta.url),{recursive:true})
const report=[]
for(const [name,width,height] of [['desktop',1440,1000],['mobile',390,844],['tablet',768,1024],['small-mobile',320,740]]){
 const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:1})
 const errors=[];page.on('pageerror',e=>errors.push(e.message))
 await page.goto((process.env.STUDIO_TEST_ORIGIN||'http://127.0.0.1:4179')+'/studio');await page.locator('.im-chrome').waitFor();await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(1800)
 await page.screenshot({path:new URL(`./validation/${name}-hero.png`,import.meta.url).pathname.slice(1)})
 await page.screenshot({path:new URL(`./validation/${name}-full.png`,import.meta.url).pathname.slice(1),fullPage:true})
 report.push({name,width,height,errors,overflow:await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),images:await page.locator('img').evaluateAll(imgs=>imgs.map(i=>({src:i.src,loaded:i.complete&&i.naturalWidth>0})))})
 await page.close()
}
await writeFile(new URL('./validation/visual-initial.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report));await browser.close()
