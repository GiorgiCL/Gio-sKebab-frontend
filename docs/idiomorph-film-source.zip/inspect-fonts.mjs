import { chromium } from './browser-tool.mjs'
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
const page=await browser.newPage();await page.goto('http://127.0.0.1:4179/studio');await page.evaluate(()=>document.fonts.ready)
console.log(await page.evaluate(()=>{const ctx=document.createElement('canvas').getContext('2d');return ['Instrument Serif','Georgia','Arial','DM Sans Variable'].map(font=>{ctx.font=`100px "${font}"`;return {font,width:ctx.measureText('From ideas to what’s next.').width}})}));await browser.close()
