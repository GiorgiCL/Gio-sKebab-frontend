// Original deterministic motion-design source. All dimensions use the 1920 x 1080 master.
import * as THREE from 'three'

export const DURATION = 32
const canvas = document.querySelector('#film'), ctx = canvas.getContext('2d')
const clamp = (v, a=0, b=1) => Math.max(a, Math.min(b,v))
const ease = v => { v=clamp(v); return v*v*(3-2*v) }
const span = (t,a,b) => ease((t-a)/(b-a))
const windowAt = (t,a,b,fade=.6) => span(t,a,a+fade)*(1-span(t,b-fade,b))
const lerp = (a,b,t) => a+(b-a)*t
const silver='#f3eff7', muted='#a49cafff', violet='#b497ed'

const renderer = new THREE.WebGLRenderer({alpha:true,antialias:true,preserveDrawingBuffer:true})
renderer.setSize(1240,1240); renderer.setPixelRatio(1)
renderer.outputColorSpace=THREE.SRGBColorSpace
renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.5
const scene=new THREE.Scene(), camera=new THREE.PerspectiveCamera(34,1,.1,100)
camera.position.set(0,0,8.7)

// A photographic light rig painted as an equirectangular environment; no stock HDRI.
const envCanvas=document.createElement('canvas');envCanvas.width=2048;envCanvas.height=1024
const e=envCanvas.getContext('2d');e.fillStyle='#111016';e.fillRect(0,0,2048,1024)
function panel(x,y,w,h,color){const g=e.createLinearGradient(x,0,x+w,0);g.addColorStop(0,'#111016');g.addColorStop(.12,color);g.addColorStop(.88,color);g.addColorStop(1,'#111016');e.fillStyle=g;e.fillRect(x,y,w,h)}
panel(80,150,190,680,'#ffffff');panel(700,10,480,410,'#cbc8d1');panel(1440,270,100,670,'#a98be1');panel(1810,80,90,860,'#ffffff')
const environment=new THREE.CanvasTexture(envCanvas);environment.mapping=THREE.EquirectangularReflectionMapping
const pmrem=new THREE.PMREMGenerator(renderer);scene.environment=pmrem.fromEquirectangular(environment).texture
environment.dispose();pmrem.dispose()
scene.add(new THREE.HemisphereLight(0xded6ff,0x0c0819,1.4))
const key=new THREE.DirectionalLight(0xffffff,4);key.position.set(-3,5,4);scene.add(key)
const rim=new THREE.DirectionalLight(0x9f72ed,5);rim.position.set(4,-1,-2);scene.add(rim)
const group=new THREE.Group();scene.add(group)

// A double-return ribbon: an asymmetric continuous S, with two generous apertures.
// Closed beveled cross-section gives the material a real edge and reflected light.
const curve=new THREE.CatmullRomCurve3([
  [-.85,1.65,-.05],[.4,1.8,.12],[1.18,1.03,-.05],[.55,.25,.42],
  [-.62,-.25,.25],[-1.13,-1.05,-.1],[-.38,-1.77,.02],[.85,-1.55,.2],
  [.85,-.65,-.4],[.12,.02,-.52],[-.9,.74,-.42],
].map(p=>new THREE.Vector3(...p)),true,'centripetal',.45)
const steps=360, frames=curve.computeFrenetFrames(steps,true), slices=12, meshes=[]
const cross=[[-.88,-1],[-.98,-.75],[-1,0],[-.98,.75],[-.88,1],[.88,1],[.98,.75],[1,0],[.98,-.75],[.88,-1]]
const material=new THREE.MeshPhysicalMaterial({color:0xe1dfe5,metalness:1,roughness:.235,clearcoat:.45,clearcoatRoughness:.18,side:THREE.DoubleSide})
for(let s=0;s<slices;s++){
 const vertices=[],indices=[];const count=steps/slices
 for(let j=0;j<=count;j++){
  const i=s*count+j,t=i/steps,p=curve.getPointAt(t),n=frames.normals[i],b=frames.binormals[i]
  const twist=.35*Math.sin(t*Math.PI*4)+t*Math.PI*2+.35
  const w=.35+.11*Math.sin(t*Math.PI*4+.4),th=.052
  for(const [u,v] of cross){const U=u*w*Math.cos(twist)-v*th*Math.sin(twist),V=u*w*Math.sin(twist)+v*th*Math.cos(twist);vertices.push(p.x+n.x*U+b.x*V,p.y+n.y*U+b.y*V,p.z+n.z*U+b.z*V)}
 }
 for(let j=0;j<count;j++)for(let k=0;k<cross.length;k++){const a=j*cross.length+k,b=j*cross.length+(k+1)%cross.length,c=a+cross.length,d=b+cross.length;indices.push(a,b,c,b,d,c)}
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.setIndex(indices);geo.computeVertexNormals()
 const mesh=new THREE.Mesh(geo,material);mesh.userData.center=curve.getPointAt((s+.5)/slices);mesh.userData.index=s;group.add(mesh);meshes.push(mesh)
}

function text(content,x,y,size=32,font='DM',color=silver,align='left',alpha=1){ctx.save();ctx.globalAlpha*=alpha;ctx.font=`${size}px ${font}`;ctx.fillStyle=color;ctx.textAlign=align;ctx.fillText(content,x,y);ctx.restore()}
function spaced(content,x,y,size=15,spacing=5,color=muted,align='left'){
 ctx.save();ctx.font=`${size}px DM`;const width=[...content].reduce((v,c)=>v+ctx.measureText(c).width+spacing,0)-spacing;let px=x-(align==='center'?width/2:align==='right'?width:0);ctx.fillStyle=color;for(const c of content){ctx.fillText(c,px,y);px+=ctx.measureText(c).width+spacing}ctx.restore()
}
function line(x1,y1,x2,y2,color='#51465d',width=1){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke()}
function rect(x,y,w,h,color='#15121b',stroke='#3d3547',radius=0){ctx.beginPath();ctx.roundRect(x,y,w,h,radius);ctx.fillStyle=color;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1;ctx.stroke()}}
function backdrop(t){
 ctx.fillStyle='#08070b';ctx.fillRect(0,0,1920,1080)
 const g=ctx.createRadialGradient(1080,470,20,1080,470,880);g.addColorStop(0,'#20162a');g.addColorStop(.5,'#100d15');g.addColorStop(1,'#08070b');ctx.fillStyle=g;ctx.fillRect(0,0,1920,1080)
 // Deliberately sparse architectural horizon.
 ctx.globalAlpha=.22;line(100,919,1820,919,'#5c4d6a');line(1530,100,1530,980,'#352b40');ctx.globalAlpha=1
}
function chrome(t,{x=960,y=520,size=880,scale=1,explode=0,rotation=0,alpha=1}={}){
 group.rotation.set(.11+Math.sin(t*.22)*.06,rotation,-.24)
 group.scale.setScalar(scale)
 for(const mesh of meshes){const p=mesh.userData.center;mesh.position.copy(p).multiplyScalar(explode);mesh.rotation.set(explode*.1*Math.sin(mesh.userData.index),explode*.15,0)}
 renderer.render(scene,camera);ctx.save();ctx.globalAlpha*=alpha;ctx.drawImage(renderer.domElement,x-size/2,y-size/2,size,size);ctx.restore()
}
function grid(t,alpha=1,converge=0){
 ctx.save();ctx.globalAlpha*=alpha;const progress=span(t,8,10.5)
 for(let i=0;i<7;i++)for(let j=0;j<4;j++){
  const x=lerp(370+i*196,960,converge),y=lerp(280+j*154,520,converge),index=i*4+j
  if(progress<index/32)continue
  if(i<6)line(x,y,lerp(x,lerp(566+i*196,960,converge),span(t,8+index*.035,9+index*.035)),y,'#4f3b69')
  if(j<3)line(x,y,x,lerp(y,lerp(434+j*154,520,converge),span(t,8.3+index*.025,9.3+index*.025)),'#3c3348')
  rect(x-4,y-4,8,8,index%5===0?'#b8a5db':'#71647e',null)
 }
 rect(717,379,484,264,'#100d16','#63506e',12)
 spaced('CONNECTED BY INTENTION',960,493,16,4,silver,'center');text('Complexity. Composed.',960,555,44,'Instrument',silver,'center')
 ctx.restore()
}
function interfaces(t,alpha=1,collapse=0){
 ctx.save();ctx.globalAlpha*=alpha;ctx.translate(960,530);ctx.scale(1-collapse*.9,1-collapse*.9);ctx.translate(-960,-530)
 const arrival=span(t,12.9,14.1)
 ctx.translate(960,530);ctx.scale(1+span(t,14,20)*.018,1+span(t,14,20)*.018);ctx.translate(-960,-530)
 ctx.translate(0,(1-arrival)*80)
 // Website editorial composition. Original illustrative content, no fabricated client.
 ctx.save();ctx.globalAlpha*=span(t,12.8,13.6);ctx.translate(150-(1-span(t,12.9,14.2))*80,225);ctx.rotate(-.055*(1-collapse))
 rect(0,0,655,491,'#e4dfd5','#7f7685',5)
 spaced('FORM / FIELD',28,41,13,3,'#25202b');line(28,62,625,62,'#a6a096')
 text('A different',32,154,68,'Instrument','#25202b');text('point of view.',32,222,68,'Instrument','#25202b')
 rect(34,260,284,179,'#26212b',null);ctx.save();ctx.beginPath();ctx.rect(34,260,284,179);ctx.clip();chrome(t,{x:177,y:353,size:285,rotation:.55,alpha:1});ctx.restore()
 text('Make an impression.',354,308,22,'DM','#25202b');text('A website with purpose,',354,348,17,'DM','#504956');text('from the very first view.',354,376,17,'DM','#504956')
 line(356,414,510,414,'#504956');text('Explore  ↗',354,438,15,'DM','#25202b');ctx.restore()
 // Application composition: workflow, not invented business statistics.
 ctx.save();ctx.globalAlpha*=span(t,14.1,15.2);ctx.translate(866+(1-span(t,14.1,15.5))*110,184);ctx.rotate(.042*(1-collapse))
 rect(0,0,850,376,'#17131e','#53455e',7)
 spaced('WORKSPACE',26,38,13,3,silver);line(0,61,850,61,'#3b3047')
 text('Ideas, moving forward.',28,112,31);text('A place for the way you work.',28,145,17,'DM',muted)
 const headings=['IDEA','IN MOTION','READY'];headings.forEach((h,i)=>{spaced(h,28+i*274,190,12,2,muted);rect(26+i*274,211,250,123,'#211b2a','#41334e',4);rect(43+i*274,229,27,4,'#a385cf',null);text(['Shape the brief','Build with purpose','Refine the details'][i],44+i*274,274,18);text(['A clear beginning','Thought into action','Ready for what’s next'][i],44+i*274,307,14,'DM',muted)})
 ctx.restore()
 // System architecture: intentionally clear and abstract.
 ctx.save();ctx.globalAlpha*=span(t,16.1,17.2);ctx.translate(907,619+(1-span(t,16.1,17.5))*70);ctx.rotate(-.025*(1-collapse))
 rect(0,0,760,202,'#100e16','#493c57',6)
 const nodes=[['EXPERIENCE',35,67],['APPLICATION',282,67],['YOUR SYSTEMS',529,67]]
 line(180,103,640,103,'#a58ac6',2)
 nodes.forEach(([label,x,y],i)=>{rect(x,y,194,73,'#1d1727','#60506d',3);spaced(label,x+97,y+43,12,1,silver,'center');const p=(t*.45+i*.23)%1;ctx.fillStyle='#cfb5ff';ctx.beginPath();ctx.arc(x+194+p*46,y+37,2.5,0,Math.PI*2);ctx.fill()})
 text('Thoughtfully connected. Built to work together.',35,178,17,'DM',muted);ctx.restore()
 ctx.restore()
}

export function draw(t){
 t=clamp(t,0,32);ctx.globalAlpha=1;backdrop(t)
 const spark=windowAt(t,0,4.7,.9)
 if(spark>0){
  ctx.save();ctx.globalAlpha=spark;const g=ctx.createRadialGradient(960,480,0,960,480,170);g.addColorStop(0,'#7144a84d');g.addColorStop(1,'#7144a800');ctx.fillStyle=g;ctx.fillRect(700,220,520,520)
  ctx.save();ctx.globalAlpha*=1-span(t,3.1,4);ctx.translate(960,480);ctx.rotate(.15+t*.035);ctx.scale(1+span(t,2.5,4)*1.5,1+span(t,2.5,4)*1.5)
  ctx.beginPath();ctx.moveTo(0,-14);ctx.lineTo(10,0);ctx.lineTo(0,14);ctx.lineTo(-10,0);ctx.closePath();ctx.fillStyle='#9e70d6';ctx.fill();ctx.strokeStyle='#d9c2fa';ctx.lineWidth=.8;ctx.stroke()
  ctx.beginPath();ctx.moveTo(0,-14);ctx.lineTo(0,0);ctx.lineTo(-10,0);ctx.closePath();ctx.fillStyle='#e3d2fa';ctx.fill();ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(10,0);ctx.lineTo(0,14);ctx.closePath();ctx.fillStyle='#4b2c73';ctx.fill();ctx.restore()
  chrome(t,{x:960,y:480,size:270,scale:.28+span(t,2.2,4.5)*.3,rotation:-.6,alpha:span(t,3.15,4.15)});spaced('EVERYTHING BEGINS WITH AN IDEA.',960,755,16,4,muted,'center');ctx.restore()
 }
 const fracture=windowAt(t,3.7,8.7,.7)
 if(fracture>0){ctx.save();ctx.globalAlpha=fracture;chrome(t,{size:960,scale:.73,explode:span(t,4.1,6.5)*.55,rotation:lerp(-.6,.2,span(t,4,8))});spaced('01 / POSSIBILITY, UNFOLDED',100,157,14,3);text('Break the expected.',100,885,66,'Instrument');ctx.restore()}
 const structure=windowAt(t,7.8,13.7,.7)
 if(structure>0){ctx.save();ctx.globalAlpha=structure;grid(t);spaced('02 / INTELLIGENCE IN THE CONNECTIONS',100,157,14,3);spaced('FROM AN IDEA TO A SYSTEM.',960,861,16,4,muted,'center');ctx.restore()}
 const creation=windowAt(t,12.7,21.5,.65)
 if(creation>0){interfaces(t,creation,span(t,20,21.7));ctx.save();ctx.globalAlpha=creation;spaced('03 / MADE TO MAKE A DIFFERENCE',100,125,14,3);spaced('BUSINESS WEBSITES',155,915,15,3,silver);spaced('CUSTOM WEB APPLICATIONS',775,915,15,3,silver);spaced('BACKEND SYSTEMS & INTEGRATIONS',1310,915,13,2,silver);text('Illustrative interface concepts',100,997,13,'DM','#95899f');ctx.restore()}
 const metamorph=windowAt(t,20.5,27.5,.9)
 if(metamorph>0){ctx.save();ctx.globalAlpha=metamorph;chrome(t,{x:960,y:lerp(485,430,span(t,23.5,25.2)),size:lerp(1250,920,span(t,21,25.7)),scale:.9,explode:(1-span(t,21,25.2))*1.45,rotation:lerp(-1,.23,span(t,21,25.8))});const a=windowAt(t,24.6,27.1,.6);text('Built to become more.',960,919,68,'Instrument',silver,'center',a);ctx.restore()}
 const signature=span(t,26.7,27.7)*(1-span(t,31.1,32))
 if(signature>0){ctx.save();ctx.globalAlpha=signature;chrome(t,{x:960,y:365,size:700,scale:.92,rotation:.23});spaced('IDIOMORPH',960,754,61,16,silver,'center');spaced('S T U D I O',960,807,17,9,muted,'center');text('Built to become more.',960,890,38,'Instrument',silver,'center');ctx.restore()}
 // Quiet constant frame marks / title, intentionally outside the action.
 if(t>3.8&&t<26.7){ctx.globalAlpha=.65;spaced('IDIOMORPH / STUDIO',100,1017,11,2);spaced('A STUDY IN TRANSFORMATION',1820,1017,11,2,muted,'right');ctx.globalAlpha=1}
 return canvas.toDataURL('image/jpeg',.97).split(',')[1]
}

// Asset mode shares the film's actual mesh, materials and lighting.
export function drawEmblem(){ctx.clearRect(0,0,1920,1080);chrome(28,{x:960,y:540,size:1100,scale:1.05,rotation:.23});return canvas.toDataURL('image/png').split(',')[1]}
window.drawEmblem=drawEmblem
window.drawPoster=()=>{ctx.globalAlpha=1;backdrop(28);chrome(28,{x:960,y:490,size:1030,scale:1,rotation:.23});return canvas.toDataURL('image/png').split(',')[1]}
export const ready=Promise.all([document.fonts.load('32px DM'),document.fonts.load('32px Instrument'),document.fonts.load('italic 32px Instrument')])
