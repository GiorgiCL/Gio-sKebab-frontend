import { execFileSync } from 'node:child_process'
import { writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import ffmpeg from 'ffmpeg-static'
const path=name=>fileURLToPath(new URL(name,import.meta.url)),master=path('./output/idiomorph-master-1080p.mp4')
for(const [i,t] of [1.5,5.7,10,18,25.4,28.5].entries())execFileSync(ffmpeg,['-y','-v','error','-ss',String(t),'-i',master,'-frames:v','1',path(`./validation/decoded-${String(i).padStart(2,'0')}.png`)],{windowsHide:true})
execFileSync(ffmpeg,['-y','-v','error','-framerate','1','-i',path('./validation/')+'decoded-%02d.png','-vf','scale=640:360,tile=3x2','-frames:v','1',path('./validation/film-contact-sheet.png')],{windowsHide:true})
const results=[]
for(const name of ['./output/idiomorph-master-1080p.mp4','../frontend/public/studio/idiomorph-film-720p.mp4','../frontend/public/studio/idiomorph-film-720p.webm']){
 execFileSync(ffmpeg,['-v','error','-xerror','-i',path(name),'-f','null','NUL'],{windowsHide:true,encoding:'utf8',stdio:['ignore','pipe','pipe']})
 results.push({name,decoded:true})
}
await writeFile(path('./validation/media-results.json'),JSON.stringify({reviewedTimestamps:[1.5,5.7,10,18,25.4,28.5],results},null,2));console.log('All three final video files decode without errors. Six final master frames extracted.')
