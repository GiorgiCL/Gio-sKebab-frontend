import { execFileSync } from 'node:child_process'
import { mkdir, writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import ffmpeg from 'ffmpeg-static'
const path=name=>fileURLToPath(new URL(name,import.meta.url)),master=path('./output/idiomorph-master-1080p.mp4')
await mkdir(path('./refinement/reports/'),{recursive:true})
const timestamps=[2.8,6.9,11.8,17.9,21.8,25.6,28.5,31.2]
for(const [i,t] of timestamps.entries())execFileSync(ffmpeg,['-y','-v','error','-ss',String(t),'-i',master,'-frames:v','1',path(`./refinement/reports/decoded-${String(i).padStart(2,'0')}.png`)],{windowsHide:true})
execFileSync(ffmpeg,['-y','-v','error','-framerate','1','-i',path('./refinement/reports/')+'decoded-%02d.png','-vf','scale=640:360,tile=4x2','-frames:v','1',path('./refinement/reports/film-contact-sheet.png')],{windowsHide:true})
const results=[]
for(const name of ['./output/idiomorph-master-1080p.mp4','../frontend/public/studio/idiomorph-film-720p.mp4','../frontend/public/studio/idiomorph-film-720p.webm']){
 execFileSync(ffmpeg,['-v','error','-xerror','-i',path(name),'-f','null','NUL'],{windowsHide:true,encoding:'utf8',stdio:['ignore','pipe','pipe']})
 results.push({name,decoded:true})
}
await writeFile(path('./refinement/reports/media-results.json'),JSON.stringify({reviewedTimestamps:timestamps,results},null,2));console.log('All three final video files decode without errors. Eight final master frames extracted.')
