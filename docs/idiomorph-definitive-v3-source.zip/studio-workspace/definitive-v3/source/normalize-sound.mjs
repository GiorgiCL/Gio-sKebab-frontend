import ffmpeg from 'ffmpeg-static'
import{spawnSync}from'node:child_process'
import{fileURLToPath}from'node:url'
import{writeFile}from'node:fs/promises'
const file=s=>fileURLToPath(new URL(s,import.meta.url)),input=file('../output/idiomorph-intention-v3-original.wav')
const run=args=>{const r=spawnSync(ffmpeg,['-hide_banner',...args],{encoding:'utf8',windowsHide:true,maxBuffer:3e6});if(r.status)throw Error(r.stderr);return r.stderr}
const first=run(['-i',input,'-af','loudnorm=I=-18:TP=-1.5:LRA=11:print_format=json','-f','null','NUL'])
const values=JSON.parse(first.slice(first.lastIndexOf('{'))),filter=`loudnorm=I=-18:TP=-1.5:LRA=11:measured_I=${values.input_i}:measured_TP=${values.input_tp}:measured_LRA=${values.input_lra}:measured_thresh=${values.input_thresh}:offset=${values.target_offset}:linear=true:print_format=json`
const second=run(['-y','-i',input,'-af',filter,'-ar','48000','-c:a','pcm_s16le',file('../output/idiomorph-intention-v3-mix.wav')])
await writeFile(file('../qa/audio-loudness.json'),JSON.stringify({target:{integratedLUFS:-18,truePeakDBTP:-1.5,LRA:11},analysis:values,normalized:JSON.parse(second.slice(second.lastIndexOf('{')))},null,2))
console.log(second.slice(second.lastIndexOf('{')))
await import('./soften-opening.mjs')
