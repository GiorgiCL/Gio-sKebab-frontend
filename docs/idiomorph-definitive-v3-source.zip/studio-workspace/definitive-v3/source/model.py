"""Shared original sculptural geometry, material and lighting production.
Blender 4.5 LTS. No imported model, HDRI, stock texture or add-on.
"""
import bpy, math, json
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/"output"
OUT.mkdir(exist_ok=True)

def reset():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    scene=bpy.context.scene
    scene.render.engine='BLENDER_EEVEE_NEXT'
    scene.render.resolution_x=1920
    scene.render.resolution_y=1080
    scene.render.resolution_percentage=100
    scene.render.image_settings.file_format='PNG'
    scene.render.film_transparent=False
    scene.render.fps=24
    scene.world.use_nodes=True
    scene.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.012,.008,.021,1)
    scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.28
    scene.view_settings.view_transform='AgX'
    scene.view_settings.look='AgX - Medium High Contrast'
    scene.render.image_settings.color_mode='RGB'
    return scene

def material(name,color,metal=0,rough=.4,grain=False):
    mat=bpy.data.materials.new(name); mat.use_nodes=True
    bs=mat.node_tree.nodes.get('Principled BSDF')
    bs.inputs['Base Color'].default_value=(*color,1)
    bs.inputs['Metallic'].default_value=metal
    bs.inputs['Roughness'].default_value=rough
    bs.inputs['Coat Weight'].default_value=.08 if metal else .06
    bs.inputs['Coat Roughness'].default_value=.22
    if grain:
        tex=mat.node_tree.nodes.new('ShaderNodeTexNoise')
        tex.inputs['Scale'].default_value=190
        tex.inputs['Detail'].default_value=2.4
        bump=mat.node_tree.nodes.new('ShaderNodeBump')
        bump.inputs['Strength'].default_value=.06
        bump.inputs['Distance'].default_value=.004
        mat.node_tree.links.new(tex.outputs['Fac'],bump.inputs['Height'])
        mat.node_tree.links.new(bump.outputs['Normal'],bs.inputs['Normal'])
    return mat

def camera(location,target,lens=60,ortho=None):
    data=bpy.data.cameras.new('Directed camera')
    ob=bpy.data.objects.new('Directed camera',data)
    bpy.context.collection.objects.link(ob)
    ob.location=location; point(ob,target)
    data.lens=lens
    if ortho: data.type='ORTHO';data.ortho_scale=ortho
    bpy.context.scene.camera=ob
    return ob

def point(ob,target):
    ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler()

def area(name,location,target,power,color,size=4,ratio=1):
    data=bpy.data.lights.new(name,'AREA');data.energy=power;data.color=color
    data.shape='RECTANGLE';data.size=size;data.size_y=size*ratio
    ob=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(ob)
    ob.location=location;point(ob,target)
    return ob

def rig():
    area('Long silver softbox',(-3.4,-3.6,2.8),(0,0,0),600,(.89,.85,1),3,.12)
    area('Soft frontal reflection',(1,-5,3),(0,0,0),180,(.72,.6,.94),4,.5)
    area('Violet edge',(3,.8,1.2),(0,0,.1),500,(.38,.12,1),3,.13)
    area('Warm edge',(-1,1,3),(0,0,0),350,(1,.84,.66),3,.15)
    area('Low violet bounce',(0,-2,-3),(0,0,0),180,(.45,.17,1),3,.2)

def mesh_object(name,verts,faces,mat=None):
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update()
    ob=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(ob)
    if mat: mesh.materials.append(mat)
    for p in mesh.polygons:p.use_smooth=True
    return ob

def emblem():
    data=json.loads((ROOT/'emblem-geometry.json').read_text())
    parent=bpy.data.objects.new('Canonical folded emblem',None)
    bpy.context.collection.objects.link(parent)
    ribbons=[]
    for k,part in enumerate(data['parts']):
        p=part['positions'];verts=[(p[i],-p[i+2],p[i+1])for i in range(0,len(p),3)]
        ix=part['indices'];faces=[ix[i:i+3]for i in range(0,len(ix),3)]
        mat=material('Brushed titanium'if k==0 else'Ultraviolet anodized metal',(.33,.31,.38)if k==0 else(.32,.105,.64),.92,.26,True)
        ob=mesh_object(part['name'],verts,faces,mat);ob.parent=parent
        solid=ob.modifiers.new('Manufactured sheet thickness','SOLIDIFY');solid.thickness=.018;solid.offset=0
        bevel=ob.modifiers.new('Fine machined edges','BEVEL');bevel.width=.006;bevel.segments=3
        # Shape key enables a physical transition from a flat sheet into the folded volume.
        ob.shape_key_add(name='Folded form')
        flat=ob.shape_key_add(name='Before the fold')
        for j,co in enumerate(flat.data):
            x,y,z=part['flat'][j*3:j*3+3];co.co=(x,-z,y)
        ribbons.append(ob)
    return parent,ribbons

def box(name,location,scale,mat,bevel=0):
    bpy.ops.mesh.primitive_cube_add(size=1,location=location)
    ob=bpy.context.object;ob.name=name;ob.scale=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    ob.data.materials.append(mat)
    if bevel:
        m=ob.modifiers.new('Soft crafted corners','BEVEL');m.width=bevel;m.segments=4
        ob.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
    return ob

def curve(name,points,mat,radius=.01):
    data=bpy.data.curves.new(name,'CURVE');data.dimensions='3D'
    data.bevel_depth=radius;data.bevel_resolution=3
    data.use_fill_caps=True
    spline=data.splines.new('BEZIER');spline.bezier_points.add(len(points)-1)
    for p,co in zip(spline.bezier_points,points):
        p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
    ob=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(ob)
    data.materials.append(mat)
    return ob

def key(ob,frame,location=None,rotation=None,scale=None):
    if location is not None:ob.location=location;ob.keyframe_insert(data_path='location',frame=frame)
    if rotation is not None:ob.rotation_euler=rotation;ob.keyframe_insert(data_path='rotation_euler',frame=frame)
    if scale is not None:ob.scale=(scale,)*3 if isinstance(scale,(int,float))else scale;ob.keyframe_insert(data_path='scale',frame=frame)

def render(path,frame=1):
    scene=bpy.context.scene;scene.frame_set(frame);scene.render.filepath=str(path)
    bpy.ops.render.render(write_still=True)
