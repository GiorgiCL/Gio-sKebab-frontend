// Original illustrative design studies, never client work.
const canvas=document.querySelector('canvas'),c=canvas.getContext('2d'),logo=new Image();logo.src='/brand/IdiomorphLogo.png'
const text=(s,x,y,size=30,font='DM',color='#3f3047')=>{c.font=`${size}px ${font}`;c.fillStyle=color;c.fillText(s,x,y)}
const line=(x,y,X,Y,color='#c8b9ce',w=1)=>{c.beginPath();c.strokeStyle=color;c.lineWidth=w;c.moveTo(x,y);c.lineTo(X,Y);c.stroke()}
const rect=(x,y,w,h,color)=>{c.fillStyle=color;c.fillRect(x,y,w,h)}
await Promise.all([logo.decode(),document.fonts.load('40px DM'),document.fonts.load('100px Instrument'),document.fonts.load('italic 100px Instrument')])
window.plate=type=>{
 c.clearRect(0,0,2200,1400)
 if(type.startsWith('website')){
  rect(0,0,2200,1400,'#eee7e3');text('AN INTERFACE STUDY',100,98,25);text('Explore  /  Contact',1710,98,25);line(100,138,2100,138)
  const d=type==='website-refined'?35:0
  text('Make room',110,464-d,184,'Instrument');text('for what matters.',110,660+d,165,'Instrument')
  text('A distinctive place for your business.',118,806,35,'DM','#74617c');line(118,938,450,938,'#765083',2);text('Start something  ↗',118,1000,33)
  rect(1320,234,762,1050,'#1a1222');c.drawImage(logo,230,120,800,1000,1351,275,700,875)
  text('Considered at every size.',118,1220,25,'DM','#7b6483');text('ORIGINAL CONCEPT · NOT CLIENT WORK',118,1315,18,'DM','#7b6483')
 }else{
  const index=Number(type.slice(-1)),system=type.startsWith('system'),titles=system?['Experience','Application','Your systems']:['A request','A clear next step','Ready to use'],copy=system?['A clear point of contact.','Useful logic, underneath.','Thoughtfully joined up.']:['Start with what you need.','Know where things stand.','Keep moving forward.']
  rect(0,0,2200,1400,'#ece6de');text((system?['INTERFACE','ENGINEERING','CONNECTIONS']:['REQUEST','REVIEW','READY'])[index],130,170,54,'DM','#856691');line(130,230,2070,230)
  text(titles[index],130,620,185,'Instrument');text(copy[index],136,825,64,'DM','#75637b')
  if(index===2){line(1750,540,1840,645,'#8c659c',17);line(1840,645,2030,400,'#8c659c',17)}
  else{rect(150,1010,1000,3,'#a98ab8');text('One thoughtful step at a time.',136,1210,43,'Instrument','#81678b')}
 }
 return canvas.toDataURL('image/png').split(',')[1]
};window.ready=true
