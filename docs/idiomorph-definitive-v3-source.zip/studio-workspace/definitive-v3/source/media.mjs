import ffmpeg from'ffmpeg-static'
import{spawnSync}from'node:child_process'
import{fileURLToPath}from'node:url'
import{mkdir,stat,writeFile}from'node:fs/promises'
const mode=process.argv[2]||'animatic',file=s=>fileURLToPath(new URL(s,import.meta.url))
const run=args=>{const r=spawnSync(ffmpeg,['-y','-v','error',...args],{windowsHide:true,encoding:'utf8',maxBuffer:2e6});if(r.status)throw Error(r.stderr)}
const picture=file('../output/idiomorph-intention-v3-'+mode+'-picture.mp4'),audio=file('../output/idiomorph-intention-v3-mix.wav')
const master=file('../output/idiomorph-intention-v3-'+(mode==='final'?'master-1080p':mode)+'.mp4')
run(['-i',picture,'-i',audio,'-c:v','copy','-c:a','aac','-b:a','192k','-movflags','+faststart','-shortest',master])
const review=file('../qa/'+mode+'-frames/');await mkdir(review,{recursive:true})
for(let t=0;t<42;t++)run(['-ss',String(t+.35),'-i',master,'-frames:v','1',review+String(t).padStart(2,'0')+'.png'])
run(['-framerate','1','-start_number','0','-i',review+'%02d.png','-vf','scale=400:225,tile=7x6','-frames:v','1',file('../qa/'+mode+'-contact-sheet.png')])
if(mode==='final'){
 const web=file('../../../frontend/public/studio/v3/');await mkdir(web,{recursive:true})
 run(['-i',master,'-vf','scale=1280:720','-c:v','libx264','-preset','slow','-crf','23','-c:a','aac','-b:a','128k','-movflags','+faststart',web+'idiomorph-intention-v3-720p.mp4'])
 run(['-i',master,'-vf','scale=1280:720','-c:v','libvpx-vp9','-b:v','0','-crf','33','-row-mt','1','-cpu-used','3','-c:a','libopus','-b:a','96k',web+'idiomorph-intention-v3-720p.webm'])
 await import('./poster.mjs')
 for(const[stage,t]of [['discover',4.6],['design',10.8],['engineer',22.5],['refine',25.2],['deliver',39]])for(const[size,suffix]of [['960:540',''],['480:270','-small']])run(['-ss',String(t),'-i',master,'-vf','scale='+size,'-c:v','libwebp','-quality','86','-frames:v','1',web+'process-'+stage+suffix+'.webp'])
 const results=[]
 for(const name of [master,web+'idiomorph-intention-v3-720p.mp4',web+'idiomorph-intention-v3-720p.webm']){run(['-xerror','-i',name,'-f','null','NUL']);results.push({file:name,bytes:(await stat(name)).size,strictDecode:true})}
 await writeFile(file('../qa/media-results.json'),JSON.stringify({duration:42,fps:24,outputs:results},null,2));console.log(JSON.stringify(results,null,2))
}
console.log('42-second '+mode+' muxed; all-second contact sheet extracted.')
