"""FROM HUMAN INTENTION TO DIGITAL FORM — original 42 s Blender production.
All scene geometry, hand pose, textures, camera direction and timing are authored here.
The human scene is an intentional clay sculpture, not purported live footage.
Run with -- --mode stills|animatic|preview|final.
"""
import sys, math, argparse
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from model import *
args=argparse.ArgumentParser();args.add_argument('--mode',default='stills');opts=args.parse_args(sys.argv[sys.argv.index('--')+1:]if'--'in sys.argv else[])
scene=reset();scene.frame_end=1008;scene.render.fps=24
scene.render.image_settings.compression=25
# Eevee uses physically based sheet materials, area sources, real camera DOF and shadows.
try: scene.eevee.taa_render_samples=32 if opts.mode!='final'else 64
except: pass
paper=material('Warm cotton paper',(.76,.69,.59),0,.78,True)
desk=material('Blackened plum desk',(.032,.018,.043),.15,.4,True)
graphite=material('Graphite on paper',(.035,.024,.04),.12,.6)
wood=material('Natural cedar pencil',(.38,.19,.065),0,.34,True)
clay=material('Warm sculpted clay — intentionally stylized hand',(.46,.35,.26),0,.63,True)
cloth=material('Charcoal studio sleeve',(.026,.02,.033),0,.92,True)
silver=material('Machined silver detail',(.46,.43,.49),.95,.28)
lavender=material('Lavender working detail',(.29,.16,.41),.65,.28)
stage_roots=[]
def stage(name,x):
    ob=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(ob);ob.location.x=x;stage_roots.append(ob);return ob,set(bpy.data.objects)
def attach(root,before):
    for ob in set(bpy.data.objects)-before:
        if ob!=root and ob.parent is None:ob.parent=root
def marker(name,t,cam):
    m=scene.timeline_markers.new(name,frame=round(t*24)+1);m.camera=cam
def aim_key(cam,t,loc,target,lens=None):
    cam.location=loc;point(cam,target)
    cam.keyframe_insert(data_path='location',frame=t*24+1);cam.keyframe_insert(data_path='rotation_euler',frame=t*24+1)
    if lens:cam.data.lens=lens;cam.data.keyframe_insert(data_path='lens',frame=t*24+1)
def focus(cam,target,aperture=4):
    cam.data.dof.use_dof=True
    cam.data.dof.aperture_fstop=aperture
    empty=bpy.data.objects.new('Focus / '+cam.name,None);bpy.context.collection.objects.link(empty);empty.location=target
    cam.data.dof.focus_object=empty
    return empty
def sphere(name,location,scale,mat):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=16,location=location)
    ob=bpy.context.object;ob.name=name;ob.scale=scale;ob.data.materials.append(mat)
    for p in ob.data.polygons:p.use_smooth=True
    return ob
def cylinder_between(name,a,b,radius,mat,vertices=32):
    delta=Vector(b)-Vector(a)
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=delta.length,location=(Vector(a)+Vector(b))/2)
    ob=bpy.context.object;ob.name=name;ob.rotation_euler=delta.to_track_quat('Z','Y').to_euler();ob.data.materials.append(mat)
    bevel=ob.modifiers.new('Fine edge','BEVEL');bevel.width=.005;bevel.segments=2
    return ob
def screen(name,plate,location,w,h):
    board=box(name+' / physical board',location,(w,.07,h),paper,.025)
    mat=bpy.data.materials.new(name+' / original type');mat.use_nodes=True
    nodes=mat.node_tree.nodes;bs=nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=.65
    tex=nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(OUT/'plates'/(plate+'.png')))
    mat.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
    mat.node_tree.links.new(tex.outputs['Color'],bs.inputs['Emission Color']);bs.inputs['Emission Strength'].default_value=.11
    verts=[(-w/2,-.04,-h/2),(w/2,-.04,-h/2),(w/2,-.04,h/2),(-w/2,-.04,h/2)]
    face=mesh_object(name+' / image plane',verts,[(0,1,2,3)],mat);face.location=location
    uv=face.data.uv_layers.new()
    for loop,co in zip(face.data.polygons[0].loop_indices,[(0,0),(1,0),(1,1),(0,1)]):uv.data[loop].uv=co
    return board,face,bs,tex

# ACT I: deliberate contact and an original sculpted writing gesture.
human,before=stage('01 / Human intention',0)
box('Architectural desk',(0,0,-.17),(11,9,.28),desk,.05)
box('Textured paper / a place to begin',(0,.15,.015),(5.9,4.4,.08),paper,.012)
area('Warm window',(-2,-1,5),(0,0,0),700,(1,.79,.58),4,.6)
area('Quiet cool room',(3,1,4),(0,0,.2),250,(.62,.55,.82),3,.7)
hand=bpy.data.objects.new('Original five-finger writing pose',None);bpy.context.collection.objects.link(hand)
hand_before=set(bpy.data.objects)
sphere('Palm',(1.72,.83,.65),(.62,.5,.19),clay)
cylinder_between('Wrist',(2,.68,.61),(2.85,.67,.54),.31,clay)
cylinder_between('Sleeve',(2.75,.67,.54),(4.7,.65,.4),.4,cloth)
fingers=[
 [(1.46,.7,.75),(1.1,.78,1.0),(.68,.57,.92),(.52,.42,.83)],
 [(1.53,1.0,.63),(1.04,1.15,.61),(.81,.94,.33),(1.02,.72,.32)],
 [(1.8,1.15,.61),(1.38,1.4,.54),(1.17,1.19,.26),(1.4,1.01,.28)],
 [(2.04,1.14,.58),(1.8,1.49,.48),(1.61,1.33,.26),(1.8,1.14,.29)],
 [(1.82,.44,.57),(1.22,.18,.42),(.69,.09,.43),(.43,.26,.57)],
]
for i,pts in enumerate(fingers):
    finger=curve(['Index','Middle','Ring','Little','Thumb'][i],pts,clay,[.13,.145,.13,.105,.16][i])
    sphere('Finger pad '+str(i),pts[-1],(.125,.135,.105),clay)
# Fuse the authored pose into a continuous sculpture, rather than separate tubes.
clay_parts=[ob for ob in set(bpy.data.objects)-hand_before if ob.type in {'MESH','CURVE'} and ob.data.materials and ob.data.materials[0]==clay]
bpy.ops.object.select_all(action='DESELECT')
for ob in clay_parts:ob.select_set(True)
bpy.context.view_layer.objects.active=clay_parts[0]
bpy.ops.object.convert(target='MESH');bpy.ops.object.join()
sculpt=bpy.context.object;sculpt.name='Continuous sculpted human writing gesture'
bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
remesh=sculpt.modifiers.new('Unified hand surface','REMESH');remesh.mode='VOXEL';remesh.voxel_size=.045;remesh.use_smooth_shade=True
bpy.ops.object.modifier_apply(modifier=remesh.name)
smooth=sculpt.modifiers.new('Hand-finished transitions','SMOOTH');smooth.factor=.7;smooth.iterations=5
bpy.ops.object.modifier_apply(modifier=smooth.name)
sub=sculpt.modifiers.new('Sculptural finish','SUBSURF');sub.levels=1
direction=Vector((.64,.45,.85)).normalized();tip=Vector((0,0,.065))
# Hexagonal cedar barrel and actual graphite contact.
cylinder_between('Cedar hexagonal barrel',tip+direction*.2,tip+direction*2.4,.052,wood,6)
cylinder_between('Graphite core',tip,tip+direction*.23,.012,graphite,16)
bpy.ops.mesh.primitive_cone_add(vertices=6,radius1=.006,radius2=.052,depth=.24,location=tip+direction*.12)
p=bpy.context.object;p.name='Sharpened cedar';p.rotation_euler=direction.to_track_quat('Z','Y').to_euler();p.data.materials.append(wood)
for ob in set(bpy.data.objects)-hand_before:
    if ob.parent is None:ob.parent=hand
handwriting=[[[0,0],[10,68],[28,24],[44,66],[62,0]],[[78,-4],[74,69],[79,34],[94,27],[104,65]],[[150,34],[137,27],[120,36],[116,55],[126,67],[143,57],[149,33],[147,64],[160,67]],[[184,2],[177,60],[184,69],[195,65]],[[165,24],[202,20]],[[231,31],[226,66]],[[232,12],[233,13]],[[260,66],[269,-2],[281,-7],[291,-1]],[[251,28],[284,24]],[[325,4],[338,-2],[353,5],[354,20],[340,34],[336,45]],[[336,62],[337,63]]]
strokes=[]
for i,points in enumerate(handwriting):
    pts=[(-1.65+x/135,.7-y/135,.061)for x,y in points]
    ob=curve('Handwritten stroke '+str(i),pts,graphite,.007)
    start=.55+i*.48;end=start+.34
    ob.data.bevel_factor_end=0;ob.data.keyframe_insert(data_path='bevel_factor_end',frame=1)
    ob.data.keyframe_insert(data_path='bevel_factor_end',frame=start*24+1)
    ob.data.bevel_factor_end=1;ob.data.keyframe_insert(data_path='bevel_factor_end',frame=end*24+1)
    strokes.append((start,end,pts))
for f in range(1,169):
    t=(f-1)/24;position=Vector(strokes[0][2][0])
    for a,b,pts in strokes:
        if t>=a:
            q=max(0,min(1,(t-a)/(b-a)))*(len(pts)-1);j=min(len(pts)-2,int(q));position=Vector(pts[j]).lerp(Vector(pts[j+1]),min(1,q-j))
    if t>6:position.z+=(t-6)**2*.8
    hand.location=(position.x,position.y,position.z-.061);hand.rotation_euler.z=.025*math.sin(t*1.8)
    hand.keyframe_insert(data_path='location',frame=f);hand.keyframe_insert(data_path='rotation_euler',frame=f)
macro=camera((-1.3,-3.15,1.7),(-1.2,.4,.08),lens=77);focus(macro,(-1.15,.48,.07),3.2)
aim_key(macro,0,(-1.35,-3.15,1.7),(-1.25,.4,.07),77);aim_key(macro,3,(-.6,-3.35,1.9),(-.55,.45,.07),77)
marker('01 / Contact, then a decision',0,macro)
wide=camera((3.2,-4.8,6.2),(.15,.4,.15),lens=54);focus(wide,(.2,.4,.15),5)
aim_key(wide,3,(3.2,-4.8,6.2),(.15,.4,.15),54);aim_key(wide,7,(2.8,-4.6,5.5),(.3,.4,.15),54)
marker('02 / A human gesture',3,wide)

# ACT II: the same sheet geometry rises from the paper and acquires its material.
emblem_root,formation=emblem()
key(emblem_root,1,scale=0);key(emblem_root,168,scale=0);key(emblem_root,169,location=(0,0,.09),rotation=(math.pi/2,0,0),scale=.64)
key(emblem_root,240,location=(0,0,1.1),rotation=(.55,0,-.12),scale=.75)
key(emblem_root,336,location=(0,0,1.55),rotation=(0,0,.05),scale=.83)
for ob in formation:
    shape=ob.data.shape_keys.key_blocks['Before the fold'];shape.value=1;shape.keyframe_insert(data_path='value',frame=169);shape.value=0;shape.keyframe_insert(data_path='value',frame=313)
    bs=ob.data.materials[0].node_tree.nodes.get('Principled BSDF');original=bs.inputs['Base Color'].default_value[:]
    for socket,a,b in [('Metallic',.04,.92),('Roughness',.8,.26)]:
        bs.inputs[socket].default_value=a;bs.inputs[socket].keyframe_insert(data_path='default_value',frame=169);bs.inputs[socket].default_value=b;bs.inputs[socket].keyframe_insert(data_path='default_value',frame=306)
    bs.inputs['Base Color'].default_value=(.045,.03,.055,1);bs.inputs['Base Color'].keyframe_insert(data_path='default_value',frame=169)
    bs.inputs['Base Color'].default_value=original;bs.inputs['Base Color'].keyframe_insert(data_path='default_value',frame=295)
lights_before=set(bpy.data.objects);rig()
for light in set(bpy.data.objects)-lights_before:
    if light.type=='LIGHT':
        power=light.data.energy;light.data.energy=0;light.data.keyframe_insert(data_path='energy',frame=168)
        light.data.energy=power;light.data.keyframe_insert(data_path='energy',frame=225)
rise=camera((0,-4.9,5.5),(0,0,.2),lens=48);focus(rise,(0,0,1),5)
aim_key(rise,7,(0,-4.9,5.5),(0,0,.15),48);aim_key(rise,10.5,(2.8,-5.3,3.6),(0,0,1),53);aim_key(rise,14,(2.7,-6.9,2.6),(0,0,1.5),54)
marker('03 / Thought becomes topology',7,rise)
attach(human,before)

# ACT III: original design and software studies, printed on dimensional work surfaces.
work,before=stage('04 / Interface shaping',24)
box('Dusky work surface',(0,1,-.17),(12,9,.25),desk,.05)
board,plane,bs,tex=screen('Business website study','website',(0,0,1.8),6.3,4.0)
refined=bs.id_data.nodes.new('ShaderNodeTexImage');refined.image=bpy.data.images.load(str(OUT/'plates/website-refined.png'))
mix=bs.id_data.nodes.new('ShaderNodeMixRGB');bs.id_data.links.new(tex.outputs['Color'],mix.inputs[1]);bs.id_data.links.new(refined.outputs['Color'],mix.inputs[2]);bs.id_data.links.new(mix.outputs['Color'],bs.inputs['Base Color']);bs.id_data.links.new(mix.outputs['Color'],bs.inputs['Emission Color'])
mix.inputs[0].default_value=0;mix.inputs[0].keyframe_insert(data_path='default_value',frame=392);mix.inputs[0].default_value=1;mix.inputs[0].keyframe_insert(data_path='default_value',frame=393)
for fc in bs.id_data.animation_data.action.fcurves:
    if 'inputs[0]'in fc.data_path:
        for kp in fc.keyframe_points:kp.interpolation='CONSTANT'
pointer=mesh_object('A deliberate design adjustment',[(0,-.09,0),(.0,-.09,-.24),(.055,-.09,-.18),(.12,-.09,-.29),(.16,-.09,-.27),(.10,-.09,-.16),(.2,-.09,-.16)],[(0,1,2,3,4,5,6)],graphite)
key(pointer,337,location=(-1.6,-.08,2.1));key(pointer,385,location=(-.52,-.08,2.24));key(pointer,409,location=(-.4,-.08,1.2));key(pointer,432,location=(.2,-.08,1.15))
area('Soft working daylight',(-2,-4,6),(0,0,1.5),650,(1,.87,.72),5,.6);area('Lavender wall',(4,1,3),(0,0,1),450,(.6,.39,.91),3,.5)
design_cam=camera((.2,-8.5,3.0),(0,0,1.8),lens=42);focus(design_cam,(0,0,1.8),8)
aim_key(design_cam,14,(.2,-8.5,3),(0,0,1.8),42);aim_key(design_cam,18,(-.25,-8.1,2.5),(0,0,1.8),43)
marker('04 / Find the feeling',14,design_cam);attach(work,before)

flow,before=stage('05 / Software for people',36)
box('Workflow foundation',(0,.5,-.25),(12,8,.2),desk,.05)
cards=[]
for i in range(3):
    card,face,_,_=screen('Workflow / '+str(i),'flow-'+str(i),(-2.18+i*2.18,0,1.12),1.95,1.24)
    for ob in [card,face]:
        key(ob,433,location=(-2.18+i*2.18,0,1.12))
        key(ob,round((18.3+i*.75)*24)+1,location=(-2.18+i*2.18,-.13,1.32))
        key(ob,round((19.05+i*.75)*24)+1,location=(-2.18+i*2.18,0,1.12))
    cards.append((card,face))
curve('One clear path',[(-2.2,.07,.3),(0,.07,.3),(2.2,.07,.3)],lavender,.015)
area('Human-scale warm source',(-1,-3,5),(0,0,1),800,(1,.86,.72),5,.65);area('Quiet edge',(4,1,4),(0,0,1),500,(.54,.32,.86),4,.5)
flow_cam=camera((-.65,-7.4,2.7),(0,0,1),lens=38);focus(flow_cam,(0,0,1.1),8)
aim_key(flow_cam,18,(-.65,-7.4,2.7),(0,0,1),38);aim_key(flow_cam,21,(.55,-7.2,2.25),(0,0,1),38)
marker('05 / A useful next step',18,flow_cam);attach(flow,before)

systems,before=stage('06 / Connected systems',48)
box('System foundation',(0,.6,-.25),(12,8,.2),desk,.05)
for i in range(3):screen('System / '+str(i),'system-'+str(i),(-2.12+i*2.12,0,1.12),1.8,1.15)
connection=curve('Intelligence in the connections',[(-2.1,0,.45),(-1,-.65,.4),(0,0,.45),(1,.65,.4),(2.1,0,.45)],silver,.025)
connection.data.bevel_factor_end=0;connection.data.keyframe_insert(data_path='bevel_factor_end',frame=505);connection.data.bevel_factor_end=1;connection.data.keyframe_insert(data_path='bevel_factor_end',frame=535)
pulse=sphere('A single meaningful signal',(-2.1,0,.45),(.065,.065,.065),lavender)
for f in range(529,577):
    q=(f-529)/47;pulse.location=(-2.1+4.2*q,-.55*math.sin(q*2*math.pi),.45);pulse.keyframe_insert(data_path='location',frame=f)
area('System key',(-3,-4,5),(0,0,1),750,(.89,.83,1),5,.6);area('Purple reflected edge',(4,1,4),(0,0,1),550,(.5,.24,.9),3,.4)
system_cam=camera((1.3,-7.4,3.4),(0,0,.9),lens=38);focus(system_cam,(0,0,1),7)
aim_key(system_cam,21,(1.3,-7.4,3.4),(0,0,.9),38);aim_key(system_cam,24,(.3,-7.3,2.9),(0,0,.9),38)
marker('06 / Things, working together',21,system_cam);attach(systems,before)

# ACT IV/V: physical folds, material close-up, construction, resolution.
sculpture,before=stage('07 / Sculpted metamorphosis',12)
box('Blackened architectural plinth',(0,0,-.15),(18,18,.2),desk,.07)
root,ribbons=emblem();root.location.z=2.15
for i,ob in enumerate(ribbons):
    sign=-1 if i==0 else 1
    key(ob,577,location=(sign*1.25,.25*i,.12*sign),rotation=(.15*sign,.3*sign,.5*sign))
    key(ob,673,location=(sign*.65,.15*i,.07*sign),rotation=(.1*sign,.18*sign,.25*sign))
    key(ob,793,location=(0,0,0),rotation=(0,0,0))
    shape=ob.data.shape_keys.key_blocks['Before the fold'];shape.value=.9;shape.keyframe_insert(data_path='value',frame=577);shape.value=.45;shape.keyframe_insert(data_path='value',frame=661);shape.value=0;shape.keyframe_insert(data_path='value',frame=793)
key(root,793,location=(0,0,2.15),scale=1);key(root,865,location=(0,0,2.6),scale=.75)
rig()
close=camera((-1.5,-2.9,3),(-1.85,0,2.6),lens=70);focus(close,(-1.7,0,2.55),4)
aim_key(close,24,(-1.5,-2.9,3),(-1.85,0,2.6),70);aim_key(close,27,(-1,-3.1,2.9),(-1.55,0,2.55),70)
marker('07 / Material, light, tension',24,close)
orbit=camera((4.3,-6.1,3.6),(0,0,2.1),lens=49);focus(orbit,(0,0,2.1),6)
aim_key(orbit,27,(4.3,-6.1,3.6),(0,0,2.1),49)
aim_key(orbit,30,(1.5,-5.5,2.5),(0,0,2.1),57)
aim_key(orbit,33,(.5,-9.3,2.5),(0,0,2.15),48)
aim_key(orbit,35,(0,-9.5,2.45),(0,0,2.2),48)
marker('08 / Two perspectives, one whole',27,orbit)
final=camera((0,-9,2.2),(0,0,2.2),ortho=8.2);focus(final,(0,0,2.5),8)
marker('09 / Idiomorph Studio',35,final);attach(sculpture,before)

# Pack original textures and save a real editable Blender timeline, cameras and shape keys.
for image in bpy.data.images:
    if image.source=='FILE':image.pack()
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'idiomorph-intention-v3.blend'))
if opts.mode=='stills':
    scene.render.resolution_percentage=50
    for t in [1.2,4.6,9.2,12.5,16.5,19.5,22.5,25.2,29.5,33.5,36.5]:
        render(OUT/('shot-'+str(t)+'.png'),round(t*24)+1)
else:
    step={'animatic':4,'preview':2,'final':1}[opts.mode]
    scene.render.resolution_percentage={'animatic':33,'preview':50,'final':100}[opts.mode]
    dest=OUT/opts.mode;dest.mkdir(exist_ok=True)
    for frame in range(1,1009,step):
        render(dest/('%04d.png'%frame),frame)
        if(frame-1)%(24*3)==0:print('PROGRESS',opts.mode,frame,'/ 1008',flush=True)
print('Production complete:',opts.mode,flush=True)
