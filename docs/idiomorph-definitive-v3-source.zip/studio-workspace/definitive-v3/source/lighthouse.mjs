import lighthouse from '../../../.verification/frontend-tools/node_modules/lighthouse/core/index.js'
import { chromium } from '../../browser-tool.mjs'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
await mkdir(new URL('../qa/lighthouse/',import.meta.url),{recursive:true})
const results=[]
for(const formFactor of (process.argv[2] ? [process.argv[2]] : ['mobile','desktop'])){
 const port=formFactor==='mobile'?19359:19360
 const chrome=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:[`--remote-debugging-port=${port}`,'--disable-gpu','--no-first-run']})
 try {
  const result=await lighthouse('http://localhost:4173/studio',{port,logLevel:'error',output:['html','json'],onlyCategories:['performance','accessibility','best-practices','seo'],formFactor,...(formFactor==='desktop'?{emulatedUserAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.8059.80 Safari/537.36'}:{}),screenEmulation:{mobile:formFactor==='mobile',width:formFactor==='mobile'?390:1440,height:formFactor==='mobile'?844:1000,deviceScaleFactor:1,disabled:false},throttlingMethod:'simulate',...(formFactor==='desktop'?{throttling:{rttMs:40,throughputKbps:10240,cpuSlowdownMultiplier:1,requestLatencyMs:0,downloadThroughputKbps:0,uploadThroughputKbps:0}}:{})})
  await writeFile(new URL(`../qa/lighthouse/lighthouse-${formFactor}.html`,import.meta.url),result.report[0]);await writeFile(new URL(`../qa/lighthouse/lighthouse-${formFactor}.json`,import.meta.url),result.report[1])
  const lhr=result.lhr
  const summary={formFactor,version:lhr.lighthouseVersion,conditions:lhr.configSettings,scores:Object.fromEntries(Object.entries(lhr.categories).map(([k,v])=>[k,Math.round(v.score*100)])),metrics:Object.fromEntries(['first-contentful-paint','largest-contentful-paint','total-blocking-time','cumulative-layout-shift','speed-index','total-byte-weight'].map(id=>[id,{value:lhr.audits[id]?.numericValue,display:lhr.audits[id]?.displayValue}])),opportunities:Object.entries(lhr.audits).filter(([,v])=>v.score!==null&&v.score<1&&v.scoreDisplayMode!=='informative').map(([id,v])=>({id,title:v.title,score:v.score,display:v.displayValue}))}
  results.push(summary);console.log(JSON.stringify(summary,null,2))
 } finally {await chrome.close()}
}
const target=new URL('../qa/lighthouse/lighthouse-summary.json',import.meta.url),previous=process.argv[2]?JSON.parse(await readFile(target,'utf8').catch(()=>'[]')):[];await writeFile(target,JSON.stringify([...previous.filter(x=>!results.some(r=>r.formFactor===x.formFactor)),...results],null,2))
