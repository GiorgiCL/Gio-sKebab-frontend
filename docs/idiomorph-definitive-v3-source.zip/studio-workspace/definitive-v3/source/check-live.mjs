import {chromium} from '../../browser-tool.mjs'
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']})
try{
 const page=await browser.newPage({viewport:{width:1440,height:1000}})
 page.on('pageerror',e=>console.log('ERROR',e.message));page.on('console',m=>{if(m.type()==='error')console.log('CONSOLE',m.text())})
 await page.goto('http://localhost:4173/studio');await page.locator('h1').waitFor()
 await page.getByRole('button',{name:/Explore the symbol/}).click()
 await page.waitForSelector('.im-emblem-ready',{timeout:30000});await page.waitForTimeout(500)
 await page.screenshot({path:'definitive-v3/qa/live-front.png'})
 await page.getByRole('button',{name:'Three-quarter',exact:true}).click();await page.waitForTimeout(700)
 await page.screenshot({path:'definitive-v3/qa/live-perspective.png'})
 await page.locator('#im-emblem-unfold').fill('100');await page.waitForTimeout(800)
 await page.screenshot({path:'definitive-v3/qa/live-unfold.png'})
 console.log('Actual WebGL emblem front, perspective and unfolded states rendered.')
}finally{await browser.close()}
