// Original film typography and final brand resolve over actual Blender renders.
const canvas=document.querySelector('#film'),c=canvas.getContext('2d'),logo=new Image();logo.src='/brand/IdiomorphLogo.png'
const mode=new URLSearchParams(location.search).get('mode')||'animatic',step={animatic:4,preview:2,final:1}[mode],fps=24/step
const clamp=x=>Math.max(0,Math.min(1,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)},span=(t,a,b)=>ease((t-a)/(b-a)),cache=new Map()
const text=(s,x,y,size,font='Instrument',color='#f1e9f5',align='left')=>{c.fillStyle=color;c.font=`${size}px ${font}`;c.textAlign=align;c.fillText(s,x,y)}
function spaced(s,x,y,size,gap,color='#f1e9f5'){c.font=`${size}px DM`;c.textAlign='left';c.fillStyle=color;let width=[...s].reduce((v,a)=>v+c.measureText(a).width+gap,0)-gap,px=x-width/2;for(const a of s){c.fillText(a,px,y);px+=c.measureText(a).width+gap}}
async function frameAt(t){
 const index=Math.min(1008-step+1,1+Math.floor(Math.min(t,41.999)*fps)*step),src=`../output/${mode}/${String(index).padStart(4,'0')}.png`
 if(!cache.has(src)){const image=new Image();image.src=src;cache.set(src,image.decode().then(()=>image))}
 if(cache.size>18)cache.delete(cache.keys().next().value)
 return cache.get(src)
}
await Promise.all([logo.decode(),document.fonts.load('40px DM'),document.fonts.load('100px Instrument')])
window.renderFrame=async t=>{
 const image=await frameAt(t);c.globalAlpha=1;c.globalCompositeOperation='source-over';c.fillStyle='#08070b';c.fillRect(0,0,1920,1080);c.drawImage(image,0,0,1920,1080)
 if(t<7){c.save();c.globalAlpha=span(t,.3,1.1)*(1-span(t,6.5,7));text(t<3?'A thought.':'Given a little care.',100,975,t<3?85:68,'Instrument','#493345');c.restore()}
 if(t>=7&&t<14){c.save();c.globalAlpha=span(t,7.25,8)*(1-span(t,13.3,14));text('Intention, given form.',100,975,65,'Instrument','#402b46');c.restore()}
 if(t>=14&&t<24){const g=c.createLinearGradient(0,875,0,1080);g.addColorStop(0,'#100b1700');g.addColorStop(1,'#100b17d9');c.fillStyle=g;c.fillRect(0,875,1920,205);const title=t<18?'Business websites':t<21?'Custom web applications':'Backend systems & integrations';text(title,95,1000,48);text('ILLUSTRATIVE DESIGN STUDY',1825,1000,16,'DM','#d6c1e0','right')}
 if(t>=35){
  const resolve=span(t,36.8,38.25);c.fillStyle=`rgba(13,9,19,${resolve})`;c.fillRect(0,0,1920,1080)
  c.save();c.globalAlpha=resolve;c.globalCompositeOperation='screen';c.drawImage(logo,230,120,800,1000,660,100,600,750);c.restore()
  c.save();c.globalAlpha=span(t,35.5,36.4);spaced('IDIOMORPH',960,877,54,14);spaced('STUDIO',960,928,16,10,'#bda8cb');text('From ideas to what’s next.',960,1008,39,'Instrument','#e6d9ed','center');c.restore()
 }
 return canvas.toDataURL('image/jpeg',.97).split(',')[1]
}
window.filmReady=true
let playing=false,start=0,busy=false;const input=document.querySelector('#timeline'),readout=document.querySelector('#time'),play=document.querySelector('#play'),audio=document.querySelector('#audio')
async function seek(t){await window.renderFrame(t);input.value=t;readout.textContent=t.toFixed(2)+'s'}
input.oninput=()=>{playing=false;play.textContent='Play';audio.pause();audio.currentTime=Number(input.value);seek(Number(input.value))}
play.onclick=async()=>{playing=!playing;play.textContent=playing?'Pause':'Play';if(playing){start=performance.now()-Number(input.value)*1000;if(!audio.muted&&audio.readyState)audio.play();requestAnimationFrame(tick)}else audio.pause()}
audio.muted=true
document.querySelector('#sound').onclick=async event=>{audio.muted=!audio.muted;event.currentTarget.textContent=audio.muted?'Enable sound':'Mute sound';if(!audio.muted){audio.currentTime=Number(input.value);if(playing)await audio.play()}}
async function tick(now){if(!playing)return;const t=Math.min(41.999,(now-start)/1000);if(!busy){busy=true;await seek(t);busy=false}if(t>=41.99){playing=false;play.textContent='Play';audio.pause();return}requestAnimationFrame(tick)}
seek(0).catch(()=>{c.fillStyle='#191021';c.fillRect(0,0,1920,1080);text('Render the '+mode+' frames to preview this timeline.',80,200,40)})
