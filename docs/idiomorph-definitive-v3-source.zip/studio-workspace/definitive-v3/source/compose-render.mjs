// Composes original typography over real Blender image sequences and exports real H.264.
import{startServer}from'../../serve.mjs'
import{chromium}from'../../browser-tool.mjs'
import ffmpeg from'ffmpeg-static'
import{spawn}from'node:child_process'
import{once}from'node:events'
import{mkdir,writeFile}from'node:fs/promises'
import{fileURLToPath}from'node:url'
const mode=process.argv[2]||'animatic',step={animatic:4,preview:2,final:1}[mode],fps=24/step,count=1008/step
if(!fps)throw Error('Choose animatic, preview or final.')
const out=new URL('../output/',import.meta.url);await mkdir(out,{recursive:true});const server=await startServer()
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
try{
 const p=await browser.newPage({viewport:{width:1920,height:1080}});p.on('pageerror',e=>console.error(e.message));await p.goto('http://127.0.0.1:4192/definitive-v3/source/edit.html?mode='+mode);await p.waitForFunction(()=>window.filmReady)
 const output=fileURLToPath(new URL('idiomorph-intention-v3-'+mode+'-picture.mp4',out))
 const encoder=spawn(ffmpeg,['-y','-hide_banner','-f','image2pipe','-vcodec','mjpeg','-framerate',String(fps),'-i','pipe:0','-vf',mode==='animatic'?'scale=960:540':'scale=1920:1080','-an','-c:v','libx264','-preset','medium','-crf',mode==='final'?'16':'21','-pix_fmt','yuv420p','-movflags','+faststart',output],{windowsHide:true,stdio:['pipe','ignore','pipe']});let log='';encoder.stderr.on('data',b=>log=(log+b).slice(-5000));encoder.stdin.on('error',()=>{});const completed=once(encoder,'exit')
 for(let f=0;f<count;f++){const t=f/fps,data=await p.evaluate(t=>window.renderFrame(t),t);if(!encoder.stdin.write(Buffer.from(data,'base64')))await once(encoder.stdin,'drain');if(f%72===0)console.log(mode+' composition '+f+'/'+count)}
 encoder.stdin.end();const[code]=await completed;if(code)throw Error(log)
 for(const[t,name]of [[1.2,'human-macro'],[4.6,'human'],[10.8,'forming'],[16.5,'design'],[19.5,'application'],[22.5,'systems'],[25.2,'material'],[29.5,'transformation'],[34,'resolved'],[39,'signature']]){await p.evaluate(t=>window.renderFrame(t),t);await writeFile(new URL(mode+'-'+name+'.png',out),Buffer.from(await p.evaluate(()=>document.querySelector('#film').toDataURL('image/png').split(',')[1]),'base64'))}
 console.log('Actual '+mode+' picture exported: 42 seconds.')
}finally{await browser.close();server.close()}
