import sys, math
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from model import *
scene=reset();scene.render.resolution_x=900;scene.render.resolution_y=1000
parent,ribbons=emblem();rig()
cam=camera((0,-9,0),(0,0,0),ortho=4.4)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'emblem-model-v3.blend'))
for name,loc in [('front',(0,-9,0)),('perspective',(3.7,-8,1.3)),('side',(7,-4,.5))]:
    cam.location=loc;point(cam,(0,0,0))
    render(OUT/('emblem-'+name+'-v3.png'))
print('GATE 2: actual modeled front, perspective and side renders complete.')

