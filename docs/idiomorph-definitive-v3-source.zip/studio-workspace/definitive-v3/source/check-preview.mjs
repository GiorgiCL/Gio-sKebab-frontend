import assert from'node:assert/strict'
import{startServer}from'../../serve.mjs'
import{chromium}from'../../browser-tool.mjs'
import{writeFile}from'node:fs/promises'
const server=await startServer(),browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true})
try{const page=await browser.newPage({viewport:{width:1280,height:720}}),errors=[];page.on('pageerror',e=>errors.push(e.message))
 await page.setContent('<body style="margin:0;background:#08070b"><video controls muted style="width:100vw;height:100vh" src="http://127.0.0.1:4192/definitive-v3/output/idiomorph-intention-v3-preview.mp4"></video></body>')
 await page.locator('video').evaluate(v=>v.play())
 for(const t of [6,13,23,34,40]){await page.waitForFunction(t=>document.querySelector('video').currentTime>t,t,{timeout:20000});await page.screenshot({path:'definitive-v3/qa/preview-realtime-'+t+'.png'})}
 await page.waitForFunction(()=>document.querySelector('video').ended,null,{timeout:10000});assert.equal(await page.locator('video').evaluate(v=>v.duration),42);assert.deepEqual(errors,[])
 await writeFile(new URL('../qa/preview-playback.json',import.meta.url),JSON.stringify({fullPlaybackCompleted:true,duration:42,screenshotsAt:[6,13,23,34,40],browserErrors:errors},null,2));console.log('Complete 42-second preview playback passed; real-time review frames captured.')
}finally{await browser.close();server.close()}
