// Canonical emblem reconstruction, manually traced from the supplied image.
// These are actual curved sheet meshes, with open ends and a manufactured edge.
import {writeFile} from 'node:fs/promises'
const bez=(a,b,c,d,t)=>a.map((v,i)=>(1-t)**3*v+3*(1-t)**2*t*b[i]+3*(1-t)*t*t*c[i]+t**3*d[i])
const outlines=[
 {name:'Silver / intuition',color:'#77717f',a:[[596,286],[390,413],[306,470],[306,560],[306,560],[306,784],[413,850],[717,1048]],b:[[596,286],[596,585],[610,655],[717,789],[717,789],[717,873],[717,976],[717,1048]]},
 {name:'Violet / engineering',color:'#8957cb',a:[[623,174],[623,282],[623,357],[623,434],[623,434],[623,606],[718,657],[718,939]],b:[[623,174],[927,349],[955,395],[955,657],[955,657],[955,790],[924,823],[718,939]]}
]
export function createGeometry(rows=112,cols=28){
 return outlines.map((r,k)=>{
  const positions=[],uv=[],indices=[],flat=[]
  for(let j=0;j<=rows;j++){const t=j/rows,half=t<.5?0:4,q=t<.5?t*2:(t-.5)*2,A=bez(...r.a.slice(half,half+4),q),B=bez(...r.b.slice(half,half+4),q)
   for(let i=0;i<=cols;i++){const u=i/cols,x=A[0]*(1-u)+B[0]*u,y=A[1]*(1-u)+B[1]*u
    const z=.17+Math.sin(Math.PI*t)*.26+Math.sin(Math.PI*u)*Math.sin(Math.PI*t*2)*.65+(u-.5)*.11
    positions.push((x-630)/240,(610-y)/240,z*(k===0?1:-1));uv.push(u,t)
    flat.push((u-.5)*1.7+(k-.5)*1.95,(.5-t)*3.4,.02*Math.sin(u*Math.PI))
   }
  }
  for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){const a=j*(cols+1)+i,b=a+cols+1;indices.push(a,b,a+1,b,b+1,a+1)}
  return{name:r.name,color:r.color,positions,indices,uv,flat}
 })
}
if(process.argv[1]?.replaceAll('\\','/').endsWith('/geometry.mjs')){await writeFile(new URL('./emblem-geometry.json',import.meta.url),JSON.stringify({source:'IdiomorphLogo.png; manual interpretation, not a recovered original mesh',parts:createGeometry()},(_,v)=>typeof v==='number'?Number(v.toFixed(5)):v));console.log('Two canonical, curved ribbon meshes generated.')}
