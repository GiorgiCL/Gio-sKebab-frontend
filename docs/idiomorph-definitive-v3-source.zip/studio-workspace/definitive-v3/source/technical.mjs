import ffmpeg from 'ffmpeg-static'
import { spawnSync } from 'node:child_process'
import { mkdir, readFile, writeFile, copyFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
const path = name => fileURLToPath(new URL(name, import.meta.url))
const run = args => {
  const result = spawnSync(ffmpeg, ['-hide_banner', ...args], { windowsHide: true, encoding: 'utf8', maxBuffer: 3e6 })
  if (result.status) throw Error(result.stderr)
  return result.stderr
}
const results = []
for (const name of ['../output/idiomorph-intention-v3-master-1080p.mp4', '../../../frontend/public/studio/v3/idiomorph-intention-v3-720p.mp4', '../../../frontend/public/studio/v3/idiomorph-intention-v3-720p.webm']) {
  const text = run(['-i', path(name), '-af', 'loudnorm=I=-18:TP=-1.5:LRA=11:print_format=json', '-f', 'null', 'NUL'])
  const measure = JSON.parse(text.slice(text.lastIndexOf('{')))
  results.push({ file: name, streamInfo: text.split('\n').filter(l => /Duration:|Stream #0:/.test(l)), audio: { integratedLUFS: Number(measure.input_i), truePeakDBTP: Number(measure.input_tp), LRA: Number(measure.input_lra) } })
}
const version = spawnSync(ffmpeg, ['-version'], { encoding: 'utf8', windowsHide: true }).stdout
const packages = {}
for (const [name, location] of [['three', '../../node_modules/three/package.json'], ['ffmpeg-static', '../../node_modules/ffmpeg-static/package.json'], ['playwright-core', '../../node_modules/playwright-core/package.json'], ['axe-core', '../../../.verification/frontend-tools/node_modules/axe-core/package.json'], ['lighthouse', '../../../.verification/frontend-tools/node_modules/lighthouse/package.json']]) packages[name] = JSON.parse(await readFile(new URL(location, import.meta.url))).version
await writeFile(path('../qa/technical-media.json'), JSON.stringify(results, null, 2))
await writeFile(path('../qa/tool-versions.json'), JSON.stringify({ node: process.version, ffmpeg: version, packages, blender: { version: '4.5.9 LTS', build: '8bf95cbd38d1', officialArchiveSHA256: '41da973b9bf95bb312cbeff4d1982feb13259b43c821686b9bafea4dfe5477cf' } }, null, 2))
await mkdir(path('../licenses/'), { recursive: true })
for (const [from, to] of [
  ['../../../.verification/blender-portable/blender-4.5.9-windows-x64/copyright.txt', 'Blender-copyright.txt'],
  ['../../../.verification/blender-portable/blender-4.5.9-windows-x64/license/spdx/GPL-2.0-or-later.txt', 'Blender-GPL-2.0-or-later.txt'],
  ['../../node_modules/three/LICENSE', 'Three-MIT.txt'],
  ['../../node_modules/ffmpeg-static/LICENSE', 'FFmpeg-static-GPL.txt'],
  ['../../node_modules/playwright-core/LICENSE', 'Playwright-Apache.txt'],
  ['../../../.verification/frontend-tools/node_modules/axe-core/LICENSE', 'axe-MPL.txt'],
  ['../../../.verification/frontend-tools/node_modules/lighthouse/LICENSE', 'Lighthouse-Apache.txt'],
  ['../../fonts/DM-Sans-OFL.txt', 'DM-Sans-OFL.txt'], ['../../fonts/Instrument-Serif-OFL.txt', 'Instrument-Serif-OFL.txt'],
]) await copyFile(path(from), path('../licenses/' + to))
console.log(JSON.stringify(results, null, 2))
