// Original 42-second score and tactile sound design. No samples or external music.
// The handwriting contacts, interface adjustment and folding climax share film timings.
import{mkdir,writeFile}from'node:fs/promises'
const rate=48000,seconds=42,count=rate*seconds,pcm=Buffer.alloc(44+count*4)
pcm.write('RIFF');pcm.writeUInt32LE(pcm.length-8,4);pcm.write('WAVEfmt ',8);pcm.writeUInt32LE(16,16);pcm.writeUInt16LE(1,20);pcm.writeUInt16LE(2,22);pcm.writeUInt32LE(rate,24);pcm.writeUInt32LE(rate*4,28);pcm.writeUInt16LE(4,32);pcm.writeUInt16LE(16,34);pcm.write('data',36);pcm.writeUInt32LE(count*4,40)
const clamp=x=>Math.max(0,Math.min(1,x)),smooth=x=>{x=clamp(x);return x*x*(3-2*x)},window=(t,a,b,r=.25)=>smooth((t-a)/r)*(1-smooth((t-b+r)/r))
const notes=[[7.8,146.832,.025,5],[10.8,220,.018,5],[14.1,293.665,.043,3.5],[16.4,329.628,.029,3.3],[18.4,220,.038,3.4],[20.5,261.626,.025,3],[29,146.832,.028,5],[31.3,220,.026,5],[33.2,293.665,.022,4],[35.1,146.832,.065,5.2],[35.1,184.997,.048,5.2],[35.1,220,.043,5.2],[35.12,293.665,.037,5.2],[35.13,329.628,.022,4.3]]
let seed=75231,brown=0,low=0,fast=0,previous=0,masterLowL=0,masterLowR=0
for(let i=0;i<count;i++){
 const t=i/rate;seed=(Math.imul(seed,1664525)+1013904223)>>>0;const noise=seed/2147483648-1
 brown=brown*.998+noise*.002;low=low*.925+noise*.075;fast=fast*.58+noise*.42
 let tactile=0,music=0,depth=0
 // An intimate, non-looping room floor; paper comes forward only when touched.
 tactile+=brown*.14*window(t,0,8,.6)
 for(let j=0;j<11;j++){const a=.55+j*.48,b=a+.34;const pressure=window(t,a,b,.045);tactile+=(fast-low)*pressure*.17*(.54+.14*Math.sin(t*36)+.13*Math.sin(t*91));const age=t-a;if(age>=0&&age<.12)tactile+=low*.1*Math.exp(-age*45)}
 tactile+=(low-brown)*.1*window(t,6.05,6.85,.2)*(1+.3*Math.sin(t*23))
 // A quiet bow-like tension grows from the first lifted graphite form.
 const lift=window(t,7.4,13.5,1.4)
 music+=(Math.sin(t*2*Math.PI*146.832)+.28*Math.sin(t*2*Math.PI*293.91)+.1*Math.sin(t*2*Math.PI*440.2))*lift*.013*(.78+.14*Math.sin(t*1.1))
 depth+=Math.sin(t*2*Math.PI*48.999)*lift*.009
 for(const[a,hz,amp,length]of notes){const age=t-a;if(age<0||age>length)continue;const envelope=(1-Math.exp(-age*27))*Math.exp(-age/(length*.34))*(1-smooth((age-length+.5)/.5));const strike=Math.sin(2*Math.PI*hz*age)+.29*Math.sin(2*Math.PI*hz*2.002*age)*Math.exp(-age*2)+.1*Math.sin(2*Math.PI*hz*3.01*age)*Math.exp(-age*4);music+=strike*envelope*amp}
 // Small, soft working details follow the action, rather than arbitrary impacts.
 for(const at of [16.35,18.3,19.05,19.8]){const age=t-at;if(age>=0&&age<.2)tactile+=(Math.sin(age*2*Math.PI*190)*.012+low*.026)*(1-Math.exp(-age*250))*Math.exp(-age*29)}
 const fold=window(t,24,35,1.3),rise=smooth((t-27)/7.2),breath=.7+.16*Math.sin(t*.81)
 tactile+=(low-brown)*fold*.028*(.8+.17*Math.sin(t*7.3))
 music+=(Math.sin(2*Math.PI*146.832*t)+.32*Math.sin(2*Math.PI*220.01*t)+.2*Math.sin(2*Math.PI*329.63*t))*fold*(.012+rise*.026)*breath
 depth+=(Math.sin(2*Math.PI*48.999*t)+.35*Math.sin(2*Math.PI*73.416*t))*fold*(.008+rise*.015)
 const hinge=t-34.72;if(hinge>=0&&hinge<1.1)tactile+=(Math.sin(2*Math.PI*128*hinge)*.055+low*.037)*(1-Math.exp(-hinge*100))*Math.exp(-hinge*9)
 const pause=1-.82*window(t,34.35,34.71,.08)
 const end=1-smooth((t-39)/1.7),start=smooth(t/.25),pan=Math.sin(t*.31)*.25*(t>24?1:.3)
 const value=(music*pause+depth*pause+tactile)*end*start
 let left=value*Math.sqrt((1-pan)/2)+brown*.002*end,right=value*Math.sqrt((1+pan)/2)-brown*.002*end
 // A soft analog-like band limit removes sharp synthesized edges.
 masterLowL+=.36*(left-masterLowL);masterLowR+=.36*(right-masterLowR);left=masterLowL;right=masterLowR
 previous=value;pcm.writeInt16LE(Math.round(Math.tanh(left)*32767),44+i*4);pcm.writeInt16LE(Math.round(Math.tanh(right)*32767),46+i*4)
}
await mkdir(new URL('../output/',import.meta.url),{recursive:true});await writeFile(new URL('../output/idiomorph-intention-v3-original.wav',import.meta.url),pcm)
console.log('New original 42-second tactile score rendered, with a timed resolution and closing silence.')
