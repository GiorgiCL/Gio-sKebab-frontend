// Listening refinement: slower, softer graphite gestures; retain the reviewed score after 7 s.
import{readFile,writeFile}from'node:fs/promises'
import{createHash}from'node:crypto'
const path=new URL('../output/idiomorph-intention-v3-mix.wav',import.meta.url),wav=await readFile(path)
let start=12
while(wav.toString('ascii',start,start+4)!=='data'){const size=wav.readUInt32LE(start+4);start+=8+size+(size%2);if(start>=wav.length)throw Error('PCM data chunk missing.')}
start+=8
const rate=48000,boundary=start+7*rate*4,tailBefore=createHash('sha256').update(wav.subarray(boundary)).digest('hex')
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)},window=(t,a,b)=>smooth((t-a)/.16)*(1-smooth((t-b+.24)/.24))
let seed=84721,soft=0,room=0
for(let i=0;i<7*rate;i++){
 const t=i/rate;seed=(Math.imul(seed,1664525)+1013904223)>>>0;const noise=seed/2147483648-1
 soft=soft*.91+noise*.09;room=room*.997+noise*.003
 const phrase=window(t,.55,2.81)*.70+window(t,2.95,3.77)*.46+window(t,3.91,4.73)*.58+window(t,4.87,5.69)*.33
 const irregular=.78+room*.9+.12*Math.sin(t*5.7+.6*Math.sin(t*2.1))
 let v=(soft-room)*phrase*irregular*.53+room*.075
 v+=(soft-room)*window(t,6.0,6.55)*.055
 v*=smooth(t/.3)
 const blend=smooth((t-6.6)/.4)
 for(let channel=0;channel<2;channel++){const offset=start+i*4+channel*2,old=wav.readInt16LE(offset)/32768,value=v*(channel?1.025:.975)*(1-blend)+old*blend;wav.writeInt16LE(Math.round(Math.max(-.999,Math.min(.999,value))*32767),offset)}
}
const tailAfter=createHash('sha256').update(wav.subarray(boundary)).digest('hex')
if(tailBefore!==tailAfter)throw Error('The reviewed score after 7 seconds must remain identical.')
await writeFile(path,wav);await writeFile(new URL('../qa/audio-listening-refinement.json',import.meta.url),JSON.stringify({listener:'User',feedback:'Opening initially harsh and too quickly repetitive; later section sounds fine.',change:'Recomposed 0–7 s as four slower, band-limited graphite phrases; softer transients and pauses.',afterSevenSecondsBitIdentical:true,tailSHA256:tailAfter},null,2))
console.log('Opening softened and rephrased. Reviewed audio after 7 seconds is bit-identical.')
