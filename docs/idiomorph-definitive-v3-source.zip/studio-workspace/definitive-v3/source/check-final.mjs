import assert from 'node:assert/strict'
import { chromium } from '../../browser-tool.mjs'
import { writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
const browser = await chromium.launch({ executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: true })
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } }), errors = []
  page.on('pageerror', e => errors.push(e.message))
  await page.goto('http://localhost:4173/studio')
  await page.getByRole('button', { name: /Watch the film/ }).first().click()
  await page.waitForFunction(() => document.querySelector('video')?.readyState >= 2)
  await page.locator('video').evaluate(v => { v.textTracks[0].mode = 'hidden' })
  await page.waitForFunction(() => document.querySelector('video').textTracks[0].cues?.length >= 9)
  for (const t of [1, 6, 11, 16, 19, 22, 26, 30, 34, 39]) {
    await page.waitForFunction(t => document.querySelector('video').currentTime > t, t, { timeout: 12000 })
    await page.locator('video').screenshot({ path: fileURLToPath(new URL('../qa/final-realtime-' + t + '.png', import.meta.url)) })
  }
  await page.waitForFunction(() => document.querySelector('video').ended, null, { timeout: 10000 })
  const result = await page.locator('video').evaluate(v => ({
    completed: v.ended, duration: v.duration, width: v.videoWidth, height: v.videoHeight, currentSrc: v.currentSrc,
    captions: v.textTracks[0].cues.length, muted: v.muted,
    decodedFrames: v.getVideoPlaybackQuality().totalVideoFrames, droppedFrames: v.getVideoPlaybackQuality().droppedVideoFrames,
  }))
  assert.ok(Math.abs(result.duration - 42) < .05); assert.deepEqual(errors, [])
  await writeFile(new URL('../qa/final-playback.json', import.meta.url), JSON.stringify({ ...result, browser: await browser.version(), errors }, null, 2))
  console.log(JSON.stringify(result, null, 2))
} finally { await browser.close() }
