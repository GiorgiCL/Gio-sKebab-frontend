// Use the rendered human scene without the film's caption, leaving room for player UI.
import ffmpeg from 'ffmpeg-static'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
const path = name => fileURLToPath(new URL(name, import.meta.url))
for (const [size, suffix] of [['1600:900', ''], ['640:360', '-small']]) {
  const result = spawnSync(ffmpeg, ['-y', '-v', 'error', '-i', path('../output/final/0111.png'), '-vf', 'scale=' + size, '-c:v', 'libwebp', '-quality', '86', '-frames:v', '1', path('../../../frontend/public/studio/v3/intention-v3-poster' + suffix + '.webp')], { windowsHide: true, encoding: 'utf8' })
  if (result.status) throw Error(result.stderr)
}
console.log('Clean, original Blender poster exported at two responsive sizes.')
