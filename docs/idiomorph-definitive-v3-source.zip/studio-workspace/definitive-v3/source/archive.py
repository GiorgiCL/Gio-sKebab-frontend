"""Package versioned authored production and studio source without tools or render caches."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json

ROOT = Path(__file__).resolve().parents[3]
WORK = ROOT / 'studio-workspace'
V3 = WORK / 'definitive-v3'
TARGET = ROOT / 'frontend/docs/idiomorph-definitive-v3-source.zip'
if TARGET.exists():
    raise SystemExit('This v3 source archive already exists. Preserve it; choose a new filename for another iteration.')
files = set()

def add(path):
    path = path.resolve()
    path.relative_to(ROOT.resolve())
    if path.is_file():
        files.add(path)

def tree(path):
    for item in path.rglob('*'):
        if '__pycache__' not in item.parts and item.suffix not in {'.pyc', '.log'}:
            add(item)

for name in ['package.json', 'package-lock.json', 'serve.mjs', 'browser-tool.mjs']:
    add(WORK / name)
tree(WORK / 'fonts')
add(WORK / 'brand/IdiomorphLogo.png')
tree(V3 / 'source')
tree(V3 / 'licenses')
for name in ['README.md', 'DIRECTION.md', 'LICENSES.md']:
    add(V3 / name)
for name in ['idiomorph-intention-v3.blend', 'emblem-model-v3.blend', 'idiomorph-intention-v3-mix.wav']:
    add(V3 / 'output' / name)
tree(V3 / 'output/plates')
for name in ['emblem-front-v3.png', 'emblem-perspective-v3.png', 'emblem-side-v3.png']:
    add(V3 / 'output' / name)
for pattern in ['*.json', 'final-contact-sheet.png']:
    for item in (V3 / 'qa').glob(pattern):
        add(item)
for folder in ['browser', 'lighthouse', 'existing-seo', 'visual']:
    for item in (V3 / 'qa' / folder).glob('*.json'):
        add(item)
for name in ['desktop-hero.png', 'desktop-full.png', 'mobile-full.png']:
    add(V3 / 'qa/visual' / name)
add(V3 / 'qa/browser/emblem-front.png')
add(V3 / 'qa/browser/emblem-construction.png')
add(V3 / 'baseline/git.json')
tree(ROOT / 'frontend/src/features/studio')
tree(ROOT / 'frontend/public/studio/v3')
for item in (ROOT / 'frontend/public/studio').glob('brand-*'):
    add(item)
for name in ['package.json', 'package-lock.json', 'docs/STUDIO_DEFINITIVE_V3.md']:
    add(ROOT / 'frontend' / name)

manifest = [{'file': str(p.relative_to(ROOT)).replace('\\', '/'), 'bytes': p.stat().st_size,
             'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)]
with ZipFile(TARGET, 'x', compression=ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(files):
        archive.write(path, path.relative_to(ROOT))
    archive.writestr('V3-SOURCE-MANIFEST.json', json.dumps(manifest, indent=2))
with ZipFile(TARGET) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(files) + 1
result = {'file': str(TARGET), 'bytes': TARGET.stat().st_size, 'entries': len(files) + 1,
          'sha256': hashlib.sha256(TARGET.read_bytes()).hexdigest(), 'crcVerified': True,
          'excludes': ['tool binaries', 'node_modules', 'large image sequences', 'accepted previous film', 'render caches']}
(V3 / 'qa/source-archive.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
