# Definitive refinement — production gates

Checkpoint: frontend development / 17df6433748bc6eecee3e3a9774420c3e5f44fdf; backend development / bcab789a6c6278cd60985293929c745b67b9d310. Both clean initially. Accepted film/source copied to baseline. No accepted video or master will be overwritten.

## Source review
Preserve left editorial hero/right supplied identity, self-hosted type, on-demand playback, functional service studies, route/footer. Improve reward of symbol exploration, rail legibility, dark-to-light passages, process visual continuity, contact composition visibility.

## Selected production
Blender 4.5 LTS (official portable, user approved), original modeled folded sheets, original stylized hand-work scene, authored materials and lights. Existing Three.js 0.180.0 for the same live mesh on demand. Existing FFmpeg for assembly and formats. No Remotion, Theatre, additional engine, stock or generative API needed.

## Directed 42-second sequence
0–3: Extreme close-up, pencil meets warm textured paper. Short contact, breath, deliberate pause.
3–7: A stylized sculpted hand guides the mark; camera slowly widens; a question gives way to a curve.
7–11: The graphite path lifts, its thickness catches light; the page's sketch becomes a physical ribbon.
11–14: Two complementary ribbons reveal their construction in an architectural space.
14–18: A design study responds to a deliberate pointer; space is refined.
18–21: Application flow advances through a person-shaped sequence.
21–24: Connections find their route; the interface planes turn toward the sculptural space.
24–29: Material close-ups, opposing curves, camera travels through the central opening.
29–35: Two folded surfaces assemble; controlled light travels across silver/violet.
35–42: Canonical silhouette resolves; exact supplied logo/identity finish; 'From ideas to what’s next.'; time to recognize; silence.

Human scene is intentionally stylized sculpture, not a person or employee claim. Interfaces are illustrative concept studies.

## Review order
Compare actual front/side/perspective mesh renders against supplied logo. Keep static hero default if needed.
Render complete small animatic. Review frames and full pacing. Build soundtrack to those moments.
Render preview, inspect, then HQ master. Integrate versioned derivatives only after visual review.
Record browser, accessibility, performance and media results separately from creative judgment.
