# Idiomorph Studio — definitive v3

An original 42-second production, **From human intention to digital form**, and a refinement of the established studio page. The supplied identity and left-text/right-emblem hero remain the visual anchor. The live object is an explicitly labelled sculptural interpretation, rather than a replacement for the approved image.

## Preview

From `frontend`, run `npm run dev` and open the printed local address at `/studio` (usually `http://localhost:5173/studio`). To check production output, use `npm run build` then `npm run preview` (usually port 4173). No backend is needed by the studio page.

Open `output/idiomorph-intention-v3-master-1080p.mp4` in a local video player. Open `output/idiomorph-intention-v3.blend` in Blender 4.5 LTS to edit the cameras, materials, geometry, lights, hand pose, animation and packed original interface textures.

From `studio-workspace`, `node serve.mjs` serves the composition editor at `http://127.0.0.1:4192/definitive-v3/source/edit.html?mode=final`. It uses the existing local `output/final/` image sequence; those large frames are deliberately excluded from the source ZIP. The editor has a timeline, play/pause and explicit sound toggle. Stop the server with Ctrl+C.

## Film direction and timeline

| Time | Shot and purpose |
| --- | --- |
| 0–3 s | Extreme close pencil contact; warm paper; an intimate beginning. |
| 3–7 s | Original stylized clay hand draws “What if?”; a wider human-scale view. |
| 7–14 s | Two surfaces lift from the sketch and fold; intention acquires structure. |
| 14–18 s | Original illustrative website study; considered typography and spacing. |
| 18–21 s | Application request, review and ready sequence. |
| 21–24 s | Connected system components; one purposeful travelling signal. |
| 24–27 s | Brushed metal macro; material and light. |
| 27–35 s | Folded ribbons turn and converge; the central negative space resolves. |
| 35–42 s | Modeled emblem resolves to the exact supplied logo; brand hold and closing line. |

The hand is deliberately sculpted and stylized. It is not filmed studio personnel. Interfaces are concept studies, not client work. No stock, models, music, footage, HDRI, generative service or paid asset is used.

## Production source

- `source/geometry.mjs`: two manually traced, curved ribbon surfaces and flattened construction states; shared geometry for offline and live rendering.
- `source/model.py`, `gate-model.py`: Blender materials, lights, real sheet thickness, canonical-view feasibility renders and editable model.
- `source/film.py`: complete 1008-frame Blender timeline; camera markers, hand/pencil animation, shape keys, material transitions and original scene geometry.
- `source/plates.*`, `make-plates.mjs`: original interface textures, drawn with the existing self-hosted fonts.
- `source/compose.mjs`, `edit.html`, `compose-render.mjs`: crisp typography and exact-logo resolve over the real rendered frames.
- `source/sound.mjs`, `normalize-sound.mjs`, `soften-opening.mjs`: deterministic original stereo sound and loudness processing. The opening was revised following the user's listening feedback. Samples after 7 seconds remain bit-identical to the positively reviewed mix.
- `source/media.mjs`, `poster.mjs`: mux, compressed MP4/WebM, poster without overlapping film captions, stage imagery, strict decode checks and contact sheet.
- `source/verify.mjs`, `visual.mjs`, `lighthouse.mjs`: browser and accessibility/performance verification. QA tools are reused from the isolated root `.verification` directory; they are not website dependencies.
- `source/existing-seo.mjs`: existing restaurant SEO regression assertions with Playwright CDP transport, separate output directory and unchanged fixtures/assertions. The old raw-WebSocket transport stalled at `Page.enable` in this environment; this adaptation passed.

## Rebuilding only when needed

The final 1080p image sequence already exists. Do not rerender Blender to change captions, typography, sound, compression or the webpage.

Run these from `studio-workspace` with the existing installed dependencies:

```powershell
node definitive-v3/source/make-plates.mjs
# Only after changing actual scene geometry, lighting, cameras or animation:
& '..\.verification\blender-portable\blender-4.5.9-windows-x64\blender.exe' -b -t 8 --python definitive-v3/source/film.py -- --mode preview
# Review the complete low-resolution preview before choosing --mode final.

# Only after changing the sound source:
node definitive-v3/source/sound.mjs
node definitive-v3/source/normalize-sound.mjs

# Existing final frames -> final composition and web derivatives:
node definitive-v3/source/compose-render.mjs final
node definitive-v3/source/media.mjs final
```

The original accepted master, editable source and frontend assets remain unchanged. These commands target v3 only. Rendering `film.py` saves the versioned v3 `.blend`; preserve a local copy before making a new creative iteration. Nothing here commits, publishes or deploys.

## Validation and evidence

`qa/browser/results.json`, `qa/visual/visual-checks.json`, `qa/lighthouse/lighthouse-summary.json`, `qa/media-results.json` and `qa/existing-seo/seo-head-checks.json` contain the measured evidence. `qa/final-contact-sheet.png` shows every second of the actual encoded film; `qa/final-frames/` contains the individual images. Source review and accepted baselines are preserved under `baseline/`.

The source ZIP contains the authored sources, packed Blender projects, original plates, canonical logo, fonts/notices, v3 web assets and frontend studio source. It excludes node_modules, tool binaries, large render sequences, caches and the unchanged previous film. Dependencies remain pinned in the existing production-workspace package/lock files. Any installation on a different machine requires that owner's permission under this task's workflow.

## Publication conditions

`frontend/src/features/studio/config.ts` is the single email/media configuration. The mailbox is proposed and unconfirmed; `emailConfirmed` and `publicationReady` remain false. Drafts stay in the visitor's browser until they open their own mail client. No form submission, backend, tracking or storage is added. Confirm the mailbox and rights to the owner-supplied logo before publication. Browser QA is local Chrome with emulated viewports/touch, not physical-device or Safari certification. Final artistic and listening review remains a human judgment.
