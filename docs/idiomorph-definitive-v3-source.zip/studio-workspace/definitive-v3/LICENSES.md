# Provenance, licenses and zero-cost assessment

Required tooling, exports and assets cost **€0**. There is no account, trial, billing requirement, paid API, stock library, watermark, subscription or external media request. No new frontend package dependency was installed. The sole downloaded tool was the explicitly approved official portable Blender archive, isolated under root `.verification/blender-portable`.

## Authored assets

All hand, pencil, paper, interfaces, emblem mesh, scene materials, procedural textures, environment lights, animation, sound synthesis and composition code in v3 were authored for this task. There are no third-party actors, models, HDRIs, textures, footage or music. No person depicted is claimed to be an employee or client. Code and generated work are delivered with this project; no third-party commercial restriction is introduced by the production itself.

The canonical image is **owner supplied**: `C:\Users\giorg\Desktop\IdiomorphLogo.png`, 1254×1254, 1,495,263 bytes. Preserved at `studio-workspace/brand/IdiomorphLogo.png`; SHA-256 `144191ebe85a63e422fe9eed12cd099cb52b5d638609ac28c42fc107cf434769`. Its license was not independently supplied or established; commercial rights should be confirmed by the owner before publication. This is distinct from the original manually modeled interpretation. Existing optimized logo variants remain unchanged.

## Tools and retained notices

| Tool/asset | Actual version | Terms and use |
| --- | --- | --- |
| Blender | 4.5.9 LTS, build `8bf95cbd38d1` | GPL-2.0-or-later; bundled components may be GPL-3-compatible. Commercial creation permitted, no organization-size limit. Local production tool, no binary distributed with the page/source ZIP. The GPL does not automatically license the original rendered art. Official archive copyright and licenses inspected. |
| Three.js | 0.180.0 | MIT; commercial use permitted, no headcount restriction. Existing installed version; only the minified runtime/core required for the live study are vendored, with the exact MIT notice in `frontend/public/studio/v3/runtime/THREE-LICENSE.txt`. |
| FFmpeg | 6.0 build with GPL enabled; ffmpeg-static 5.2.0 | GPL-3.0-or-later local tool/wrapper in this installed distribution; commercial use permitted, no size limit. Encoding only, binary not shipped. Original movie output is not software derived from FFmpeg. |
| Playwright Core | 1.64.1 | Apache-2.0, local browser automation. Existing isolated install; no site runtime. |
| axe-core | 4.14.0 | MPL-2.0, local accessibility audit. Existing isolated install; no shipped runtime or modification. |
| Lighthouse | 13.5.0 | Apache-2.0, existing local performance audit; no site runtime. |
| DM Sans / Instrument Serif | Existing self-hosted font files | SIL OFL-1.1, commercial website/video use permitted. Original font files and exact notices retained in `studio-workspace/fonts/` and the source archive. No font API requests. |
| Node.js | 25.2.1 | MIT and bundled third-party notices; existing local orchestration tool. |
| Python | 3.14.0 host; Blender's bundled Python for scene production | PSF license / bundled tool terms; existing local use. |
| Google Chrome | 155.0.8059.80 | Existing free local verification browser; Chrome itself is not claimed to be open-source. No browser binary is shipped. |

All adopted open-source tools above permit this commercial workflow without an organization-size restriction. Their required notices are retained with redistributed components. Tool-license snapshots in `licenses/` supplement, rather than replace, the originals in the installed packages.

## Primary provenance

- Official Blender release: `https://download.blender.org/release/Blender4.5/blender-4.5.9-windows-x64.zip`; checksum from the same official release directory. Archive SHA-256 **41da973b9bf95bb312cbeff4d1982feb13259b43c821686b9bafea4dfe5477cf**. Official release index captured in `qa/blender-release-index.html`; distribution copyright and license directory inspected locally.
- Blender licensing: https://www.blender.org/about/license/ ; exact downloaded `copyright.txt` is retained in `licenses/`.
- Three.js exact release license: https://github.com/mrdoob/three.js/blob/r180/LICENSE ; matches the installed distribution.
- FFmpeg licensing: https://ffmpeg.org/legal.html ; exact local binary build/configuration recorded in `qa/tool-versions.json`.
- Playwright: https://github.com/microsoft/playwright/blob/main/LICENSE ; exact installed notice retained.
- axe-core: https://github.com/dequelabs/axe-core/blob/develop/LICENSE ; exact installed MPL notice retained.
- Lighthouse: https://github.com/GoogleChrome/lighthouse/blob/main/LICENSE ; exact installed Apache notice retained.
- Font provenance and OFL notices: existing project Fontsource distribution; https://github.com/google/fonts/tree/main/ofl/dmsans and https://github.com/google/fonts/tree/main/ofl/instrumentserif .

## Evaluated but not adopted

Remotion is source-available with a special commercial license, not an unrestricted OSI open-source dependency. Its official [license FAQ](https://www.remotion.dev/docs/license/faq) permits free use for individuals and organizations of at most three people; four or more requires the applicable Company License. Organization eligibility was not established, so it is not used. No Remotion code, rendering or subscription is required.

Theatre.js and PlayCanvas were considered through their official repositories/documentation; neither is installed, copied or depended upon. Existing Three.js and Blender meet the actual production needs with fewer runtime dependencies. Motion for React and React Three Fiber were unnecessary and not added. No third-party design template/skill code was copied into the product.
